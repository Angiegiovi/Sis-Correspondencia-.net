﻿Imports System.Text

Friend Class NetJSON

#Region " Private Declarations"
    Dim myName As String = ""
    Dim myContent As New Hashtable
    Const dblQuote As Char = Chr(34)
#End Region

#Region " Enumerations"
    Private Enum dataType
        dt_Nothing
        dt_Boolean
        dt_Decimal
        dt_Double
        dt_Integer
        dt_string
        dt_Array
        dt_NetJSON
    End Enum
#End Region

#Region " Public Constructors, Methods and Properties"
    Public Sub New()

    End Sub

    Public Sub New(ByVal nameString As String)
        myName = nameString
    End Sub

    Public Sub AddNameValue(ByVal nameString As String, ByVal Value As Object)
        StoreValue(nameString, Value)
    End Sub

    Public Overrides Function toString() As String
        Dim Resp As New StringBuilder
        Dim Firstcall As Boolean = True
        Dim TailBrace As String = "}"

        If myName.Length > 0 Then
            Resp.Append("{" & dblQuote & myName & dblQuote & ": {")
            TailBrace &= "}"
        Else
            Resp.Append("{")
        End If

        Dim myEnumerator As IDictionaryEnumerator = myContent.GetEnumerator()
        While myEnumerator.MoveNext
            Resp.Append(IIf(Firstcall, "", ", ") & dblQuote & myEnumerator.Key & dblQuote & ": " & MakeString(myEnumerator.Value))
            Firstcall = False
        End While

        Resp.Append(TailBrace)
        Return Resp.ToString()
    End Function

#End Region

#Region " Private Functions and Subroutines"
    Private Function MakeString(ByVal ThisData As Object) As String
        Dim ThisType As dataType = GetDataType(ThisData)

        If ThisType = dataType.dt_Array Then
            Dim TestArray(ThisData.length) As Object
            Dim aLoop As Int16
            Dim ArrayStruct As New StringBuilder("[")
            Dim FirstCall As Boolean = True

            ThisType = GetDataType(ThisData(0))

            For aLoop = 0 To ThisData.Length - 1
                ArrayStruct.Append(IIf(FirstCall, "", ", ") & MakeElementString(ThisData(aLoop), ThisType))
                FirstCall = False
            Next

            ArrayStruct.Append("]")
            Return ArrayStruct.ToString()
        Else
            Return MakeElementString(ThisData, ThisType)
        End If
    End Function

    Private Function MakeElementString(ByVal ThisData As Object, ByVal ThisDataType As dataType)
        Select Case ThisDataType
            Case dataType.dt_Boolean
                Return IIf(CBool(ThisData), "true", "false")
            Case dataType.dt_Decimal
                Return String.Format("{0}", ThisData).Replace(","c, "."c)
            Case dataType.dt_string
                Return Chr(34) & CType(ThisData, String).Replace("\", "\\").Replace("/", "\/").Replace(vbCrLf, "\n").Replace(vbTab, "\t").Replace(Chr(34), "\" & Chr(34)) & Chr(34)
            Case dataType.dt_Nothing
                Return "null"
            Case dataType.dt_NetJSON
                Return ThisData.ToString()
            Case Else
                Return ""
        End Select
    End Function

    Private Function GetDataType(ByVal Value As Object) As dataType
        If TypeOf Value Is Array Then
            Return dataType.dt_Array
        ElseIf TypeOf Value Is Single Or TypeOf Value Is Double Then
            Return dataType.dt_Double
        ElseIf TypeOf Value Is Decimal Then
            Return dataType.dt_Decimal
        ElseIf TypeOf Value Is Boolean Then
            Return dataType.dt_Boolean
        ElseIf TypeOf Value Is String Then
            Return dataType.dt_string
        ElseIf TypeOf Value Is Integer Or TypeOf Value Is Int16 Or TypeOf Value Is Int32 Or TypeOf Value Is Int64 Then
            Return dataType.dt_Integer
        ElseIf TypeOf Value Is NetJSON Then
            Return dataType.dt_NetJSON
        ElseIf Value Is Nothing Then
            Return dataType.dt_Nothing
        End If
    End Function


    Private Sub StoreValue(ByVal nameString As String, ByVal Value As Object)
        Select Case GetDataType(Value)
            Case dataType.dt_Array
                Dim copyArray(Value.length - 1) As Object
                For aLoop As Int16 = 0 To Value.length - 1
                    copyArray(aLoop) = Value(aLoop)
                Next
                myContent.Add(nameString, copyArray)

            Case dataType.dt_Boolean
                Dim wrkBoolean As Boolean = CBool(Value)
                myContent.Add(nameString, wrkBoolean)

            Case dataType.dt_Double, dataType.dt_Integer, dataType.dt_Decimal
                Dim wrkDecimal As Decimal = CDec(Value)
                myContent.Add(nameString, wrkDecimal)

            Case dataType.dt_string
                Dim wrkString As String = CStr(Value)
                myContent.Add(nameString, wrkString)

            Case dataType.dt_NetJSON
                myContent.Add(nameString, Value)

            Case dataType.dt_Nothing
                myContent.Add(nameString, Nothing)

        End Select
    End Sub

#End Region

End Class
