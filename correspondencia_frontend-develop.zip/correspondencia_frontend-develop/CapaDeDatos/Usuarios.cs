﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class Usuarios
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;
          

        #endregion
        #region "Constructor"

            public Usuarios()
            {
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _CodigoUsuarioHR { get; set; }
            public int _CodigoRol { get; set; }
            public int _CodigoFuncionario { get; set; }
            public int _Habilitado { get; set; }

            //extras
            public string _NombreCompleto { get; set; }
            public int _CodigoCargo { get; set; }
            public int _CodigoUnidad { get; set; }
            public string _NombreUnidad { get; set; }
            public int _CodigoDepto { get; set; }
            public string _NombreDepto { get; set; }
            public int _TipoCargo { get; set; }
            public int _CodigoArea { get; set; }
            public int _CodigoResidencia { get; set; }

            public int _err_Existente{ get; set; }
            public string _err_Mensaje{ get; set; }
            public int _err_Codigo { get; set; }

        #endregion
        #region "funciones publicas"
//-------------------------------------------------------------------------------
        public SqlDataReader _ValidarAccesoDeUsuario(string pLogin, string pPassword)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("sel_LoginUsuario", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Login = new SqlParameter("@LoginUsuario", SqlDbType.VarChar, 250);
                Parameter_Login.Value = pLogin;
                Parameter_Login.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Login);

                SqlParameter Parameter_Password = new SqlParameter("@PasswordUsuario", SqlDbType.VarChar, 250);
                Parameter_Password.Value = pPassword;
                Parameter_Password.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Password);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_ValidarAccesoDeUsuario::Produjo un error.", MiExcepcion);
                }
            }
//--------------------------------------------------------------------------------------
        public DataSet _ListadoAsignacionRolesDeUsuarios(int pEstado , string pBusqueda, int pper_codigo_administrado, int pper_codigo_administra,int pCodigoRol, int pper_codigo)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("sel_Personas_Rol", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Estado = new SqlParameter("@Estado", SqlDbType.Int, 4);
            Parameter_Estado.Value = pEstado;
            Parameter_Estado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Estado);

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 30);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            SqlParameter Parameter_per_codigo_administrado = new SqlParameter("@per_codigo_administrado", SqlDbType.Int, 11);
            Parameter_per_codigo_administrado.Value = pper_codigo_administrado;
            Parameter_per_codigo_administrado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_administrado);

            SqlParameter Parameter_per_codigo_administra = new SqlParameter("@per_codigo_administra", SqlDbType.Int, 11);
            Parameter_per_codigo_administra.Value = pper_codigo_administra;
            Parameter_per_codigo_administra.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_administra);

            SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
            Parameter_CodigoRol.Value = pCodigoRol;
            Parameter_CodigoRol.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoRol);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);
            

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_personas");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//--------------------------------------------------------------------------------------
        public SqlDataReader _AdicionarRolAPersona(int pCodigoRol, int pper_codigo, int pper_codigo_responsable)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_Personas_Rol", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
            Parameter_CodigoRol.Value = pCodigoRol;
            Parameter_CodigoRol.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoRol);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_ValidarAccesoDeUsuario::Produjo un error.", MiExcepcion);
            }
        }
//-------------------------------------------------------------------------------
        public SqlDataReader _EliminarAsignacionRolUsuario(int pCodigoUsuarioHR, int pper_codigo_responsable)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_Personas_Rol", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuarioHR = new SqlParameter("@CodigoUsuarioHR", SqlDbType.Int, 11);
            Parameter_CodigoUsuarioHR.Value = pCodigoUsuarioHR;
            Parameter_CodigoUsuarioHR.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuarioHR);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_ValidarAccesoDeUsuario::Produjo un error.", MiExcepcion);
            }
        }
//--------------------------------------------------------------------------------------


















//-------------------------------------------------------------------------------
        public DataSet ListadoAsignacionUsuarios(int pCriterio, string pBusqueda, int pCodigoRol, int pCodigoFuncionario, int pCodigoUnidad)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("sel_AsignacionUsuarios", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Criterio = new SqlParameter("@Criterio", SqlDbType.Int, 4);
            Parameter_Criterio.Value = pCriterio;
            Parameter_Criterio.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Criterio);

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
            Parameter_CodigoRol.Value = pCodigoRol;
            Parameter_CodigoRol.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoRol);

            SqlParameter Parameter_CodigoFuncionario = new SqlParameter("@CodigoFuncionario", SqlDbType.Int, 11);
            Parameter_CodigoFuncionario.Value = pCodigoFuncionario;
            Parameter_CodigoFuncionario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoFuncionario);

            SqlParameter Parameter_CodigoUnidad = new SqlParameter("@CodigoUnidad", SqlDbType.Int, 11);
            Parameter_CodigoUnidad.Value = pCodigoUnidad;
            Parameter_CodigoUnidad.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUnidad);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_personas");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//-------------------------------------------------------------------------------
        public bool ObtenerUsuarioHRPorID(string pCodigoUsuario)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("sel_UsuarioHRPorId", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoUsuarioHR", SqlDbType.VarChar, 250);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    _CodigoRol = Convert.ToInt32(Lector["cCodigoRol"]);
                    _CodigoFuncionario = Convert.ToInt32(Lector["cCodigoFuncionario"]);
                    _Habilitado = Convert.ToInt32(Lector["cHabilitado"]);

                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                    Lector.Close();
                    SqlCon.Close();
                    if (_CodigoError == 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    Lector.Close();
                    SqlCon.Close();
                    _CodigoError = -1;
                    return false;
                }
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ExisteUsuarioPorCuenta::Produjo un error.", MiExcepcion);
            }
        }
//-------------------------------------------------------------------------------
//-------------------------------------------------------------------------------
        public bool Modificar(int pCodigoUsuarioHR, int pCodigoRol, int pCodigoFuncionario, int pHabilitado)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_UsuariosHR", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuarioHR = new SqlParameter("@CodigoUsuarioHR", SqlDbType.Int, 11);
            Parameter_CodigoUsuarioHR.Value = pCodigoUsuarioHR;
            Parameter_CodigoUsuarioHR.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuarioHR);

            SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
            Parameter_CodigoRol.Value = pCodigoRol;
            Parameter_CodigoRol.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoRol);

            SqlParameter Parameter_CodigoFuncionario = new SqlParameter("@CodigoFuncionario", SqlDbType.Int, 11);
            Parameter_CodigoFuncionario.Value = pCodigoFuncionario;
            Parameter_CodigoFuncionario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoFuncionario);

            SqlParameter Parameter_Habilitado = new SqlParameter("@Habilitado", SqlDbType.Int, 1);
            Parameter_Habilitado.Value = pHabilitado;
            Parameter_Habilitado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Habilitado);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Contrato::Modificacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//-------------------------------------------------------------------------------
        public bool ModificarPorRolYUsuario(int pCodigoRol, int pCodigoFuncionarioAnt, int pCodigoFuncionarioActual)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_UsuariosPorRol", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
            Parameter_CodigoRol.Value = pCodigoRol;
            Parameter_CodigoRol.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoRol);

            SqlParameter Parameter_CodigoFuncionarioAnt = new SqlParameter("@CodigoFuncionarioAnt", SqlDbType.Int, 11);
            Parameter_CodigoFuncionarioAnt.Value = pCodigoFuncionarioAnt;
            Parameter_CodigoFuncionarioAnt.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoFuncionarioAnt);

            SqlParameter Parameter_CodigoFuncionarioActual = new SqlParameter("@CodigoFuncionarioActual", SqlDbType.Int, 11);
            Parameter_CodigoFuncionarioActual.Value = pCodigoFuncionarioActual;
            Parameter_CodigoFuncionarioActual.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoFuncionarioActual);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Contrato::Modificacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//-------------------------------------------------------------------------------
        public bool Eliminar(int pCodigoUsuarioHR)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_UsuariosHR", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuarioHR = new SqlParameter("@CodigoUsuarioHR", SqlDbType.Int, 11);
            Parameter_CodigoUsuarioHR.Value = pCodigoUsuarioHR;
            Parameter_CodigoUsuarioHR.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuarioHR);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Rol::Eliminacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//-------------------------------------------------------------------------------
        public bool EliminarPorRolYUsuario(int pCodigoFuncionario, int pCodigoRol)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_RolPorUsuario", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoFuncionario = new SqlParameter("@CodigoFuncionario", SqlDbType.Int, 11);
            Parameter_CodigoFuncionario.Value = pCodigoFuncionario;
            Parameter_CodigoFuncionario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoFuncionario);

            SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
            Parameter_CodigoRol.Value = pCodigoRol;
            Parameter_CodigoRol.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoRol);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Rol::Eliminacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//-------------------------------------------------------------------------------
        public bool EliminarAsignacionPorUsuario(int pCodigoFuncionario)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_AsignacionPorUsuario", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoFuncionario = new SqlParameter("@CodigoFuncionario", SqlDbType.Int, 11);
            Parameter_CodigoFuncionario.Value = pCodigoFuncionario;
            Parameter_CodigoFuncionario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoFuncionario);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Rol::Eliminacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//-------------------------------------------------------------------------------
        
//-------------------------------------------------------------------------------
        public DataSet BuscarPersonas(string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("sel_AutocompletarFuncionario", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_personas");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//-------------------------------------------------------------------------------
        public bool ObtenerRolPorUsuario(string pCodigoUsuario)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("sel_ObtenerRolDePersona", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoFuncionario", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    _CodigoRol = Convert.ToInt32(Lector["cCodigoRol"]);

                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                    Lector.Close();
                    SqlCon.Close();
                    if (_CodigoError == 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    Lector.Close();
                    SqlCon.Close();
                    _CodigoError = -1;
                    return false;
                }
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ExisteUsuarioPorCuenta::Produjo un error.", MiExcepcion);
            }
        }
//-------------------------------------------------------------------------------
        public bool VerificaPasswordActual(int pCodigoUsuarioHR)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("sel_VerificaPasswordActual", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuarioHR = new SqlParameter("@CodigoUsuarioHR", SqlDbType.Int, 11);
            Parameter_CodigoUsuarioHR.Value = pCodigoUsuarioHR;
            Parameter_CodigoUsuarioHR.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuarioHR);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Rol::Eliminacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//-------------------------------------------------------------------------------
        #endregion
    }
}
