﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI;

namespace CapaDeDatos
{
    public class HojaRuta
    {
        #region "Variables"
            
            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"
            
            public HojaRuta()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion

        #region "Propiedades publicas"

            public int _CodigoHojaRuta { get; set; }
            public string _Referencia { get; set; }
            public string _Procedencia { get; set; }
            public string _FechaRegistro { get; set; }
            public int _CodigoEstado { get; set; }
            public int _CodigoTipoHojaRuta { get; set; }
            public string _CodigoCorrelatvo { get; set; }
            public string _FechaRecepcion { get; set; }
            public string _CodigoCorrespondencia { get; set; }

            public string _HoraRegistro { get; set; }
            public string _HoraRecepcion { get; set; }
            public string _CITE { get; set; }
            public char _PQ { get; set; }

            public int _EnUso { get; set; }
            public string _Anexos { get; set; }

        #endregion
        #region "funciones publicas"

//---------------------------------------------------------------------------------------------------------------------
        // LISTA LAS HOJAS DE RUTA CON CERTIFICACION PRESUPUESTARIA
            public DataSet _ListadoHRCertificacionPresupuestaria(int pper_codigo, int pRol)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("list_hojasRutaCCP", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Per_Codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_Per_Codigo.Value = pper_codigo;
                Parameter_Per_Codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Per_Codigo);
               
                SqlParameter Parameter_pRol = new SqlParameter("@codigoRol ", SqlDbType.Int, 11);
                Parameter_pRol.Value = pRol;
                Parameter_pRol.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pRol);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    //Retorno = da.Fill(ds, "DataGrid_busqueda");
                    Retorno = da.Fill(ds, "DataGrid_hr_ccp");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("HojaRuta::ListadoHRCertificacionPresupuestaria::Produjo un error.", MiExcepcion);
                }
                finally
                {  SqlCon.Close(); }
            }
//----------------------------------------------------------------------------------------------------------------------
        public DataSet _ListadoHrAnuladas(int pper_codigo, int pper_codigo_responsable)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_Hojas_Ruta_Anuladas_X_Bandeja", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                //Datos del formulario                    
                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = pper_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "datosHRAnulados");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosElementos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//----------------------------------------------------------------------------------------------------------------------
        public DataSet _cargar_contralor()
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_NombreContralor", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "cbocontralor");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosElementos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//----------------------------------------------------------------------------------------------------------------------
        public SqlDataReader _Modificar_PQ(int CodigoHojaRuta, int PQ)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("upd_HojaRuta_define_PQ", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = CodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                SqlParameter Parameter_PQ = new SqlParameter("@PQ", SqlDbType.Int, 11);
                Parameter_PQ.Value = PQ;
                Parameter_PQ.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_PQ);


                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_PQ::Produjo un error.", MiExcepcion);
                }
            }
//----------------------------------------------------------------------------------------------------------------------
        public DataSet _BusquedaHR_por_pq(DateTime pFechaRegistro_desde, DateTime pFechaRegistro_hasta, int pper_codigo, int pper_codigo_responsable, int pCodigoRol)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_BusquedaHojaRuta_por_pq", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                //Datos del formulario                    
                SqlParameter Parameter_Fecha_desde = new SqlParameter("@FechaRegistro_desde", SqlDbType.Date);
                Parameter_Fecha_desde.Value = pFechaRegistro_desde;
                Parameter_Fecha_desde.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Fecha_desde);

                SqlParameter Parameter_Fecha_hasta = new SqlParameter("@FechaRegistro_hasta", SqlDbType.Date);
                Parameter_Fecha_hasta.Value = pFechaRegistro_hasta;
                Parameter_Fecha_hasta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Fecha_hasta);

                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = pper_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlParameter Parameter_rol_codigo = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
                Parameter_rol_codigo.Value = pCodigoRol;
                Parameter_rol_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_rol_codigo);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    //Retorno = da.Fill(ds, "DataGrid_busqueda");
                    Retorno = da.Fill(ds, "DataGrid_busqueda");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//----------------------------------------------------------------------------------------------------------------------
        public SqlDataReader _RechazoHR(int pCodigoHojaRuta, int pCodigoEstado, int pper_codigo_responsable)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("ins_upd_HojaRutaEstado", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
                Parameter_CodigoEstado.Value = pCodigoEstado;
                Parameter_CodigoEstado.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoEstado);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
                }
            }
//----------------------------------------------------------------------------------------------------------------------
        public DataSet _ObtenerSolicitudOficioSinDerivar(string CodigoSistema, int per_codigo_responsable)
            {             
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("sel_BandejaSinDerivar", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoSistema = new SqlParameter("@CodigoSistema", SqlDbType.VarChar,15);
                Parameter_CodigoSistema.Value = CodigoSistema;
                Parameter_CodigoSistema.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoSistema);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "foundEntidades");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//----------------------------------------------------------------------------------------------------------------------
        public SqlDataReader _AdicionarOfi(string Referencia, int per_codigo_remitente, int TipoDestino, string NombrePersona, string cargo_transcrito, int CodigoCargoPE, int CodigoMovimiento, string entidad_transcrito, int CodigoO, int uni_codigo_destino, int per_codigo_destino, int per_codigo_responsable)
            {
                SqlDataReader Lector;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("ins_CorrelativoDocumento_oficio", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 650);
                Parameter_Referencia.Value = Referencia;
                Parameter_Referencia.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Referencia);

                SqlParameter Parameter_per_codigo_remitente = new SqlParameter("@per_codigo_remitente", SqlDbType.Int, 11);
                Parameter_per_codigo_remitente.Value = per_codigo_remitente;
                Parameter_per_codigo_remitente.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_remitente);

                SqlParameter Parameter_TipoDestino = new SqlParameter("@TipoDestino", SqlDbType.Int, 11);
                Parameter_TipoDestino.Value = TipoDestino;
                Parameter_TipoDestino.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_TipoDestino);

                SqlParameter Parameter_NombrePersona = new SqlParameter("@NombrePersona", SqlDbType.VarChar, 100);
                Parameter_NombrePersona.Value = NombrePersona;
                Parameter_NombrePersona.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_NombrePersona);

                SqlParameter Parameter_cargo_transcrito = new SqlParameter("@cargo_transcrito", SqlDbType.VarChar, 60);
                Parameter_cargo_transcrito.Value = cargo_transcrito;
                Parameter_cargo_transcrito.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_cargo_transcrito);

                SqlParameter Parameter_per_codigo_CodigoCargoPE = new SqlParameter("@CodigoCargoPE", SqlDbType.Int, 11);
                Parameter_per_codigo_CodigoCargoPE.Value = CodigoCargoPE;
                Parameter_per_codigo_CodigoCargoPE.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_CodigoCargoPE);

                SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
                Parameter_CodigoMovimiento.Value = CodigoMovimiento;
                Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

                SqlParameter Parameter_entidad_transcrito = new SqlParameter("@entidad_transcrito", SqlDbType.VarChar, 60);
                Parameter_entidad_transcrito.Value = entidad_transcrito;
                Parameter_entidad_transcrito.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_entidad_transcrito);

                SqlParameter Parameter_CodigoO = new SqlParameter("@CodigoO", SqlDbType.Int, 11);
                Parameter_CodigoO.Value = CodigoO;
                Parameter_CodigoO.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoO);

                SqlParameter Parameter_uni_codigo_destino = new SqlParameter("@uni_codigo_destino", SqlDbType.Int, 11);
                Parameter_uni_codigo_destino.Value = uni_codigo_destino;
                Parameter_uni_codigo_destino.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_uni_codigo_destino);

                SqlParameter Parameter_per_codigo_destino = new SqlParameter("@per_codigo_destino", SqlDbType.Int, 11);
                Parameter_per_codigo_destino.Value = per_codigo_destino;
                Parameter_per_codigo_destino.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_destino);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);
                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
                }
            }
//--------------------------------------------------------------------------------------------------------------------------------------------------------
        public SqlDataReader _AdicionarOfi_Adm(string Referencia, int per_codigo_remitente, int TipoDestino, string NombrePersona, string cargo_transcrito, int CodigoCargoPE, int uni_codigo_destino, int per_codigo_destino,int CodigoHojaRuta, int per_codigo_responsable)
        {
            SqlDataReader Lector;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_CorrelativoDocumento_oficio_admin", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 650);
            Parameter_Referencia.Value = Referencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_per_codigo_remitente = new SqlParameter("@per_codigo_remitente", SqlDbType.Int, 11);
            Parameter_per_codigo_remitente.Value = per_codigo_remitente;
            Parameter_per_codigo_remitente.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_remitente);

            SqlParameter Parameter_TipoDestino = new SqlParameter("@TipoDestino", SqlDbType.Int, 11);
            Parameter_TipoDestino.Value = TipoDestino;
            Parameter_TipoDestino.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_TipoDestino);

            SqlParameter Parameter_NombrePersona = new SqlParameter("@NombrePersona", SqlDbType.VarChar, 100);
            Parameter_NombrePersona.Value = NombrePersona;
            Parameter_NombrePersona.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombrePersona);

            SqlParameter Parameter_cargo_transcrito = new SqlParameter("@cargo_transcrito", SqlDbType.VarChar, 60);
            Parameter_cargo_transcrito.Value = cargo_transcrito;
            Parameter_cargo_transcrito.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_cargo_transcrito);

            SqlParameter Parameter_per_codigo_CodigoCargoPE = new SqlParameter("@CodigoCargoPE", SqlDbType.Int, 11);
            Parameter_per_codigo_CodigoCargoPE.Value = CodigoCargoPE;
            Parameter_per_codigo_CodigoCargoPE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_CodigoCargoPE);

            SqlParameter Parameter_uni_codigo_destino = new SqlParameter("@uni_codigo_destino", SqlDbType.Int, 11);
            Parameter_uni_codigo_destino.Value = uni_codigo_destino;
            Parameter_uni_codigo_destino.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_uni_codigo_destino);

            SqlParameter Parameter_per_codigo_destino = new SqlParameter("@per_codigo_destino", SqlDbType.Int, 11);
            Parameter_per_codigo_destino.Value = per_codigo_destino;
            Parameter_per_codigo_destino.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_destino);

            SqlParameter Parameter_per_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_per_CodigoHojaRuta.Value = CodigoHojaRuta;
            Parameter_per_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_CodigoHojaRuta);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = per_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }
        }
//-----------------------------------------------------------------------------------------------
        public DataSet _ObtenerSolicitudOficioAdmin(int per_codigo, string NumeroCorrelativo)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_CorrelativoDocumento_oficios_admin", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            //parametros de salida
            /*     SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                  SqlCom.Parameters.Add(Parameter_CodigoDeError);*/



            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = per_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlParameter Parameter_NumeroCorrelativo = new SqlParameter("@NumeroCorrelativo", SqlDbType.VarChar, 150);
            Parameter_NumeroCorrelativo.Value = NumeroCorrelativo;
            Parameter_NumeroCorrelativo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NumeroCorrelativo);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "RadGridOFICIO");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosElementos::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//-----------------------------------------------------------------------------------------------
        public DataSet _ImprimirCabecera(int pCodigoHojaRuta, int pCodigoEjemplar)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_CabeceraHojaRuta", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
                Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
                Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "lista");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosElementos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-----------------------------------------------------------------------------------------------
        public DataSet _ObtenerBandejaArchivados(string Correlativo, int per_codigo, int per_codigo_responsable, int CodigoRol)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_BusquedaHojaRuta_Arch", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Correlativo = new SqlParameter("@CodigoSistema", SqlDbType.VarChar, 150);
                Parameter_Correlativo.Value = Correlativo;
                Parameter_Correlativo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Correlativo);


                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = per_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
                Parameter_CodigoRol.Value = CodigoRol;
                Parameter_CodigoRol.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoRol);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "listaArchivados");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosElementos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-----------------------------------------------------------------------------------------------
        public DataSet _ObtenerCopiasEjemplar(int pCodigoHojaRuta, int pCodigoEjemplar, int pCodigoMovimiento)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_copias_de_ejemplar", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
                Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
                Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

                SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
                Parameter_CodigoMovimiento.Value = pCodigoMovimiento;
                Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "lista");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosElementos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-----------------------------------------------------------------------------------------------
        public DataSet _ObtenerGruposEjemplar(int pCodigoHojaRuta, int pCodigoEjemplar, int pCodigoMovimiento, int pCodigoGrupo)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_grupo_de_ejemplar", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
                Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
                Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

                SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
                Parameter_CodigoMovimiento.Value = pCodigoMovimiento;
                Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

                SqlParameter Parameter_CodigoGrupo = new SqlParameter("@CodigoGrupo", SqlDbType.Int, 11);
                Parameter_CodigoGrupo.Value = pCodigoGrupo;
                Parameter_CodigoGrupo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoGrupo);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "lista");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosElementos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//----------------------------------------------------------------------------------------------------------------------------------
        public DataSet _Busqueda_Especifica_HR(
                                        int uni_codigo, 
                                        int CodigoFuncionario, 
                                        int CodigoTipoHojaRuta, 
                                        int CodigoEstado, 
                                        int per_codigo, 
                                        int per_codigo_responsable, 
                                        int CodigoRol)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_BusquedaHojaRuta_esp", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                //Datos del formulario
                SqlParameter Parameter_uni_codigo = new SqlParameter("@uni_codigo", SqlDbType.Int, 11);
                Parameter_uni_codigo.Value = uni_codigo;
                Parameter_uni_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_uni_codigo);

                SqlParameter Parameter_CodigoFuncionario = new SqlParameter("@CodigoFuncionario", SqlDbType.Int, 11);
                Parameter_CodigoFuncionario.Value = CodigoFuncionario;
                Parameter_CodigoFuncionario.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoFuncionario);

                SqlParameter Parameter_CodigoTipoHojaRuta = new SqlParameter("@CodigoTipoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoTipoHojaRuta.Value = CodigoTipoHojaRuta;
                Parameter_CodigoTipoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoTipoHojaRuta);

                SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
                Parameter_CodigoEstado.Value = CodigoEstado;
                Parameter_CodigoEstado.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoEstado);

                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = per_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
                Parameter_CodigoRol.Value = CodigoRol;
                Parameter_CodigoRol.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoRol);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_busqueda");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//----------------------------------------------------------------------------------------------------------------------------------
        public SqlDataReader _DeshacerGrupo(int CodigoEjemplar, int CodigoGrupo, int per_codigo_responsable)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("upd_ins_Desacer_Ejemplar_Grupo", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
                Parameter_CodigoEjemplar.Value = CodigoEjemplar;
                Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

                SqlParameter Parameter_CodigoGrupo = new SqlParameter("@CodigoGrupo", SqlDbType.Int, 11);
                Parameter_CodigoGrupo.Value = CodigoGrupo;
                Parameter_CodigoGrupo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoGrupo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
                }
            }
//-----------------------------------------------------------------------------------------------
        public DataSet _ObtenerSolicitudOficio(int per_codigo, string NumeroCorrelativo)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_CorrelativoDocumento_oficios", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                //parametros de salida
                /*     SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 4);
                    Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                      SqlCom.Parameters.Add(Parameter_CodigoDeError);*/



                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = per_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_NumeroCorrelativo = new SqlParameter("@NumeroCorrelativo", SqlDbType.VarChar, 150);
                Parameter_NumeroCorrelativo.Value = NumeroCorrelativo;
                Parameter_NumeroCorrelativo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_NumeroCorrelativo);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "RadGridOFICIO");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosElementos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-----------------------------------------------------------------------------------------------
        public SqlDataReader _ModificarCambiosdeEstado(int CodigoEstado, int CodigoEjemplar, int CodigoMovimiento, int CodPersonaMovimiento, int pper_codigo, int pper_codigo_responsable)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("upd_CambiosEstadoHojaRuta", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
                Parameter_CodigoEstado.Value = CodigoEstado;
                Parameter_CodigoEstado.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoEstado);

                SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
                Parameter_CodigoEjemplar.Value = CodigoEjemplar;
                Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

                SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int,11);
                Parameter_CodigoMovimiento.Value = CodigoMovimiento;
                Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

                SqlParameter Parameter_CodPersonaMovimiento = new SqlParameter("@CodPersonaMovimiento", SqlDbType.Int, 11);
                Parameter_CodPersonaMovimiento.Value = CodPersonaMovimiento;
                Parameter_CodPersonaMovimiento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodPersonaMovimiento);

                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = pper_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);
                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Actualizar::Produjo un error.", MiExcepcion);
                }
            }
//-------------------------------------------------------------------------------------------
        public SqlDataReader _AnularCorrelativoList(int CodigoDocumento, int per_codigo_responsable)
            {
                SqlDataReader Lector;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("ins_AnularCorrelativoDocumento", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento ", SqlDbType.Int, 11);
                Parameter_CodigoDocumento.Value = CodigoDocumento;
                Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoDocumento);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);
                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Anular correltivo produjo un error.", MiExcepcion);
                }
            
            }
//-----------------------------------------------------------------------------------------------------------------
        public SqlDataReader _ConfirmarDerivacionHR(int CodPersonaMovimiento, int per_codigo, int per_codigo_responsable)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("upd_ConfirmarDerivacionHR", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodPersonaMovimiento = new SqlParameter("@CodPersonaMovimiento", SqlDbType.Int, 11);
                Parameter_CodPersonaMovimiento.Value = CodPersonaMovimiento;
                Parameter_CodPersonaMovimiento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodPersonaMovimiento);

                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = per_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Insertar Copia de Hoja Ruta::Produjo un error.", MiExcepcion);
                }
            }
//-----------------------------------------------------------------------------------------------
        public DataSet _ElementosporConfirmar(int per_codigo ,string  Correlativo, int per_codigo_responsable)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_BandejaPorConfirmar", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                //parametros de salida
                /*     SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 4);
                    Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                      SqlCom.Parameters.Add(Parameter_CodigoDeError);*/



                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int , 11);
                Parameter_per_codigo.Value = per_codigo ;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_Correlativo = new SqlParameter("@CodigoSistema", SqlDbType.VarChar, 150);
                Parameter_Correlativo.Value = Correlativo;
                Parameter_Correlativo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Correlativo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "RadGridELE");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosElementos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//---------------------------------------------------------------------------------------------------
        public DataSet _ObtenerCorrespondencia(string pCodigoUsuario, int pCriterio, string pBusqueda, int pCodigoRol, int pCodigoResidencia)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_Correspondencia", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlParameter Parameter_Criterio = new SqlParameter("@Criterio", SqlDbType.Int, 1);
            Parameter_Criterio.Value = pCriterio;
            Parameter_Criterio.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Criterio);

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
            Parameter_CodigoRol.Value = pCodigoRol;
            Parameter_CodigoRol.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoRol);

            //SqlParameter Parameter_CodigoResidencia = new SqlParameter("@CodigoResidencia", SqlDbType.Int, 11);
            //Parameter_CodigoResidencia.Value = pCodigoResidencia;
            //Parameter_CodigoResidencia.Direction = ParameterDirection.Input;
            //SqlCom.Parameters.Add(Parameter_CodigoResidencia);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_corres");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _AdicionarCorrespondencia(
            string pNombrePersnaExterna, 
            string pCargoTranscrito, 
            int pCodigoCargo, 
            int pPer_codigo_remitente, 
            int pCodigoO_entidad, 
            string pReferencia, 
            string pProcedencia, 
            int pCodigoTipoHoja, 
            string pFechaDocumento,
            string pFechaRecepcion, 
            string pCodigoCorrespondencia, 
            int pPQ, 
            string pCITE, 
            int pTipoCorrespondencia, 
            int cper_codigo)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_HojaRutaCorrespondencia", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_nombrePersona = new SqlParameter("@nombrePersonaExterna", SqlDbType.VarChar, 600);
            Parameter_nombrePersona.Value = pNombrePersnaExterna;
            Parameter_nombrePersona.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_nombrePersona);

            SqlParameter Parameter_cargoTranscrito = new SqlParameter("@cargoTranscrito", SqlDbType.VarChar, 600);
            Parameter_cargoTranscrito.Value = pCargoTranscrito;
            Parameter_cargoTranscrito.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_cargoTranscrito);

            SqlParameter Parameter_CodigoCargoPE = new SqlParameter("@CodigoCargoPE", SqlDbType.Int, 11);
            Parameter_CodigoCargoPE.Value = pCodigoCargo;
            Parameter_CodigoCargoPE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoCargoPE);

            SqlParameter Parameter_CodigoO = new SqlParameter("@CodigoO", SqlDbType.Int, 11);
            Parameter_CodigoO.Value = pCodigoO_entidad;
            Parameter_CodigoO.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoO);

            SqlParameter Parameter_per_codigo_remitente = new SqlParameter("@per_codigo_remitente", SqlDbType.Int, 11);
            Parameter_per_codigo_remitente.Value = pPer_codigo_remitente;
            Parameter_per_codigo_remitente.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_remitente);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 600);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 600);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            SqlParameter Parameter_CodigoTipoHoja = new SqlParameter("@CodigoTipoHoja", SqlDbType.Int, 11);
            Parameter_CodigoTipoHoja.Value = pCodigoTipoHoja;
            Parameter_CodigoTipoHoja.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoHoja);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumento", SqlDbType.Date, 30);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_FechaRecepcion = new SqlParameter("@FechaRecepcion", SqlDbType.DateTime, 30);
            Parameter_FechaRecepcion.Value = pFechaRecepcion;
            Parameter_FechaRecepcion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRecepcion);

            SqlParameter Parameter_CodigoCorrespondencia = new SqlParameter("@CodigoCorrespondencia", SqlDbType.VarChar, 100);
            Parameter_CodigoCorrespondencia.Value = pCodigoCorrespondencia;
            Parameter_CodigoCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoCorrespondencia);

            SqlParameter Parameter_PQ = new SqlParameter("@PQ", SqlDbType.Int, 5);
            Parameter_PQ.Value = pPQ;
            Parameter_PQ.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_PQ);

            SqlParameter Parameter_CITE = new SqlParameter("@CITE", SqlDbType.VarChar, 250);
            Parameter_CITE.Value = pCITE;
            Parameter_CITE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CITE);

            SqlParameter Parameter_TipoCorrespondencia = new SqlParameter("@tipo_correspondencia", SqlDbType.Int, 5);
            Parameter_TipoCorrespondencia.Value = pTipoCorrespondencia;
            Parameter_TipoCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_TipoCorrespondencia);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = cper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _AdicionarHojaRutaInterna(
            string pReferencia, 
            string pProcedencia, 
            string pComentarios, 
            string xml_instrucciones, 
            string xml_remitentes, 
            string xml_destinatarios, 
            int cper_codigo, 
            int cper_codigo_responsable, 
            string xml_correlativos,              
            int pConCertificacionPresupuestaria)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_HojaRutaInterna", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 600);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 600);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            SqlParameter Parameter_Comentarios = new SqlParameter("@Comentarios", SqlDbType.VarChar, 250);
            Parameter_Comentarios.Value = pComentarios;
            Parameter_Comentarios.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Comentarios);

            SqlParameter Parameter_xml_instrucciones = new SqlParameter("@xml_instrucciones", SqlDbType.Xml, 1000);
            Parameter_xml_instrucciones.Value = xml_instrucciones;
            Parameter_xml_instrucciones.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_xml_instrucciones);

            SqlParameter Parameter_xml_remitentes = new SqlParameter("@xml_remitentes", SqlDbType.Xml, 1000);
            Parameter_xml_remitentes.Value = xml_remitentes;
            Parameter_xml_remitentes.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_xml_remitentes);

            SqlParameter Parameter_xml_destinatarios = new SqlParameter("@xml_destinatarios", SqlDbType.Xml, 1000);
            Parameter_xml_destinatarios.Value = xml_destinatarios;
            Parameter_xml_destinatarios.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_xml_destinatarios);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = cper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = cper_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

            SqlParameter Parameter_xml_correlativos = new SqlParameter("@correlativos_xml", SqlDbType.Xml, 1000);
            Parameter_xml_correlativos.Value = xml_correlativos;
            Parameter_xml_correlativos.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_xml_correlativos);
            // agregados  string pFechaDerivacion, int pConCertificacionPresupuestari

            SqlParameter Parameter_ConCertificacionPresupuestaria = new SqlParameter("@con_certificacion_presupuestaria", SqlDbType.Int, 11);
            Parameter_ConCertificacionPresupuestaria.Value = pConCertificacionPresupuestaria;
            Parameter_ConCertificacionPresupuestaria.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_ConCertificacionPresupuestaria);
            // aumentar correlativos                 
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
       //@Ever Ivan - 2015 actualiado
        public SqlDataReader _ObtenerCorrespondenciaPorID(int pCodigoHojaRuta, int pCodigoEjemplar)
        {
            SqlDataReader Lector = null;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_CorrespondenciaPorId", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
            Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_ObtenerCorrespondenciaPorID::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _ModificarCorrespondencia( int pCodigoHojaRuta,string pNombrePersnaExterna, string pCargoTranscrito, int pCodigoCargo, int pPer_codigo_remitente, int pCodigoO_entidad, string pReferencia, string pProcedencia, int pCodigoTipoHoja, string pFechaDocumento, string pFechaRecepcion, string pCodigoCorrespondencia, int pPQ, string pCITE, int pTipoCorrespondencia, int cper_codigo, int cCodigoRol)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_HojaRutaCorrespondencia", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_nombrePersona = new SqlParameter("@nombrePersonaExterna", SqlDbType.VarChar, 600);
            Parameter_nombrePersona.Value = pNombrePersnaExterna;
            Parameter_nombrePersona.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_nombrePersona);

            SqlParameter Parameter_cargoTranscrito = new SqlParameter("@cargoTranscrito", SqlDbType.VarChar, 600);
            Parameter_cargoTranscrito.Value = pCargoTranscrito;
            Parameter_cargoTranscrito.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_cargoTranscrito);

            SqlParameter Parameter_CodigoCargoPE = new SqlParameter("@CodigoCargoPE", SqlDbType.Int, 11);
            Parameter_CodigoCargoPE.Value = pCodigoCargo;
            Parameter_CodigoCargoPE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoCargoPE);

            SqlParameter Parameter_CodigoO = new SqlParameter("@CodigoO", SqlDbType.Int, 11);
            Parameter_CodigoO.Value = pCodigoO_entidad;
            Parameter_CodigoO.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoO);

            SqlParameter Parameter_per_codigo_remitente = new SqlParameter("@per_codigo_remitente", SqlDbType.Int, 11);
            Parameter_per_codigo_remitente.Value = pPer_codigo_remitente;
            Parameter_per_codigo_remitente.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_remitente);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 600);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 600);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            SqlParameter Parameter_CodigoTipoHoja = new SqlParameter("@CodigoTipoHoja", SqlDbType.Int, 11);
            Parameter_CodigoTipoHoja.Value = pCodigoTipoHoja;
            Parameter_CodigoTipoHoja.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoHoja);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumento", SqlDbType.Date, 30);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_FechaRecepcion = new SqlParameter("@FechaRecepcion", SqlDbType.DateTime, 30);
            Parameter_FechaRecepcion.Value = pFechaRecepcion;
            Parameter_FechaRecepcion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRecepcion);

            SqlParameter Parameter_CodigoCorrespondencia = new SqlParameter("@CodigoCorrespondencia", SqlDbType.VarChar, 100);
            Parameter_CodigoCorrespondencia.Value = pCodigoCorrespondencia;
            Parameter_CodigoCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoCorrespondencia);

            SqlParameter Parameter_PQ = new SqlParameter("@PQ", SqlDbType.Int, 5);
            Parameter_PQ.Value = pPQ;
            Parameter_PQ.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_PQ);

            SqlParameter Parameter_CITE = new SqlParameter("@CITE", SqlDbType.VarChar, 250);
            Parameter_CITE.Value = pCITE;
            Parameter_CITE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CITE);

            SqlParameter Parameter_TipoCorrespondencia = new SqlParameter("@tipo_correspondencia", SqlDbType.Int, 5);
            Parameter_TipoCorrespondencia.Value = pTipoCorrespondencia;
            Parameter_TipoCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_TipoCorrespondencia);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = cper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
            Parameter_CodigoRol.Value = cCodigoRol;
            Parameter_CodigoRol.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoRol);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _CambioEstadoHojaRuta(int pCodigoHojaRuta, int pCodigoEstado)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("upd_CambioEstadoHojaRuta", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoEstado.Value = pCodigoHojaRuta;
            Parameter_CodigoEstado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEstado);

            SqlParameter Parameter_Valor = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
            Parameter_Valor.Value = pCodigoEstado;
            Parameter_Valor.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Valor);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet _BusquedaRegistroCorrespondencia(string pFechaRegistro, string pCorrelativoCorrespondenciaIni, string pCorrelativoCorrespondenciaFin , int pCodigoUsuario)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_HojasRutasRegistradasPorCorrespondencia", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_FechaRegistro = new SqlParameter("@FechaRegistro", SqlDbType.Date);
            Parameter_FechaRegistro.Value = pFechaRegistro;
            Parameter_FechaRegistro.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRegistro);

            SqlParameter Parameter_CorrelativoCorrespondenciaIni = new SqlParameter("@CorrelativoCorrespondenciaIni", SqlDbType.Int, 11);
            Parameter_CorrelativoCorrespondenciaIni.Value = pCorrelativoCorrespondenciaIni;
            Parameter_CorrelativoCorrespondenciaIni.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CorrelativoCorrespondenciaIni);

            SqlParameter Parameter_CorrelativoCorrespondenciaFin = new SqlParameter("@CorrelativoCorrespondenciaFin", SqlDbType.Int, 11);
            Parameter_CorrelativoCorrespondenciaFin.Value = pCorrelativoCorrespondenciaFin;
            Parameter_CorrelativoCorrespondenciaFin.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CorrelativoCorrespondenciaFin);

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoUsuario", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);


            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_busqueda");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet _ObtenerBandejaEntrada(int pCodigoUsuario, string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_BandejaEntrada", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlParameter Parameter_Busqueda = new SqlParameter("@CodigoSistema", SqlDbType.VarChar, 150);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_hojaR");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet _ObtenerBandejaEnviados(int pCodigoUsuario, string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_BandejaEnviados", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlParameter Parameter_Busqueda = new SqlParameter("@CodigoSistema", SqlDbType.VarChar, 150);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_hojaR");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
 //--------------------------------------------------------------------------------------
        public SqlDataReader _CambiarDeEstadoHR(int pEstado, int pCodigoEjemplar, int pCodigoMovimiento, int pCodigoPersonaMovimiento, int pper_codigo, int pper_codigo_responsable)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("upd_CambiosEstadoHojaRuta", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
            Parameter_CodigoEstado.Value = pEstado;
            Parameter_CodigoEstado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEstado);

            SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
            Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

            SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
            Parameter_CodigoMovimiento.Value = pCodigoMovimiento;
            Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

            SqlParameter Parameter_CodPersonaMovimiento = new SqlParameter("@CodPersonaMovimiento", SqlDbType.Int, 11);
            Parameter_CodPersonaMovimiento.Value = pCodigoPersonaMovimiento;
            Parameter_CodPersonaMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodPersonaMovimiento);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

            
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------

        public DataSet _Detalle_hoja_de_Ruta2(int pCodigoEjemplar, int pCodigoMovimiento)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_provehido_ejemplar2", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_pCodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_pCodigoEjemplar.Value = pCodigoEjemplar;
            Parameter_pCodigoEjemplar.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_pCodigoEjemplar);

            SqlParameter Parameter_pCodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
            Parameter_pCodigoMovimiento.Value = pCodigoMovimiento;
            Parameter_pCodigoMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_pCodigoMovimiento);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "RadGridFlujo");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
        //-----------------------------------------------------------------------
        public DataSet _Detalle_hoja_de_Ruta(int CodigoHojaRuta)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_provehido_ejemplar", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = CodigoHojaRuta;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "RadGridFlujo");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet _Crear_Grupo_HR(int pCodigoUsuario, int pCodigoEjemplar )
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_Bandeja_para_agrupar", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;
            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pCodigoUsuario;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlCom.CommandType = CommandType.StoredProcedure;
            SqlParameter Parameter_pBusqueda = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_pBusqueda.Value = pCodigoEjemplar;
            Parameter_pBusqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_pBusqueda);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "RadGridGrupo");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }  
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _Insertar_CopiaHojaRuta(int CodigoHojaRuta,int CodigoEjemplar, int CodigoMovimiento, int CodiPersonaMovimiento, int pper_codigo, int per_codigo_responsable)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_copiar_ejemplar", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = CodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_CodigoEjemplar.Value = CodigoEjemplar;
            Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

            SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
            Parameter_CodigoMovimiento.Value = CodigoMovimiento;
            Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

            SqlParameter Parameter_Comentarios = new SqlParameter("@CodPersonaMovimiento", SqlDbType.Int, 11);
            Parameter_Comentarios.Value = CodiPersonaMovimiento;
            Parameter_Comentarios.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Comentarios);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);
            
            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = per_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);



           try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Insertar Copia de Hoja Ruta::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
// para el reporte general        
        public DataSet _BusquedaHRreporte(
                                   string FechaRegistro_desde,
                                   string FechaRegistro_hasta,
                                   int pres_codigo,
                                   string pCodigoTipoHojaRuta,
                                   string pProcedencia,
                                   string pReferencia,
                                   string pCodigoSistema,
                                   string pCorrelativoCorrespondencia,
                                   string pCodigoEstado,
                                   string pCite,
                                   int pPercodigo,
                                   int pPercodigoResposable,
                                   int pCodigoRol,            
                                   string pVarHrCon)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_BusquedaHojaRuta_gralReporte", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            //Datos del formulario                    
            SqlParameter Parameter_FechaRegistro_desde = new SqlParameter("@FechaRegistro_desde", SqlDbType.DateTime, 30);
            Parameter_FechaRegistro_desde.Value = FechaRegistro_desde;
            Parameter_FechaRegistro_desde.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRegistro_desde);

            SqlParameter Parameter_FechaRegistro_hasta = new SqlParameter("@FechaRegistro_hasta", SqlDbType.DateTime, 30);
            Parameter_FechaRegistro_hasta.Value = FechaRegistro_hasta;
            Parameter_FechaRegistro_hasta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRegistro_hasta);

            SqlParameter Parameter_res_codigo = new SqlParameter("@res_codigo", SqlDbType.Int, 60);
            Parameter_res_codigo.Value = pres_codigo;
            Parameter_res_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_res_codigo);

            SqlParameter Parameter_CodigoTipoHojaRuta = new SqlParameter("@CodigoTipoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoTipoHojaRuta.Value = pCodigoTipoHojaRuta;
            Parameter_CodigoTipoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoHojaRuta);

            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 600);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 600);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);
            
            SqlParameter Parameter_CodigoSistema = new SqlParameter("@CodigoSistema", SqlDbType.VarChar, 150);
            Parameter_CodigoSistema.Value = pCodigoSistema;
            Parameter_CodigoSistema.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSistema);

            SqlParameter Parameter_CorrelativoCorrespondencia = new SqlParameter("@CorrelativoCorrespondencia", SqlDbType.VarChar, 150);
            Parameter_CorrelativoCorrespondencia.Value = pCorrelativoCorrespondencia;
            Parameter_CorrelativoCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CorrelativoCorrespondencia);
            
            SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
            Parameter_CodigoEstado.Value = pCodigoEstado;
            Parameter_CodigoEstado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEstado);

            SqlParameter Parameter_CITE = new SqlParameter("@CITE", SqlDbType.VarChar, 50);
            Parameter_CITE.Value = pCite;
            Parameter_CITE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CITE);

            SqlParameter Parameter_PerCodigo = new SqlParameter("@per_codigo", SqlDbType.Int, 60);
            Parameter_PerCodigo.Value = pPercodigo;
            Parameter_PerCodigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_PerCodigo);

            SqlParameter Parameter_PerCodigoResponsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 60);
            Parameter_PerCodigoResponsable.Value = pPercodigoResposable;
            Parameter_PerCodigoResponsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_PerCodigoResponsable);

            SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 60);
            Parameter_CodigoRol.Value = pCodigoRol;
            Parameter_CodigoRol.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoRol);            

            SqlParameter Parameter_pVarHrCon = new SqlParameter("@VarHrCon", SqlDbType.Int, 60);
            Parameter_pVarHrCon.Value = pVarHrCon;
            Parameter_pVarHrCon.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_pVarHrCon);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                //Retorno = da.Fill(ds, "DataGrid_busqueda");
                Retorno = da.Fill(ds, "DataGrid_busqueda_general");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
        
        
 
        public DataSet _BusquedaHR(
                                    string pProcedencia, 
                                    string pReferencia, 
                                    string FechaRegistro_desde, 
                                    string FechaRegistro_hasta, 
                                    string pCodigoSistema, 
                                    string pCorrelativoCorrespondencia, 
                                    string pCodigoTipoHojaRuta, 
                                    string pCodigoEstado, 
                                    string pCite, 
                                    int pPercodigo, 
                                    int pPercodigoResposable, 
                                    int pCodigoRol, 
                                    int pres_codigo,
                                    string pVarHrCon)    
    {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);            
            SqlCommand SqlCom = new SqlCommand("sel_BusquedaHojaRuta_gral", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;
            
            //Datos del formulario                    
            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 600);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 600);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_FechaRegistro_desde = new SqlParameter("@FechaRegistro_desde", SqlDbType.DateTime, 30);
            Parameter_FechaRegistro_desde.Value = FechaRegistro_desde;
            Parameter_FechaRegistro_desde.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRegistro_desde);

            SqlParameter Parameter_FechaRegistro_hasta = new SqlParameter("@FechaRegistro_hasta", SqlDbType.DateTime, 30);
            Parameter_FechaRegistro_hasta.Value = FechaRegistro_hasta;
            Parameter_FechaRegistro_hasta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRegistro_hasta);

            SqlParameter Parameter_CodigoSistema = new SqlParameter("@CodigoSistema", SqlDbType.VarChar, 150);
            Parameter_CodigoSistema.Value = pCodigoSistema;
            Parameter_CodigoSistema.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSistema);

            SqlParameter Parameter_CorrelativoCorrespondencia = new SqlParameter("@CorrelativoCorrespondencia", SqlDbType.VarChar, 150);
            Parameter_CorrelativoCorrespondencia.Value = pCorrelativoCorrespondencia;
            Parameter_CorrelativoCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CorrelativoCorrespondencia);
   
            SqlParameter Parameter_CodigoTipoHojaRuta = new SqlParameter("@CodigoTipoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoTipoHojaRuta.Value = pCodigoTipoHojaRuta;
            Parameter_CodigoTipoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoHojaRuta);

            SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
            Parameter_CodigoEstado.Value = pCodigoEstado;
            Parameter_CodigoEstado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEstado);
              
            SqlParameter Parameter_CITE = new SqlParameter("@CITE", SqlDbType.VarChar, 50);
            Parameter_CITE.Value = pCite;
            Parameter_CITE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CITE);

            SqlParameter Parameter_PerCodigo = new SqlParameter("@per_codigo", SqlDbType.Int, 60);
            Parameter_PerCodigo.Value = pPercodigo;
            Parameter_PerCodigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_PerCodigo);

            SqlParameter Parameter_PerCodigoResponsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 60);
            Parameter_PerCodigoResponsable.Value = pPercodigoResposable;
            Parameter_PerCodigoResponsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_PerCodigoResponsable);

            SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 60);
            Parameter_CodigoRol.Value = pCodigoRol;
            Parameter_CodigoRol.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoRol);

            SqlParameter Parameter_res_codigo = new SqlParameter("@res_codigo", SqlDbType.Int, 60);
            Parameter_res_codigo.Value = pres_codigo;
            Parameter_res_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_res_codigo);
                                         
            SqlParameter Parameter_pVarHrCon = new SqlParameter("@VarHrCon", SqlDbType.Int, 60);
            Parameter_pVarHrCon.Value = pVarHrCon;
            Parameter_pVarHrCon.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_pVarHrCon);
                        
            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                //Retorno = da.Fill(ds, "DataGrid_busqueda");
                Retorno = da.Fill(ds, "DataGrid_busqueda_general");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------
        #endregion
    }
}
