﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class PersonaNaturalExterna
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public PersonaNaturalExterna()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _CodigoPersonaExterna { get; set; }
            public string _Nombres { get; set; }    
            public string _DocIdentificacion { get; set; }
            public string _CI { get; set; }
            public string _Fono { get; set; }
            public int _Habilitado { get; set; }
            public string _Apellidos { get; set; }
            public string _NombreCompleto { get; set; }    

        #endregion
        #region "funciones publicas"
//---------------------------------------------------------------------------------------------------
        public DataSet BuscarPersona(int pCriterio ,string pBusqueda )
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_BuscarPersonaExterna", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Criterio = new SqlParameter("@Criterio", SqlDbType.Int, 4);
            Parameter_Criterio.Value = pCriterio;
            Parameter_Criterio.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Criterio);

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_perExterna");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet ObtenerTodasLasPersonas(int pCriterio, string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_PersonasExternas", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Criterio = new SqlParameter("@Criterio", SqlDbType.Int, 11);
            Parameter_Criterio.Value = pCriterio;
            Parameter_Criterio.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Criterio);

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_personas");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool Adicionar(string pNombreCompleto, string pCI, string pFono, int pHabilitado, string pApellidos)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_PersonaExterna", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_NombreCompleto = new SqlParameter("@NombreCompleto", SqlDbType.VarChar, 200);
            Parameter_NombreCompleto.Value = pNombreCompleto;
            Parameter_NombreCompleto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombreCompleto);

            SqlParameter Parameter_CI = new SqlParameter("@CI", SqlDbType.VarChar, 50);
            Parameter_CI.Value = pCI;
            Parameter_CI.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CI);

            SqlParameter Parameter_Fono = new SqlParameter("@Fono", SqlDbType.VarChar, 100);
            Parameter_Fono.Value = pFono;
            Parameter_Fono.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Fono);

            SqlParameter Parameter_Habilitado = new SqlParameter("@Habilitado", SqlDbType.Int, 2);
            Parameter_Habilitado.Value = pHabilitado;
            Parameter_Habilitado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Habilitado);

            SqlParameter Parameter_Apellidos = new SqlParameter("@Apellidos", SqlDbType.VarChar, 200);
            Parameter_Apellidos.Value = pApellidos;
            Parameter_Apellidos.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Apellidos);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlParameter Parameter_CodigoPerIndep = new SqlParameter("@CodigoPersonaExterna", SqlDbType.Int, 11);
            Parameter_CodigoPerIndep.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoPerIndep);

            SqlParameter Parameter_NombresCompletos = new SqlParameter("@NombresCompletos", SqlDbType.VarChar, 250);
            Parameter_NombresCompletos.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_NombresCompletos);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoPersonaExterna = Convert.ToInt32(Parameter_CodigoPerIndep.Value);
                _NombreCompleto = Parameter_NombresCompletos.Value.ToString();

                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Usuario::Adicion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool Modificar(int pCodigoPersonaExterna, string pNombreCompleto, string pCI, string pFono, int pHabilitado)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_PersonaExterna", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoPersonaExterna = new SqlParameter("@CodigoPersonaExterna", SqlDbType.Int, 11);
            Parameter_CodigoPersonaExterna.Value = pCodigoPersonaExterna;
            Parameter_CodigoPersonaExterna.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoPersonaExterna);

            SqlParameter Parameter_NombreCompleto = new SqlParameter("@NombreCompleto", SqlDbType.VarChar, 650);
            Parameter_NombreCompleto.Value = pNombreCompleto;
            Parameter_NombreCompleto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombreCompleto);

            SqlParameter Parameter_CI = new SqlParameter("@CI", SqlDbType.VarChar, 200);
            Parameter_CI.Value = pCI;
            Parameter_CI.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CI);

            SqlParameter Parameter_Fono = new SqlParameter("@Fono", SqlDbType.VarChar, 200);
            Parameter_Fono.Value = pFono;
            Parameter_Fono.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Fono);

            SqlParameter Parameter_Habilitado = new SqlParameter("@Habilitado", SqlDbType.Int, 2);
            Parameter_Habilitado.Value = pHabilitado;
            Parameter_Habilitado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Habilitado);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();

                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("DocumentoRecibido::Modificacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//--------------------------------------------------------------------------------------------------
        public bool Eliminar(int pCodigoPersona)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_PersonaIndependiente", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoTipoHoja = new SqlParameter("@CodigoPersona", SqlDbType.Int, 11);
            Parameter_CodigoTipoHoja.Value = pCodigoPersona;
            Parameter_CodigoTipoHoja.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoHoja);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Rol::Eliminacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//--------------------------------------------------------------------------------------------------
        public bool ObtenerPersonaPorID(int pCodigoPersonaExterna)
        {
            SqlDataReader Lector = null;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("sel_PersonaExternaPorId", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoPersonaExterna = new SqlParameter("@CodigoPersonaExterna", SqlDbType.Int, 11);
            Parameter_CodigoPersonaExterna.Value = pCodigoPersonaExterna;
            Parameter_CodigoPersonaExterna.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoPersonaExterna);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();

                if (Lector.Read())
                {
                    _CodigoPersonaExterna = Convert.ToInt32(Lector["cCodigoPersonaExterna"]);
                    _Nombres = Lector["cNombreCompleto"].ToString();
                    _CI = Lector["cCI"].ToString();
                    _Fono = Lector["cFono"].ToString();
                    _Habilitado = Convert.ToInt32(Lector["cHabilitado"]);
                    _Apellidos = Lector["cApellidos"].ToString();
                    
                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);

                    Lector.Close();
                    SqlCon.Close();

                    if (_CodigoError == 0)
                    {
                        //    EstablecerPoliticaPrincipal(_CodigoUsuario, _LoginUsuario)
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    Lector.Close();
                    SqlCon.Close();
                    _CodigoError = -1;
                    return false;
                }
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("DocumentosRecibidos::RecuperarUsuarioPorCodigo::Produjo un error.", MiExcepcion);
            }
        }
//--------------------------------------------------------------------------------------------------
        public DataSet BuscarPersonaExterna(string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_BuscarPersonaNatExterna", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "foundPerExterna");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//--------------------------------------------------------------------------------------------------
        #endregion
    }
}
