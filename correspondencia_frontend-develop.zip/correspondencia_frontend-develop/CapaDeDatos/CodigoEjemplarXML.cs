﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//Ever Ivan
namespace CapaDeDatos
{
    public class CodigoEjemplarXML
    {
        public int CodigoEjemplar
        { get; set; }

        // Constructor
        public CodigoEjemplarXML()
        {
            this.CodigoEjemplar = 0;
        }

        public CodigoEjemplarXML(int CodigoEjemplar)
        {
            this.CodigoEjemplar = CodigoEjemplar;
        }

        // Casteador
        public static String CastearXml(List<CodigoEjemplarXML> lista)
        {
            return ConversionTipos.CastearListaObjetosParaXml(lista, typeof(CodigoEjemplarXML));
        }
    }
}
