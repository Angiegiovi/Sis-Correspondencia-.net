﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class BDEntidades
    {
        #region "Variables"

            private string _CadenaConexionBDEntidades;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public BDEntidades()
            {
                //_CadenaConexionBDEntidades = WebConfigurationManager.AppSettings["CadenaDeConexionEntidades"];
                //_CadenaConexionBDEntidades = WebConfigurationManager.ConnectionStrings["CadenaDeConexionEntidades"].ConnectionString;
                _CadenaConexionBDEntidades = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        
        #endregion
        #region "Propiedades publicas"

            public int _CodigoO { get; set; }
            public string _RazonSocialE { get; set; }
            public string _SiglaE { get; set; }

        #endregion
        #region "funciones publicas"
//---------------------------------------------------------------------------------------------------
        public DataSet ObtenerEntidadesPublicas(int pCriterio, string pBusqueda, int pTipoEntidad)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDEntidades);
               
                SqlCommand SqlCom = new SqlCommand("sel_EntidadesPublicas", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Criterio = new SqlParameter("@Criterio", SqlDbType.Int, 4);
                Parameter_Criterio.Value = pCriterio;
                Parameter_Criterio.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Criterio);

                SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
                Parameter_Busqueda.Value = pBusqueda;
                Parameter_Busqueda.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Busqueda);

                //parametros de salida
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_publicos");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//---------------------------------------------------------------------------------------------------
        public DataSet ObtenerEntidadesPrivadas(int pCriterio, string pBusqueda, int pTipoEntidad)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDEntidades);

                SqlCommand SqlCom = new SqlCommand("sel_EntidadesPrivadas", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Criterio = new SqlParameter("@Criterio", SqlDbType.Int, 4);
                Parameter_Criterio.Value = pCriterio;
                Parameter_Criterio.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Criterio);

                SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
                Parameter_Busqueda.Value = pBusqueda;
                Parameter_Busqueda.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Busqueda);

                //parametro de salida
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_privados");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//---------------------------------------------------------------------------------------------------
        public DataSet ObtenerEntidades(int pCriterio, string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDEntidades);

            SqlCommand SqlCom = new SqlCommand("sel_BusquedaEntidades", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Criterio = new SqlParameter("@Criterio", SqlDbType.Int, 4);
            Parameter_Criterio.Value = pCriterio;
            Parameter_Criterio.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Criterio);

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            //parametro de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_entidades");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet ObtenerComboEntidades( int pTipo)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDEntidades);
                SqlCommand SqlCom = new SqlCommand("sel_ComboEntidades", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Tipo = new SqlParameter("@Tipo", SqlDbType.Int, 4);
                Parameter_Tipo.Value = pTipo;
                Parameter_Tipo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Tipo);

                //parametros de salida
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "comboEntidades");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//---------------------------------------------------------------------------------------------------
        public bool ObtenerEntidadPorId(int pEntidad)
            {
                SqlDataReader Lector = null;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDEntidades);
                SqlCommand SqlCom = new SqlCommand("sel_EntidadporID", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Tipo = new SqlParameter("@CodigoEntidad", SqlDbType.Int, 11);
                Parameter_Tipo.Value = pEntidad;
                Parameter_Tipo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Tipo);

                //parametros de salida
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                //string ds ;
                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();

                    if (Lector.Read())
                    {
                       // _CodigoO = Convert.ToInt32(Lector["campo1"]);
                        _RazonSocialE = Lector["razonsocial"].ToString();
                        _SiglaE = Lector["sigla"].ToString();
                       
                        _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                        Lector.Close();
                        SqlCon.Close();

                        if (_CodigoError == 0)
                        {
                            //    EstablecerPoliticaPrincipal(_CodigoUsuario, _LoginUsuario)
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        Lector.Close();
                        SqlCon.Close();
                        _CodigoError = -1;
                        return false;
                    }
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//---------------------------------------------------------------------------------------------------
        public DataSet BuscarEntidades(string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDEntidades);

            SqlCommand SqlCom = new SqlCommand("sel_BuscarEntidades", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            //parametro de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "foundEntidades");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        #endregion
    }
        
}
