﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;


namespace CapaDeDatos
{
    public class RecepcionSalidasDocumento
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public RecepcionSalidasDocumento()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _recsal_Codigo { get; set; }
            public int _CodigoDocumento { get; set; }
            public int _recsal_CodPersonaCorresp { get; set; }
            public int _recsal_CodPersonaSolicita { get; set; }
            public DateTime _recsal_FechaRecepcionDocFisico { get; set; }
            public DateTime _recsal_FechaRecepcionCopiaDocFisico { get; set; }
            public int CodigoAdjunto { get; set; }
            public char _recsal_Respuesta { get; set; } 

        #endregion
        #region "funciones publicas"
//------------------------------------------------------------------------------------
  /*
     @tiposalida INT,
    @FechaComprovante_desde date,
    @FechaComprovante_hasta date,
    @NumeroOficio VARCHAR(250),
    @Tipenv_codigo INT,
    @numero_guia VARCHAR(20)         
             */
            //COMENTARIO:  buscar documentos de salida
            public DataSet BuscarDocumentoSalida(int pTipoSalida, string pFechaComprovante_desde, string pFechaComprovante_hasta, string pNumeroOficio, int pTipenv_codigo, string pNumero_guia)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_BusquedaOficio", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_TipoSalida = new SqlParameter("@tiposalida", SqlDbType.Int, 11);
                Parameter_TipoSalida.Value = pTipoSalida;
                Parameter_TipoSalida.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_TipoSalida);

                SqlParameter Parameter_FchCompr_desde = new SqlParameter("@FechaComprovante_desde", SqlDbType.DateTime, 30);
                Parameter_FchCompr_desde.Value = pFechaComprovante_desde;
                Parameter_FchCompr_desde.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_FchCompr_desde);

                SqlParameter Parameter_FchCompr_hasta = new SqlParameter("@FechaComprovante_hasta", SqlDbType.DateTime, 30);
                Parameter_FchCompr_hasta.Value = pFechaComprovante_hasta;
                Parameter_FchCompr_hasta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_FchCompr_hasta);

                SqlParameter Parameter_NumeroOficio = new SqlParameter("@NumeroOficio", SqlDbType.VarChar, 250);
                Parameter_NumeroOficio.Value = pNumeroOficio;
                Parameter_NumeroOficio.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_NumeroOficio);

                SqlParameter Parameter_Tipenv_codigo = new SqlParameter("@Tipenv_codigo", SqlDbType.Int, 100);
                Parameter_Tipenv_codigo.Value = pTipenv_codigo;
                Parameter_Tipenv_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Tipenv_codigo);

                SqlParameter Parameter_Numero_guia = new SqlParameter("@numero_guia", SqlDbType.VarChar, 250);
                Parameter_Numero_guia.Value = pNumero_guia;
                Parameter_Numero_guia.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Numero_guia);               

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_BuscarDocumentoSalida");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::BuscarDocumentoSalida::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }        
        
        //'@Ever Ivan - 2015 
        // COMENTARIO: REGISTRA LA FECHA DEL COMPROBANTE DEL DOCUMENTO DE SALIDA
            public SqlDataReader _Adicionar(int precsal_Codigo, string pRescal_FechaComprobante, int pCodigoDocumento, int pPer_codigo_responsable)
            {
                SqlDataReader Lector = null;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("ins_RecepcionSalidasDocumento", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_recsal_Codigo = new SqlParameter("@recsal_Codigo", SqlDbType.Int, 11);
                Parameter_recsal_Codigo.Value = precsal_Codigo;
                Parameter_recsal_Codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_recsal_Codigo);

                SqlParameter Parameter_CodPersonaCorrespondencia = new SqlParameter("@rescal_FechaComprobante", SqlDbType.DateTime, 11);
                Parameter_CodPersonaCorrespondencia.Value = pRescal_FechaComprobante;
                Parameter_CodPersonaCorrespondencia.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodPersonaCorrespondencia);

                SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
                Parameter_CodigoDocumento.Value = pCodigoDocumento;
                Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoDocumento);

                SqlParameter Parameter_pPer_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.VarChar, 30);
                Parameter_pPer_codigo_responsable.Value = pPer_codigo_responsable;
                Parameter_pPer_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pPer_codigo_responsable);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
                }
            }
//------------------------------------------------------------------------------------
            // @Ever Ivan - 2015 
            // Comentario: modificar el dato de la registro de comprobante
            public bool Modificar(int pCodigoSalida, int pCodPersonaCorrespondencia, int pCodPersonaSolicita, string pFechaRecepcionFisico, string pFechaRecepcionRespuesta,string pFechaEntregaExterna, int pCodigoAdjunto, char pSW)
            {
                int Resultado = 0;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("upd_RecepcionSalidasDocumento", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoSalida = new SqlParameter("@CodigoSalida", SqlDbType.Int, 11);
                Parameter_CodigoSalida.Value = pCodigoSalida;
                Parameter_CodigoSalida.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoSalida);

                SqlParameter Parameter_CodPersonaCorrespondencia = new SqlParameter("@CodPersonaCorrespondencia", SqlDbType.Int, 11);
                Parameter_CodPersonaCorrespondencia.Value = pCodPersonaCorrespondencia;
                Parameter_CodPersonaCorrespondencia.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodPersonaCorrespondencia);

                SqlParameter Parameter_CodPersonaSolicita = new SqlParameter("@CodPersonaSolicita", SqlDbType.Int, 11);
                Parameter_CodPersonaSolicita.Value = pCodPersonaSolicita;
                Parameter_CodPersonaSolicita.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodPersonaSolicita);

                SqlParameter Parameter_FechaRecepcionFisico = new SqlParameter("@FechaRecepcionFisico", SqlDbType.VarChar, 30);
                Parameter_FechaRecepcionFisico.Value = pFechaRecepcionFisico;
                Parameter_FechaRecepcionFisico.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_FechaRecepcionFisico);

                SqlParameter Parameter_FechaRecepcionRespuesta = new SqlParameter("@FechaRecepcionRespuesta", SqlDbType.VarChar, 30);
                Parameter_FechaRecepcionRespuesta.Value = pFechaRecepcionRespuesta;
                Parameter_FechaRecepcionRespuesta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_FechaRecepcionRespuesta);

                SqlParameter Parameter_FechaEntregaExterna = new SqlParameter("@FechaEntregaExterna", SqlDbType.VarChar, 30);
                Parameter_FechaEntregaExterna.Value = pFechaEntregaExterna;
                Parameter_FechaEntregaExterna.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_FechaEntregaExterna);

                SqlParameter Parameter_CodigoAdjunto = new SqlParameter("@CodigoAdjunto", SqlDbType.Int, 11);
                Parameter_CodigoAdjunto.Value = pCodigoAdjunto;
                Parameter_CodigoAdjunto.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoAdjunto);
                
                SqlParameter Parameter_sw = new SqlParameter("@SW", SqlDbType.Char, 1);
                Parameter_sw.Value = pSW;
                Parameter_sw.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_sw);

                //parametros de salida
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);

                try
                {
                    SqlCon.Open();
                    Resultado = SqlCom.ExecuteNonQuery();
                    //_CodigoDocumento = Convert.ToInt32(Parameter_CodigoDocumento.Value);
                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                }
                catch (Exception MiExcepcion)
                {
                    _CodigoError = -1;
                    throw new Exception("Contrato::Modificacion::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }

                if (_CodigoError == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
//------------------------------------------------------------------------------------
// INSERTA LOS DATOS PARA EL ENVIO DE UN OFICIO FUERA DE LA CGE    
// Ever Ivan Cordero Paco
            public SqlDataReader ins_EnvioOficios(int pRecsal_Codigo, string pRescal_FechaComprobante, int pTip_codigo, string pLug_destino_transcrito, int pRes_codigo, int pTipenv_codigo, string pDatenv_numero_guia, float pDatenv_peso_gramos, string pArcadj_RutaAdjunto, string pArcadj_NombreAdjunto, string pArcadj_ExtensionAdjunto, int pPer_codigo_responsable)
            {
                SqlDataReader Lector = null;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("ins_EnvioOficios", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_pRecsal_Codigo = new SqlParameter("@recsal_Codigo", SqlDbType.Int, 11);
                Parameter_pRecsal_Codigo.Value = pRecsal_Codigo;
                Parameter_pRecsal_Codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pRecsal_Codigo);

                SqlParameter Parameter_pRescal_FechaComprobante = new SqlParameter("@rescal_FechaComprobante", SqlDbType.DateTime, 11);
                Parameter_pRescal_FechaComprobante.Value = pRescal_FechaComprobante;
                Parameter_pRescal_FechaComprobante.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pRescal_FechaComprobante);

                SqlParameter Parameter_pTip_codigo = new SqlParameter("@tip_codigo", SqlDbType.Int, 11);
                Parameter_pTip_codigo.Value = pTip_codigo;
                Parameter_pTip_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pTip_codigo);

                SqlParameter Parameter_pLug_destino_transcrito = new SqlParameter("@lug_destino_transcrito", SqlDbType.VarChar, 60);
                Parameter_pLug_destino_transcrito.Value = pLug_destino_transcrito;
                Parameter_pLug_destino_transcrito.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pLug_destino_transcrito);

                SqlParameter Parameter_pRes_codigo = new SqlParameter("@res_codigo", SqlDbType.VarChar, 30);
                Parameter_pRes_codigo.Value = pRes_codigo;
                Parameter_pRes_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pRes_codigo);

                SqlParameter Parameter_pTipenv_codigo = new SqlParameter("@tipenv_codigo", SqlDbType.VarChar, 30);
                Parameter_pTipenv_codigo.Value = pTipenv_codigo;
                Parameter_pTipenv_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pTipenv_codigo);

                SqlParameter Parameter_pDatenv_numero_guia = new SqlParameter("@datenv_numero_guia", SqlDbType.VarChar, 30);
                Parameter_pDatenv_numero_guia.Value = pDatenv_numero_guia;
                Parameter_pDatenv_numero_guia.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pDatenv_numero_guia);

                SqlParameter Parameter_pDatenv_peso_gramos = new SqlParameter("@datenv_peso_gramos", SqlDbType.VarChar, 30);
                Parameter_pDatenv_peso_gramos.Value = pDatenv_peso_gramos;
                Parameter_pDatenv_peso_gramos.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pDatenv_peso_gramos);

                SqlParameter Parameter_pArcadj_RutaAdjunto = new SqlParameter("@arcadj_RutaAdjunto", SqlDbType.VarChar, 30);
                Parameter_pArcadj_RutaAdjunto.Value = pArcadj_RutaAdjunto;
                Parameter_pArcadj_RutaAdjunto.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pArcadj_RutaAdjunto);

                SqlParameter Parameter_pArcadj_NombreAdjunto = new SqlParameter("@arcadj_NombreAdjunto", SqlDbType.VarChar, 30);
                Parameter_pArcadj_NombreAdjunto.Value = pArcadj_NombreAdjunto;
                Parameter_pArcadj_NombreAdjunto.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pArcadj_NombreAdjunto);

                SqlParameter Parameter_pArcadj_ExtensionAdjunto = new SqlParameter("@arcadj_ExtensionAdjunto", SqlDbType.VarChar, 30);
                Parameter_pArcadj_ExtensionAdjunto.Value = pArcadj_ExtensionAdjunto;
                Parameter_pArcadj_ExtensionAdjunto.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pArcadj_ExtensionAdjunto);

                SqlParameter Parameter_pPer_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.VarChar, 30);
                Parameter_pPer_codigo_responsable.Value = pPer_codigo_responsable;
                Parameter_pPer_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pPer_codigo_responsable);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ins_EnvioOficios::Produjo un error.", MiExcepcion);
                }
            }
        //-------------------------------------------------
        public bool ModificarEstado(int pCodigoSalida, int pEstado)
            {
                int Resultado = 0;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("upd_RecepcionSalidasDocumentoEstado", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoSalida = new SqlParameter("@CodigoSalida", SqlDbType.Int, 11);
                Parameter_CodigoSalida.Value = pCodigoSalida;
                Parameter_CodigoSalida.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoSalida);

                SqlParameter Parameter_sw = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
                Parameter_sw.Value = pEstado;
                Parameter_sw.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_sw);

                //parametros de salida
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);

                try
                {
                    SqlCon.Open();
                    Resultado = SqlCom.ExecuteNonQuery();
                    //_CodigoDocumento = Convert.ToInt32(Parameter_CodigoDocumento.Value);
                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                }
                catch (Exception MiExcepcion)
                {
                    _CodigoError = -1;
                    throw new Exception("Contrato::Modificacion::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }

                if (_CodigoError == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
//------------------------------------------------------------------------------------
        #endregion
    }
}
