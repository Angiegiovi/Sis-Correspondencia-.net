﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;



namespace CapaDeDatos
{
    public class BDPersonal
    {
        #region "Variables"

            private string _CadenaConexionBDPersonal;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public BDPersonal()
            {
                _CadenaConexionBDPersonal = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
                //_CadenaConexionBDPersonal = WebConfigurationManager.ConnectionStrings["CadenaDeConexionPersonal"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _per_Codigo { get; set; }
            public string _per_Paterno { get; set; }
            public string _per_Materno { get; set; }
            public string _per_PrimerNombre { get; set; }
            public int _car_Codigo { get; set; }
            public int _uni_Codigo { get; set; }
            public string _NombreUnidad { get; set; }

            public int _uni_Dependencia { get; set; }
            public string _uni_Sigla { get; set; }
            public int _car_Tipo { get; set; }

            public int _CodigoRol { get; set; }
            public int _UsuarioMAE { get; set; }

        #endregion
        #region "funciones publicas"


//------------------------------------------------------------------------------------
//-------------------------------------------------------------
            public SqlDataReader _Modificar_Datos_Reporte(string datrep_nombres, string datrep_cargo, int datrep_codigo)
            {
                SqlDataReader Lector;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);
                SqlCommand SqlCom = new SqlCommand("upd_datos_Reporte", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_datrep_nombres = new SqlParameter("@nombre", SqlDbType.VarChar, 40);
                Parameter_datrep_nombres.Value = datrep_nombres;
                Parameter_datrep_nombres.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_datrep_nombres);

                SqlParameter Parameter_datrep_cargo = new SqlParameter("@cargo", SqlDbType.VarChar, 40);
                Parameter_datrep_cargo.Value = datrep_cargo;
                Parameter_datrep_cargo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_datrep_cargo);

                SqlParameter Parameter_datrep_codigo = new SqlParameter("@codigo", SqlDbType.Int, 11);
                Parameter_datrep_codigo.Value = datrep_codigo;
                Parameter_datrep_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_datrep_codigo);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::ModificarSalidasDatosReporte::Produjo un error.", MiExcepcion);
                }
            }

//---------------------------------------------------------------------------------------------------

            public DataSet _UnidadesGerenciasDep()
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);

                SqlCommand SqlCom = new SqlCommand("sel_UnidadesGerenciasDep", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "comboUnidades");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-------------------------------------------------------------------------------------------------
            public SqlDataReader _InsertarDatos(string datrep_nombres, string datrep_cargo, int per_codigo_responsable)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);
                SqlCommand SqlCom = new SqlCommand("ins_datos_reportes", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;
                
                SqlParameter Parameter_datrep_nombres = new SqlParameter("@datrep_nombres", SqlDbType.VarChar, 40);
                Parameter_datrep_nombres.Value = datrep_nombres;
                Parameter_datrep_nombres.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_datrep_nombres);

                SqlParameter Parameter_datrep_cargo = new SqlParameter("@datrep_cargo", SqlDbType.VarChar, 40);
                Parameter_datrep_cargo.Value = datrep_cargo;
                Parameter_datrep_cargo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_datrep_cargo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
                }
            }
//--------------------------------------------------------------------------------
            public DataSet _Sello_Per(int datrep_codigo, int per_codigo_responsable)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);

                SqlCommand SqlCom = new SqlCommand("sel_datos_reportes", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_datrep_codigo = new SqlParameter("@datrep_codigo", SqlDbType.Int, 11);
                Parameter_datrep_codigo.Value = datrep_codigo;
                Parameter_datrep_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_datrep_codigo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "listarsello");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//---------------------------------------------------------------------------------------------------
            public SqlDataReader _DeletePersonaExc(int excder_codigo, int per_codigo_responsable)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);
                SqlCommand SqlCom = new SqlCommand("del_ExcepcionesDerivacionesPersona", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;



                SqlParameter Parameter_excder_codigo = new SqlParameter("@excder_codigo", SqlDbType.Int, 11);
                Parameter_excder_codigo.Value = excder_codigo;
                Parameter_excder_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_excder_codigo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
                }
            }
 //--------------------------------------------------   
            public SqlDataReader _InsertarPersonaExc(int per_codigo, int per_codigo_responsable, int per_codigo_origen, string pcamexc_justificacion)
        {
                SqlDataReader Lector;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);
                SqlCommand SqlCom = new SqlCommand("ins_ExcepcionesDerivacionesPersona", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = per_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlParameter Parameter_per_codigo_origen = new SqlParameter("@per_codigo_origen", SqlDbType.Int, 11);
                Parameter_per_codigo_origen.Value = per_codigo_origen;
                Parameter_per_codigo_origen.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_origen);

                SqlParameter Parameter_camexc_justificacion = new SqlParameter("@camexc_justificacion", SqlDbType.VarChar, 150);
                Parameter_camexc_justificacion.Value = pcamexc_justificacion;
                Parameter_camexc_justificacion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_camexc_justificacion);
            
                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
                }
            }
//-------------------------------------------------------------------------------------------------------
            public DataSet _ExceDerPersona(int excder_codigo)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);

                SqlCommand SqlCom = new SqlCommand("sel_ExcepcionesDerivacionPersona", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_excder_codigo = new SqlParameter("@excder_codigo", SqlDbType.Int, 11);
                Parameter_excder_codigo.Value = excder_codigo;
                Parameter_excder_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_excder_codigo);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "listarexc");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
            //------------
//-----------------------------------   
        //  lista todas la unidades dependientes de una MAE
            public DataSet  _ObtenerTodasUnidadesDeMAE(int pPer_codigo)
            { int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);

                SqlCommand SqlCom = new SqlCommand("sel_TodasUnidades_modificar", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = pPer_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "comboUnidades");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
        //--------------------------------
        public DataSet _ObtenerTodasUnidades()
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);

                SqlCommand SqlCom = new SqlCommand("sel_TodasUnidades", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "comboUnidades");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-------------------------------------------------------------------------------------------------------
            public DataSet _PersonasPorUnidad(int pUnidad)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);

                SqlCommand SqlCom = new SqlCommand("sel_FuncionariosPorUnidad", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Unidad = new SqlParameter("@uni_codigo", SqlDbType.Int, 11);
                Parameter_Unidad.Value = pUnidad;
                Parameter_Unidad.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Unidad);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_personas");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-----------------------------------------------------------------------------------------------------
            public DataSet ListarResidencias()
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);
                SqlCommand SqlCom = new SqlCommand("sel_Residencias", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "comboResidencias");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ListarResidencias::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-------------------------------------------------------------------------------------------------------
        //Ever  modificado     se aumento el parametro de cargo
        public DataSet _ListarUnidadesPermitidas(int pper_codigo, 
                                                                                            int pProviene, 
                                                                                            int pper_codigo_responsable,
                                                                                            int pCodigoRol, 
                                                                                            int pCodigoCar)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);

                SqlCommand SqlCom = new SqlCommand("sel_UnidadesParaDerivacionPorUsuario", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = pper_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_Proviene = new SqlParameter("@Proviene", SqlDbType.Int, 11);
                Parameter_Proviene.Value = pProviene;
                Parameter_Proviene.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Proviene);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
                Parameter_CodigoRol.Value = pCodigoRol;
                Parameter_CodigoRol.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoRol);

                SqlParameter Parameter_CodigoCar = new SqlParameter("@car_codigo", SqlDbType.Int, 11);
                Parameter_CodigoCar.Value = pCodigoCar;
                Parameter_CodigoCar.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoCar);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "comboUnidades");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-----------------------------------------------------------------------------------------------------
         public DataSet _ListarFuncionariosPorunidadPermitidos(
                int puni_codigo,
                int pper_codigo, 
                int pProviene, 
                int pper_codigo_responsable,
                int pCodigoRol,
                int pcar_codigo)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDPersonal);

                SqlCommand SqlCom = new SqlCommand("sel_FuncionariosXUnidadParaDerivacion2", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_uni_codigo = new SqlParameter("@uni_codigo", SqlDbType.Int, 11);
                Parameter_uni_codigo.Value = puni_codigo;
                Parameter_uni_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_uni_codigo);

                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = pper_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_Proviene = new SqlParameter("@Proviene", SqlDbType.Int, 11);
                Parameter_Proviene.Value = pProviene;
                Parameter_Proviene.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Proviene);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
                Parameter_CodigoRol.Value = pCodigoRol;
                Parameter_CodigoRol.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoRol);
                
                /* se aumento el envio del codigo del cargo*/
                SqlParameter Parameter_car_codigo = new SqlParameter("@car_codigo", SqlDbType.Int, 11);
                Parameter_car_codigo.Value = pcar_codigo;
                Parameter_car_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_car_codigo);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "comboPersonas");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::_ListarFuncionariosPorunidadPermitidos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//------------------------------------------------------------------------------------------------------
                          
//--------------------------------------------------------------------------------------------------- 
        #endregion
    }
}
