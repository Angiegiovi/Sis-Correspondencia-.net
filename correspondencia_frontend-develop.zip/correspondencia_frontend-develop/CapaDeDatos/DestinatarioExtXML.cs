﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CapaDeDatos
{
    public class DestinatarioExtXML
    {
        string NombrePersona;        
        //{ get; set; }
        int ent_codigo;
        //{ get; set; }
    
        // Constructor
        public DestinatarioExtXML()
        {
            this.NombrePersona = "NULL";
            this.ent_codigo = -1;
        }

        public DestinatarioExtXML(string NombrePersona, int ent_codigo)
        {
            this.NombrePersona = NombrePersona;
            this.ent_codigo = ent_codigo;
        }

        // Casteador
        public static String CastearXml(List<DestinatarioExtXML> lista)
        {
            return ConversionTipos.CastearListaObjetosParaXml(lista, typeof(DestinatarioExtXML));
        }

    }
}
