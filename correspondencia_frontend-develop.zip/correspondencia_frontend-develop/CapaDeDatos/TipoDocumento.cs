﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class TipoDocumento
    {
        #region "Variables"
            private string _CadenaConexion;
            private int _CodigoError;
        #endregion
        #region "Constructor"
            public TipoDocumento()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _CodigoTipoDocumento { get; set; }
            public string _Descripcion { get; set; }
            public string _CodigoUnidad { get; set; }
            public int _Correlativo { get; set; }
            public string _CorrelativoCompleto { get; set; }
            public int _Gestion { get; set; }
            public string _Prefijo { get; set; }
            public string _PrefijoDOC { get; set; }
            public int _Habilitado { get; set; }

            //extra
            public string _Numero { get; set; }

        #endregion
        #region "funciones publicas"
//---------------------------------------------------------------------------------------------------
        /*Ever Ivan*/    
        public DataSet _ObtenerTodosLosTiposDocumentos(int pEstado, int pCodigoTipoDocumento,int pPer_codigo)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_TipoDocumento", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Estado = new SqlParameter("@Estado", SqlDbType.Int, 11);
                Parameter_Estado.Value = pEstado;
                Parameter_Estado.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Estado);

                SqlParameter Parameter_CodigoTipoDocumento = new SqlParameter("@CodigoTipoDocumento", SqlDbType.Int, 11);
                Parameter_CodigoTipoDocumento.Value = pCodigoTipoDocumento;
                Parameter_CodigoTipoDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoTipoDocumento);

                SqlParameter Parameter_pPer_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_pPer_codigo.Value = pPer_codigo;
                Parameter_pPer_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pPer_codigo);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "comboDeTiposDoc");

                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }

     
//---------------------------------------------------------------------------------------------------
        #endregion
    }
}
