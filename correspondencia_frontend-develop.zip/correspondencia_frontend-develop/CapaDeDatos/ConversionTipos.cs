﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace CapaDeDatos
{
    public class ConversionTipos
    {
        public static String CastearListaObjetosParaXml(object lista, Type Class)
        {

            String strNombreClase = Class.Name;
            //String strNombreClaseTitulo = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(strNombreClase);
            String strNombreClaseTitulo = strNombreClase.First().ToString(CultureInfo.InvariantCulture).ToUpper() +
                                          strNombreClase.Substring(1);

            var listType = typeof(List<>);
            var constructedListType = listType.MakeGenericType(Class);
            XmlSerializer x = new XmlSerializer(constructedListType);
            StringWriter textWriter = new StringWriterWithEncoding(Encoding.UTF8);
            x.Serialize(textWriter, lista);
            string strxml2 = textWriter.ToString();
            strxml2 = strxml2.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
            strxml2 = strxml2.Replace("<ArrayOf" + strNombreClaseTitulo, "<table");
            strxml2 = strxml2.Replace("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"", "");
            strxml2 = strxml2.Replace("xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"", "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
            strxml2 = strxml2.Replace("</ArrayOf" + strNombreClaseTitulo + ">", "</table>");
            strxml2 = strxml2.Replace(strNombreClase, "row");
            Debug.WriteLine("---------=========->" + strxml2);
            return strxml2;

        }

    }
}
