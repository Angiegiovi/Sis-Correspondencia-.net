﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class FirmaPersona
    {
        
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public FirmaPersona()
            {
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _CodigoFirmaPersona { get; set; }
            public int _per_Codigo { get; set; }
            public byte  _Firma { get; set; }
            public int _CodigoSesion { get; set; }
        
        #endregion
        #region "funciones publicas"
//-------------------------------------------------------------------------------
            public bool Adicionar(int pCodigoFuncionario, byte[] pFirma, int pCodigoSesion)
            {
                int Resultado = 0;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("ins_FirmaPersona", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoFuncionario = new SqlParameter("@CodigoFuncionario", SqlDbType.Int, 11);
                Parameter_CodigoFuncionario.Value = pCodigoFuncionario;
                Parameter_CodigoFuncionario.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoFuncionario);

                SqlParameter Parameter_Firma = new SqlParameter("@Firma", SqlDbType.VarBinary);
                Parameter_Firma.Value = pFirma;
                Parameter_Firma.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Firma);

                SqlParameter Parameter_CodigoSesion = new SqlParameter("@CodigoSesion", SqlDbType.Int, 11);
                Parameter_CodigoSesion.Value = pCodigoSesion;
                Parameter_CodigoSesion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoSesion);

                
                try
                {
                    SqlCon.Open();
                    Resultado = SqlCom.ExecuteNonQuery();
                   
                }
                catch (Exception MiExcepcion)
                {
                    _CodigoError = -1;
                    throw new Exception("Instruccion::Adicionar::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
                if (_CodigoError == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
//-------------------------------------------------------------------------------
            public DataSet ObtenerFirmaPersonaPorID(string pCodigoFuncionario)
            {
                
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("sel_FirmaPersona", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoFuncionario = new SqlParameter("@CodigoFuncionario", SqlDbType.Int, 11);
                Parameter_CodigoFuncionario.Value = pCodigoFuncionario;
                Parameter_CodigoFuncionario.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoFuncionario);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_firma");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-------------------------------------------------------------------------------
//-------------------------------------------------------------------------------
//-------------------------------------------------------------------------------
        #endregion
    }
}
