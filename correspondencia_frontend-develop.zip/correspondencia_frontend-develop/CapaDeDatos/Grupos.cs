﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI;
/*
 * Ever Ivan - @2015
 * Clase para la admintracion de los grupos de hojas de rutas
 */
namespace CapaDeDatos
{
    public class Grupos
    {   
        #region "Variables"
            
            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"
            
            public Grupos()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion

        //    #region "Propiedades publicas"

        //    public int _CodigoHojaRuta { get; set; }
        //    public string _Referencia { get; set; }
        //    public string _Procedencia { get; set; }
        //    public string _FechaRegistro { get; set; }
        //    public int _CodigoEstado { get; set; }
        //    public int _CodigoTipoHojaRuta { get; set; }
        //    public string _CodigoCorrelatvo { get; set; }
        //    public string _FechaRecepcion { get; set; }
        //    public string _CodigoCorrespondencia { get; set; }

        //    public string _HoraRegistro { get; set; }
        //    public string _HoraRecepcion { get; set; }
        //    public string _CITE { get; set; }
        //    public char _PQ { get; set; }

        //    public int _EnUso { get; set; }
        //    public string _Anexos { get; set; }

        //#endregion
        #region "funciones publicas"
        
    //@CodigoEjemplar_Padre INT,
    //@comentario Varchar(250),
    //@Codigo_Ejemplar_xml XML,
    //@CodigoMovimiento INT
        public SqlDataReader AdicionarGrupo(int pCodigoEjemplar_Padre, string pComentario, string Codigo_Ejemplar_xml, int pCodigoMovimiento, int pper_Codigo, int pper_codigo_responsable)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_Ejemplar_Grupo_Movimiento", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoEjemplar_Padre = new SqlParameter("@CodigoEjemplar_Padre", SqlDbType.Int, 11);
            Parameter_CodigoEjemplar_Padre.Value = pCodigoEjemplar_Padre;
            Parameter_CodigoEjemplar_Padre.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEjemplar_Padre);

            SqlParameter Parameter_comentario = new SqlParameter("@comentario", SqlDbType.VarChar, 600);
            Parameter_comentario.Value = pComentario;
            Parameter_comentario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_comentario);

            SqlParameter Parameter_Codigo_Ejemplar_xml = new SqlParameter("@Codigo_Ejemplar_xml", SqlDbType.VarChar, 600);
            Parameter_Codigo_Ejemplar_xml.Value = Codigo_Ejemplar_xml;
            Parameter_Codigo_Ejemplar_xml.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Codigo_Ejemplar_xml);

            SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
            Parameter_CodigoMovimiento.Value = pCodigoMovimiento;
            Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pper_Codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);  

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::AdicionarGrupo::Produjo un error.", MiExcepcion);
            }
        }
        #endregion
    }
}