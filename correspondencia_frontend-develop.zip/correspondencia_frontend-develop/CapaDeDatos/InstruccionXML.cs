﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CapaDeDatos
{
    public class InstruccionXML
    {
        public int CodigoInstruccion;
        //{ get; set; }
       
       // Constructor
        public InstruccionXML()
        {
            this.CodigoInstruccion = 0;
        }

        public InstruccionXML(int CodigoInstruccion)
        {
            this.CodigoInstruccion = CodigoInstruccion;
        }

        // Casteador
        public static String CastearXml(List<InstruccionXML> lista)
        {
            return ConversionTipos.CastearListaObjetosParaXml(lista, typeof(InstruccionXML));
        }
       
    }
}
