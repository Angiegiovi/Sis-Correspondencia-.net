﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class Anexos
    {
        #region "Variables"
            
            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public Anexos()
            {
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion
        #region "Propiedades publicas"

            public int _CodigoAnexo { get; set; }
            public string _Descripcion { get; set; }
            public int _CodigoSesion { get; set; }
            public int _Habilitado { get; set; }
            
        #endregion
        #region "funciones publicas"

//----------------------------------------------------------
        //Ever Ivan -2015
        //AdicionarSalidasAnexos, insertamos anexos a los oficios de la bandeja de salida
            public SqlDataReader AdicionarSalidasAnexos(int pRecal_Codigo, int pCodigoAnexo, int pCantidad)
            {
                SqlDataReader Lector;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("ins_SalidasAnexos", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Recal_Codigo = new SqlParameter("@recsal_Codigo", SqlDbType.Int, 11);
                Parameter_Recal_Codigo.Value = pRecal_Codigo;
                Parameter_Recal_Codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Recal_Codigo);

                SqlParameter Parameter_CodigoAnexo = new SqlParameter("@CodigoAnexo", SqlDbType.Int, 11);
                Parameter_CodigoAnexo.Value = pCodigoAnexo;
                Parameter_CodigoAnexo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoAnexo);

                SqlParameter Parameter_Cantidad = new SqlParameter("@Cantidad", SqlDbType.Int, 11);
                Parameter_Cantidad.Value = pCantidad;
                Parameter_Cantidad.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Cantidad);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::_AdicionaranexoXHojaRuta::Produjo un error.", MiExcepcion);
                }
            }

            public SqlDataReader EliminarSalidaAnexo(int pSal_codigo)
            {
                SqlDataReader Lector;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("del_SalidasAnexos", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;
                SqlParameter Parameter_Sal_codigo = new SqlParameter("@sal_codigo", SqlDbType.Int, 11);
                Parameter_Sal_codigo.Value = pSal_codigo;
                Parameter_Sal_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Sal_codigo);
                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::_EliminarAnexoXHojaRuta::Produjo un error.", MiExcepcion);
                }
            }




            public SqlDataReader ModificarSalidasAnexos(int pSal_codigo, int pCodigoAnexo, int pCantidad)
            {
                SqlDataReader Lector;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("upd_SalidasAnexos", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Sal_codigo = new SqlParameter("@sal_codigo", SqlDbType.Int, 11);
                Parameter_Sal_codigo.Value = pSal_codigo;
                Parameter_Sal_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Sal_codigo);

                SqlParameter Parameter_CodigoAnexo = new SqlParameter("@CodigoAnexo", SqlDbType.Int, 11);
                Parameter_CodigoAnexo.Value = pCodigoAnexo;
                Parameter_CodigoAnexo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoAnexo);

                SqlParameter Parameter_Cantidad = new SqlParameter("@Cantidad", SqlDbType.Int, 11);
                Parameter_Cantidad.Value = pCantidad;
                Parameter_Cantidad.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Cantidad);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::ModificarSalidasAnexos::Produjo un error.", MiExcepcion);
                }
            }







        
            public DataSet ObtenerAnexosDeOficio(int pRecsal_Codigo)
            {   int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_SalidasAnexos", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@recsal_Codigo", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pRecsal_Codigo;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);
                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_anexosOficio");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::_ObtenerAnexosDeHojaRuta::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }



//-------------------------------------------------------------
           
        //----------------------------
            public DataSet _ListarAnexos(int pEstado, int pCodigoAnexo)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_TiposAnexos", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Descripcion = new SqlParameter("@Estado", SqlDbType.Int, 11);
                Parameter_Descripcion.Value = pEstado;
                Parameter_Descripcion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Descripcion);

                SqlParameter Parameter_CodigoAnexo = new SqlParameter("@CodigoAnexo", SqlDbType.Int, 11);
                Parameter_CodigoAnexo.Value = pCodigoAnexo;
                Parameter_CodigoAnexo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoAnexo);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_anexos");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//----------------------------------------------------------
            public SqlDataReader _AdicionarAnexo(string pDescripcion)
            {
                SqlDataReader Lector;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("ins_TiposAnexos", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Descripcion = new SqlParameter("@Descripcion", SqlDbType.VarChar, 250);
                Parameter_Descripcion.Value = pDescripcion;
                Parameter_Descripcion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Descripcion);
                
                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
                }
            }
//----------------------------------------------------------
    
//----------------------------------------------------------
        #endregion
    }
}
