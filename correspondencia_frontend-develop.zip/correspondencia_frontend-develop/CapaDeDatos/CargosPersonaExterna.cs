﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class CargosPersonaExterna
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public CargosPersonaExterna()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _CodigoCargoPE { get; set; }
            public string _Descripcion { get; set; }
            public string _Abreviatura { get; set; }
            public int _Habilitado { get; set; }

        #endregion
        #region "funciones publicas"
//-----------------------------------------------------------------------------
            public DataSet _ObtenerTodosLosCargos()
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_TodosCargosPersonaExterna", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                  SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_cargos");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-----------------------------------------------------------------------------
          
//-----------------------------------------------------------------------------   
        #endregion
    }
}
