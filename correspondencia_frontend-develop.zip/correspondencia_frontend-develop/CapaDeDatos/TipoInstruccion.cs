﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class TipoInstruccion
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public TipoInstruccion()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion
        #region "Propiedades publicas"

            public int _CodigoInstruccion { get; set; }
            public string _Descripcion { get; set; }

        #endregion
        #region "funciones publicas"
//---------------------------------------------------------------------------------------------------
            public DataSet _ObtenerListadoInstrucciones(int pEstado)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_TipoInstruccion", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Estado = new SqlParameter("@Estado", SqlDbType.Int, 11);
                Parameter_Estado.Value = pEstado;
                Parameter_Estado.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Estado);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "comboDeInstruccion");

                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//---------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------
        #endregion
    }
}
