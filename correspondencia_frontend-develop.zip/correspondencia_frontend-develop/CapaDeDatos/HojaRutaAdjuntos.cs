﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class HojaRutaAdjuntos
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public HojaRutaAdjuntos()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _CodigoHRAdjunto { get; set; }
            public string _Referencia { get; set; }
            public string _Cite { get; set; }
            public string _FechaDocumento { get; set; }
            public string _FechaRegistro { get; set; }
            public int _CodigoHojaRuta { get; set; }
            public int _CodigoAdjunto { get; set; }
            public int _CodigoDerivacion { get; set; }
            public string _DatosAdicionales { get; set; }

            public string _RutaArchivo { get; set; }
            public string _NombreArchivo { get; set; }
            public string _ExtensionArchivo { get; set; }

        #endregion
        #region "funciones publicas"

//---------------------------------------------------------------------------------------------------
        public DataSet _ArchivosPorCorrespondencia(int pCodigoHojaRuta)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_AdjuntosPorCorrespondencia", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                 SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_archivos");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::_ArchivosPorCorrespondencia::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//---------------------------------------------------------------------------------------------------
    //@Ever Ivan - 2015
    //@recsal_codigo INT, el txtinput
    //@CodigoEjemplar INT,????????????????????? grid listado
    //@CodigoHojaRuta INT,
    //@Referencia VARCHAR(250), del formulario
    //@Cite VARCHAR(100), ??????????????????? del formulario, documento que llega 
    //@FechaDocumento date, ??? del formulario, documento que llega
    //@DatosAdicionales VARCHAR(1000),del formulario, ? doc llega
    //@FechaRecepcionFisica DATETIME, ?del formulario, Fecha recepcion: 
    //@remper_persona_externa VARCHAR(120),del formulario el texto
    //@remper_cargo_transcrito VARCHAR(60), si es 0 cargo te manod esto
    //@CodigoCargoPE INT,  si es dif cero te mano cod, si es igual
    //@RutaAdjunto VARCHAR(150), del archivo fisico
    //@NombreAdjunto VARCHAR(150), del archivo fisico
    //@ExtensionAdjunto VARCHAR(10),del achivo fisico
    //@per_codigo_responsable INT  session("CodUsuario") 
        public SqlDataReader _AdicionarRegistroEntradas(int pRescal_codigo, int pCodigoEjemplar, int pCodigoHojaRuta, 
                                                        string pReferencia, string pCite, string pFechaDocumento, 
                                                        string pDatosAdicionales, string pFechaRecepcionFisica, 
                                                        string pRemper_persona_externa, string pRemper_cargo_transcrito, 
                                                        int pCodigoCargoPE, string pRutaAdjunto, string pNombreAdjunto, 
                                                        string pExtensionAdjunto, int pPer_codigo_responsable)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_registro_entradas", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Rescal_codigo = new SqlParameter("@recsal_codigo", SqlDbType.Int, 11);
            Parameter_Rescal_codigo.Value = pRescal_codigo;
            Parameter_Rescal_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Rescal_codigo);

            SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 250);
            Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
            Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 100);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar,100);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Cite = new SqlParameter("@Cite", SqlDbType.VarChar, 1000);
            Parameter_Cite.Value = pCite;
            Parameter_Cite.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Cite);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumento", SqlDbType.Date, 1000);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_DatosAdicionales = new SqlParameter("@DatosAdicionales", SqlDbType.VarChar, 1000);
            Parameter_DatosAdicionales.Value = pDatosAdicionales;
            Parameter_DatosAdicionales.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DatosAdicionales);

            SqlParameter Parameter_FechaRecepcionFisica = new SqlParameter("@FechaRecepcionFisica  ", SqlDbType.Date, 100);
            Parameter_FechaRecepcionFisica.Value = pFechaRecepcionFisica;
            Parameter_FechaRecepcionFisica.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRecepcionFisica);

            SqlParameter Parameter_remper_persona_externa = new SqlParameter("@remper_persona_externa", SqlDbType.VarChar, 1000);
            Parameter_remper_persona_externa.Value = pRemper_persona_externa;
            Parameter_remper_persona_externa.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_remper_persona_externa);

            SqlParameter Parameter_Remper_cargo_transcrito = new SqlParameter("@remper_cargo_transcrito", SqlDbType.VarChar, 60);
            Parameter_Remper_cargo_transcrito.Value = pRemper_cargo_transcrito;
            Parameter_Remper_cargo_transcrito.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Remper_cargo_transcrito);

            SqlParameter Parameter_CodigoCargoPE = new SqlParameter("@CodigoCargoPE", SqlDbType.Int, 10);
            Parameter_CodigoCargoPE.Value = pCodigoCargoPE;
            Parameter_CodigoCargoPE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoCargoPE);

            SqlParameter Parameter_RutaAdjunto = new SqlParameter("@RutaAdjunto", SqlDbType.VarChar, 150);
            Parameter_RutaAdjunto.Value = pRutaAdjunto;
            Parameter_RutaAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_RutaAdjunto);

            SqlParameter Parameter_NombreAdjunto = new SqlParameter("@NombreAdjunto", SqlDbType.VarChar, 150);
            Parameter_NombreAdjunto.Value = pNombreAdjunto;
            Parameter_NombreAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombreAdjunto);

            SqlParameter Parameter_ExtensionAdjunto = new SqlParameter("@ExtensionAdjunto", SqlDbType.VarChar, 10);
            Parameter_ExtensionAdjunto.Value = pExtensionAdjunto;
            Parameter_ExtensionAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_ExtensionAdjunto);

            SqlParameter Parameter_Per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 10);
            Parameter_Per_codigo_responsable.Value = pPer_codigo_responsable;
            Parameter_Per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Per_codigo_responsable);
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("::_AdicionarAdjuntosCorrespondencia::Produjo un error.", MiExcepcion);
            }
        }        
        public SqlDataReader _AdicionarAdjuntosCorrespondencia(string pReferencia, string pCite, string pFechaDocumento, int pCodigoHojaRuta, string pDatosAdicionales, string pRutaAdjunto, string pNombreAdjunto, string pExtensionAdjunto)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_HojaRutaAdjuntos", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);
            
            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 250);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Cite = new SqlParameter("@Cite", SqlDbType.VarChar, 100);
            Parameter_Cite.Value = pCite;
            Parameter_Cite.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Cite);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumento", SqlDbType.Date);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_DatosAdicionales = new SqlParameter("@DatosAdicionales", SqlDbType.VarChar, 1000);
            Parameter_DatosAdicionales.Value = pDatosAdicionales;
            Parameter_DatosAdicionales.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DatosAdicionales);
            
            SqlParameter Parameter_RutaAdjunto = new SqlParameter("@RutaAdjunto", SqlDbType.VarChar, 150);
            Parameter_RutaAdjunto.Value = pRutaAdjunto;
            Parameter_RutaAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_RutaAdjunto);

            SqlParameter Parameter_NombreAdjunto = new SqlParameter("@NombreAdjunto", SqlDbType.VarChar, 150);
            Parameter_NombreAdjunto.Value = pNombreAdjunto;
            Parameter_NombreAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombreAdjunto);
            
            SqlParameter Parameter_ExtensionAdjunto = new SqlParameter("@ExtensionAdjunto", SqlDbType.VarChar, 10);
            Parameter_ExtensionAdjunto.Value = pExtensionAdjunto;
            Parameter_ExtensionAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_ExtensionAdjunto);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("::_AdicionarAdjuntosCorrespondencia::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _ModificarAdjuntosCorrespondencia(int pCodigoHRAdjunto, string pCite, string pReferencia, string pFechaDocumento, string pDatosAdicionales, string pRutaAdjunto, string pNombreAdjunto, string pExtensionAdjunto)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_HojaRutaAdjuntos", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHRAdjunto = new SqlParameter("@CodigoHRAdjunto", SqlDbType.Int, 11);
            Parameter_CodigoHRAdjunto.Value = pCodigoHRAdjunto;
            Parameter_CodigoHRAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHRAdjunto);

            SqlParameter Parameter_Cite = new SqlParameter("@Cite", SqlDbType.VarChar, 100);
            Parameter_Cite.Value = pCite;
            Parameter_Cite.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Cite);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 250);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumento", SqlDbType.Date);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_DatosAdicionales = new SqlParameter("@DatosAdicionales", SqlDbType.VarChar, 1000);
            Parameter_DatosAdicionales.Value = pDatosAdicionales;
            Parameter_DatosAdicionales.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DatosAdicionales);


            SqlParameter Parameter_RutaAdjunto = new SqlParameter("@RutaAdjunto", SqlDbType.VarChar, 150);
            Parameter_RutaAdjunto.Value = pRutaAdjunto;
            Parameter_RutaAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_RutaAdjunto);

            SqlParameter Parameter_NombreAdjunto = new SqlParameter("@NombreAdjunto", SqlDbType.VarChar, 150);
            Parameter_NombreAdjunto.Value = pNombreAdjunto;
            Parameter_NombreAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombreAdjunto);

            SqlParameter Parameter_ExtensionAdjunto = new SqlParameter("@ExtensionAdjunto", SqlDbType.VarChar, 10);
            Parameter_ExtensionAdjunto.Value = pExtensionAdjunto;
            Parameter_ExtensionAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_ExtensionAdjunto);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("::_ModificarAdjuntosCorrespondencia::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _EliminarAdjuntosCorrespondencia(int pCodigoHRAdjunto)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_HojaRutaAdjuntos", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHRAdjunto = new SqlParameter("@CodigoHRAdjunto", SqlDbType.Int, 11);
            Parameter_CodigoHRAdjunto.Value = pCodigoHRAdjunto;
            Parameter_CodigoHRAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHRAdjunto);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("::_AdicionarAdjuntosCorrespondencia::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool AdicionarHRAdjunto(string pReferencia, string pCite, string pFechaDocumento, int pCodigoHojaRuta, int pCodigoAdjunto, int pCodigoDerivacion, string pDatosAdicionales, int pCodigoSesion, string pFechaRecepcion)
        {
            int Resultado = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_HojaRutaAdjuntosRespuesta", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 250);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Cite = new SqlParameter("@Cite", SqlDbType.VarChar, 100);
            Parameter_Cite.Value = pCite;
            Parameter_Cite.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Cite);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumento", SqlDbType.VarChar, 15);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_CodigoAdjunto = new SqlParameter("@CodigoAdjunto", SqlDbType.Int, 11);
            Parameter_CodigoAdjunto.Value = pCodigoAdjunto;
            Parameter_CodigoAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoAdjunto);

            SqlParameter Parameter_CodigoDerivacion = new SqlParameter("@CodigoDerivacion", SqlDbType.Int, 11);
            Parameter_CodigoDerivacion.Value = pCodigoDerivacion;
            Parameter_CodigoDerivacion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDerivacion);

            SqlParameter Parameter_DatosAdicionales = new SqlParameter("@DatosAdicionales", SqlDbType.VarChar, 1000);
            Parameter_DatosAdicionales.Value = pDatosAdicionales;
            Parameter_DatosAdicionales.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DatosAdicionales);

            SqlParameter Parameter_CodigoSesion = new SqlParameter("@CodigoSesion", SqlDbType.VarChar, 250);
            Parameter_CodigoSesion.Value = pCodigoSesion;
            Parameter_CodigoSesion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSesion);

            SqlParameter Parameter_FechaRecepcion = new SqlParameter("@FechaRecepcion", SqlDbType.VarChar,20);
            Parameter_FechaRecepcion.Value = pFechaRecepcion;
            Parameter_FechaRecepcion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRecepcion);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlParameter Parameter_CodigoHRAdjunto = new SqlParameter("@CodigoHRAdjunto", SqlDbType.Int, 11);
            Parameter_CodigoHRAdjunto.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoHRAdjunto);


            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                _CodigoHRAdjunto = Convert.ToInt32(Parameter_CodigoHRAdjunto.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Usuario::Adicion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet _ArchivosDeHojaRuta(int pCodigoHojaRuta, int pCodigoEjemplar)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_TodosAdjuntosPorHojaDeRuta", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
            Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_archivos");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("::_ArchivosPorCorrespondencia::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        #endregion
    }
}
