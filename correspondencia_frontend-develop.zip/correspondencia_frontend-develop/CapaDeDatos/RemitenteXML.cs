﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CapaDeDatos
{
    public class RemitenteXML
    {
         public int per_codigo
        { get; set; }

        // Constructor
        public RemitenteXML()
        {
            this.per_codigo = 0;
        }

        public RemitenteXML(int per_codigo)
        {
            this.per_codigo = per_codigo;
        }

        // Casteador
        public static String CastearXml(List<RemitenteXML> lista)
        {
            return ConversionTipos.CastearListaObjetosParaXml(lista, typeof(RemitenteXML));
        }
    }
}
