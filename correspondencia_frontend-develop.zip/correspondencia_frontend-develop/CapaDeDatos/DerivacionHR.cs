﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class DerivacionHR
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public DerivacionHR()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion
        #region "Propiedades publicas"

            public int _CodigoDerivacion { get; set; }
            public string _Comentarios { get; set; }
            public int _DerivadoPor { get; set; }
            public int _DerivadoA { get; set; }
            public string _FechaDerivacion { get; set; }
            public string _FechaRegistro { get; set; }
            public int _CodigoHojaRuta { get; set; }
            public int _EstadoDerivacion { get; set; }
            public int _CodigoGrupo { get; set; }

            //extras
            public string _Instruccion { get; set; }
            public string _DerivadoPorM { get; set; }
            public string _DerivadoAM { get; set; }
            public int _TotalRegistros { get; set; }
        
        #endregion
        #region "funciones publicas"
//---------------------------------------------------------------------------------------------------
            public SqlDataReader _AdicionarCronograma(string pcuce, DateTime pfechaHoraPublicacion, DateTime pfechaHoraLimiteEntrega, int  pCodigoHojaRuta,int pCodigoUsuario)
            {
                SqlDataReader Lector = null;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("ins_CronogramaRecepcion", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;
  
                SqlParameter Parameter_pcuce = new SqlParameter("@cuce", SqlDbType.VarChar, 20);
                Parameter_pcuce.Value = pcuce;
                Parameter_pcuce.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pcuce);

                SqlParameter Parameter_pfechaHoraPublicacion = new SqlParameter("@fechaHoraPublicacion", SqlDbType.DateTime, 11);
                Parameter_pfechaHoraPublicacion.Value = pfechaHoraPublicacion;
                Parameter_pfechaHoraPublicacion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pfechaHoraPublicacion);

                SqlParameter Parameter_pfechaHoraLimiteEntrega = new SqlParameter("@fechaHoraLimiteEntrega ", SqlDbType.DateTime, 11);
                Parameter_pfechaHoraLimiteEntrega.Value = pfechaHoraLimiteEntrega;
                Parameter_pfechaHoraLimiteEntrega.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pfechaHoraLimiteEntrega);

                SqlParameter Parameter_pCodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.VarChar, 20);
                Parameter_pCodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_pCodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pCodigoHojaRuta);

                SqlParameter Parameter_pCodigoUsuario = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 20);
                Parameter_pCodigoUsuario.Value = pCodigoUsuario;
                Parameter_pCodigoUsuario.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pCodigoUsuario);
  
                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_AdicionarCronograma::Produjo un error.", MiExcepcion);
                }
            }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _AdicionarProveido(int pCodigoHojaRuta, int pCodigoEjemplar, int pCodigoMovimiento, string pComentarios, string xml_instrucciones, string xml_remitentes, string xml_destinatarios, int pper_codigo, int pper_codigo_responsable, string correlativos_xml, string pccp,DateTime  fecha_derivacion_usurio, string pcuce, DateTime pfechaHoraPublicacion, DateTime pfechaHoraLimiteEntrega )
        {
                SqlDataReader Lector = null;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("ins_FlujoEjemplarMovimiento", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
                Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
                Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

                SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
                Parameter_CodigoMovimiento.Value = pCodigoMovimiento;
                Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

                SqlParameter Parameter_Comentarios = new SqlParameter("@Comentarios", SqlDbType.VarChar, 250);
                Parameter_Comentarios.Value = pComentarios;
                Parameter_Comentarios.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Comentarios);

                SqlParameter Parameter_xml_instrucciones = new SqlParameter("@xml_instrucciones", SqlDbType.Xml, 1000);
                Parameter_xml_instrucciones.Value = xml_instrucciones;
                Parameter_xml_instrucciones.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_xml_instrucciones);

                SqlParameter Parameter_xml_remitentes = new SqlParameter("@xml_remitentes", SqlDbType.Xml, 1000);
                Parameter_xml_remitentes.Value = xml_remitentes;
                Parameter_xml_remitentes.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_xml_remitentes);

                SqlParameter Parameter_xml_destinatarios = new SqlParameter("@xml_destinatarios", SqlDbType.Xml, 1000);
                Parameter_xml_destinatarios.Value = xml_destinatarios;
                Parameter_xml_destinatarios.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_xml_destinatarios);

                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = pper_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlParameter Parameter_xml_correlativos = new SqlParameter("@correlativos_xml", SqlDbType.Xml, 1000);
                Parameter_xml_correlativos.Value = correlativos_xml;
                Parameter_xml_correlativos.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_xml_correlativos);

                SqlParameter Parameter_ccp = new SqlParameter("@ccert_presupuestaria", SqlDbType.Int, 11);
                Parameter_ccp.Value = pccp;
                Parameter_ccp.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_ccp);

                SqlParameter Parameter_pfecha_derivacion_usurio = new SqlParameter("@fecha_derivacion_usuario", SqlDbType.DateTime, 11);
                Parameter_pfecha_derivacion_usurio.Value = fecha_derivacion_usurio;
                Parameter_pfecha_derivacion_usurio.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pfecha_derivacion_usurio);
                
                SqlParameter Parameter_pcuce = new SqlParameter("@cuce", SqlDbType.VarChar, 20);
                Parameter_pcuce.Value = pcuce;
                Parameter_pcuce.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pcuce);

                SqlParameter Parameter_pfechaHoraPublicacion = new SqlParameter("@fechaHoraPublicacion", SqlDbType.DateTime, 11);
                Parameter_pfechaHoraPublicacion.Value = pfechaHoraPublicacion;
                Parameter_pfechaHoraPublicacion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pfechaHoraPublicacion);

                SqlParameter Parameter_pfechaHoraLimiteEntrega = new SqlParameter("@fechaHoraLimiteEntrega ", SqlDbType.DateTime, 11);
                Parameter_pfechaHoraLimiteEntrega.Value = pfechaHoraLimiteEntrega;
                Parameter_pfechaHoraLimiteEntrega.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pfechaHoraLimiteEntrega);

               try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
                }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _RegistrarFechaRecepcionFisicaEspecial(int pCodigoEjemplar, int pCodigoMovimiento, int pCodigoPersonaMovimiento, int pper_codigo, int pper_codigo_responsable, string pFechaRecepcionFisico)
        {
            SqlDataReader Lector = null;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("upd_RegistroFechaRecepcionFisicaHojaRutaEspecial", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
            Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

            SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
            Parameter_CodigoMovimiento.Value = pCodigoMovimiento;
            Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

            SqlParameter Parameter_CodPersonaMovimiento = new SqlParameter("@CodPersonaMovimiento", SqlDbType.Int, 11);
            Parameter_CodPersonaMovimiento.Value = pCodigoPersonaMovimiento;
            Parameter_CodPersonaMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodPersonaMovimiento);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

            SqlParameter Parameter_FechaRecepcionFisico = new SqlParameter("@FechaRecepcionFisica", SqlDbType.DateTime, 30);
            Parameter_FechaRecepcionFisico.Value = pFechaRecepcionFisico;
            Parameter_FechaRecepcionFisico.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRecepcionFisico);
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }

        }
        //----------------------------------------------------------------------------------------------------------------------        
   



        public SqlDataReader _RegistrarFechaRecepcionFisica( int pCodigoEjemplar, int pCodigoMovimiento, int pCodigoPersonaMovimiento, int pper_codigo ,int pper_codigo_responsable, string pFechaRecepcionFisico)
        {
            SqlDataReader Lector = null;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            
            SqlCommand SqlCom = new SqlCommand("upd_RegistroFechaRecepcionFisicaHojaRuta", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
            Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

            SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
            Parameter_CodigoMovimiento.Value = pCodigoMovimiento;
            Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

            SqlParameter Parameter_CodPersonaMovimiento = new SqlParameter("@CodPersonaMovimiento", SqlDbType.Int, 11);
            Parameter_CodPersonaMovimiento.Value = pCodigoPersonaMovimiento;
            Parameter_CodPersonaMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodPersonaMovimiento);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = pper_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

            SqlParameter Parameter_FechaRecepcionFisico = new SqlParameter("@FechaRecepcionFisica", SqlDbType.DateTime,30);
            Parameter_FechaRecepcionFisico.Value = pFechaRecepcionFisico;
            Parameter_FechaRecepcionFisico.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRecepcionFisico);
 
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }

        }
//----------------------------------------------------------------------------------------------------------------------        
        //Ever Ivan, para el registro de la fecha de la recepcion fisica del oficio.
        public SqlDataReader _RegistrarFechaRecepcionFisicaOficios(int pRecsal_Codigo, string pRescal_FechaComprobante, int pCodigoDocumento, int pPer_codigo_responsable)
        {
            SqlDataReader Lector = null;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("ins_RecepcionSalidasDocumento", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_recsal_Codigo = new SqlParameter("@recsal_Codigo", SqlDbType.Int, 11);
            Parameter_recsal_Codigo.Value = pRecsal_Codigo;
            Parameter_recsal_Codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_recsal_Codigo);

            SqlParameter Parameter_rescal_FechaComprobante = new SqlParameter("@rescal_FechaComprobante", SqlDbType.Date, 11);
            Parameter_rescal_FechaComprobante.Value = pRescal_FechaComprobante;
            Parameter_rescal_FechaComprobante.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_rescal_FechaComprobante);

            SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
            Parameter_CodigoDocumento.Value = pCodigoDocumento;
            Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDocumento);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pPer_codigo_responsable;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_RegistrarFechaRecepcionFisicaOficios::Produjo un error.", MiExcepcion);
            }

        }
//---------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------
        #endregion
    }
}
