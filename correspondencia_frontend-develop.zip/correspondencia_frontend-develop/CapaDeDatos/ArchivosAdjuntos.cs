﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class ArchivosAdjuntos
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"
        
            public ArchivosAdjuntos()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _CodigoAdjunto { get; set; }
            public string _RutaAdjunto { get; set; }
            public string _NombreAdjunto { get; set; }
            public string _ExtensionAdjunto { get; set; }

        #endregion
        #region "funciones publicas"
        //------------------------------------------------------------------------------
            public bool AdicionarActa(int pCodigoHojaRuta, int pCodigoDocumento, string pRutaAdjunto, string pNombreAdjunto, string pExtensionAdjunto)
            {
                int Resultado = 0;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("ins_ArchivoAdjunto_ActaCierre", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;




                SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
                Parameter_CodigoDocumento.Value = pCodigoDocumento;
                Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoDocumento);

                SqlParameter Parameter_RutaAdjunto = new SqlParameter("@arcadj_RutaAdjunto", SqlDbType.VarChar, 250);
                Parameter_RutaAdjunto.Value = pRutaAdjunto;
                Parameter_RutaAdjunto.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_RutaAdjunto);

                SqlParameter Parameter_NombreAdjunto = new SqlParameter("@arcadj_NombreAdjunto", SqlDbType.VarChar, 250);
                Parameter_NombreAdjunto.Value = pNombreAdjunto;
                Parameter_NombreAdjunto.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_NombreAdjunto);

                SqlParameter Parameter_ExtensionAdjunto = new SqlParameter("@arcadj_ExtensionAdjunto", SqlDbType.VarChar, 10);
                Parameter_ExtensionAdjunto.Value = pExtensionAdjunto;
                Parameter_ExtensionAdjunto.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_ExtensionAdjunto);

                SqlParameter Parameter_codigohr = new SqlParameter("@codigohr", SqlDbType.VarChar, 10);
                Parameter_codigohr.Value = pCodigoHojaRuta;
                Parameter_codigohr.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_codigohr);


                try
                {
                    SqlCon.Open();
                    Resultado = SqlCom.ExecuteNonQuery();
                    //_CodigoAdjunto = Convert.ToInt32(Parameter_CodigoAdjunto.Value);
                    //_CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                }
                catch (Exception MiExcepcion)
                {
                    _CodigoError = -1;
                    throw new Exception("Usuario::Adicion::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
                if (_CodigoError == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

//---------------------------------------------------------------------------------------------------
        public bool Adicionar(int pCodigoDocumento,string pRutaAdjunto, string pNombreAdjunto, string pExtensionAdjunto)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_ArchivoAdjunto_Correlativo", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
            Parameter_CodigoDocumento.Value = pCodigoDocumento;
            Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDocumento);

            SqlParameter Parameter_RutaAdjunto = new SqlParameter("@arcadj_RutaAdjunto", SqlDbType.VarChar, 250);
            Parameter_RutaAdjunto.Value = pRutaAdjunto;
            Parameter_RutaAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_RutaAdjunto);

            SqlParameter Parameter_NombreAdjunto = new SqlParameter("@arcadj_NombreAdjunto", SqlDbType.VarChar, 250);
            Parameter_NombreAdjunto.Value = pNombreAdjunto;
            Parameter_NombreAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombreAdjunto);

            SqlParameter Parameter_ExtensionAdjunto = new SqlParameter("@arcadj_ExtensionAdjunto", SqlDbType.VarChar, 10);
            Parameter_ExtensionAdjunto.Value = pExtensionAdjunto;
            Parameter_ExtensionAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_ExtensionAdjunto);
            
            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                //_CodigoAdjunto = Convert.ToInt32(Parameter_CodigoAdjunto.Value);
                //_CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Usuario::Adicion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
       
//---------------------------------------------------------------------------------------------------
        #endregion
    }
}
