﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CapaDeDatos
{
    public class Instrucciones
    {
        public int CodigoInstruccion
        { get; set; }
        
        //Constructor
        public Instrucciones()
        {
            this.CodigoInstruccion = 0;
        }
        public Instrucciones(int CodigoIntruc)
        {
            this.CodigoInstruccion = CodigoIntruc;
        }

        //Casteador
        public static String CastearXml(List<Instrucciones> lista)
        {
            return ConversionTipos.CastearListaObjetosParaXml(lista, typeof (Instrucciones));

        }



    }
}
