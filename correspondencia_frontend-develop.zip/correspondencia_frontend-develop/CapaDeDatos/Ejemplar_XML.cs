﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CapaDeDatos
{
    class Ejemplar_XML
    {
                    public int CodigoEjemplar;
            //{ get; set; }

            // Constructor
            public Ejemplar_XML()
            {
                this.CodigoEjemplar = 0;
            }

            public Ejemplar_XML(int CodigoEjemplar)
            {
                this.CodigoEjemplar = CodigoEjemplar;
            }

            // Casteador
            public static String CastearXml(List<Ejemplar_XML> lista)
            {
                return ConversionTipos.CastearListaObjetosParaXml(lista, typeof(Ejemplar_XML));
            }
    }
}
