﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CapaDeDatos
{
    public class CorrelativoXML
    {
        public int CodigoDocumento
        { get; set; }

        // Constructor
        public CorrelativoXML()
        {
            this.CodigoDocumento = 0;
        }

        public CorrelativoXML(int CodigoDocumento)
        {
            this.CodigoDocumento = CodigoDocumento;
        }

        // Casteador
        public static String CastearXml(List<CorrelativoXML> lista)
        {
            return ConversionTipos.CastearListaObjetosParaXml(lista, typeof(CorrelativoXML));
        }
    }
}
