﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class HojaRutaRelacionadas
    {
        #region "Variables"
            
            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public HojaRutaRelacionadas()
            {
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion
        #region "Propiedades publicas"

            public int _CodigoHojaRutaRelacionada { get; set; }
            public int _CodigoHojaRuta { get; set; }
            public int _CodigoHojaRuta1 { get; set; }
            public int _CodigoSesion { get; set; }
            
        #endregion
        #region "funciones publicas"

//--------------------------------------------------------
            public bool Adicionar(int pCodigoHojaRuta, int pCodigoHojaRuta1, int pCodigoSesion)
            {
                int Resultado = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("ins_HojaRutaRelacionadas", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                SqlParameter Parameter_CodigoHojaRuta1 = new SqlParameter("@CodigoHojaRuta1", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta1.Value = pCodigoHojaRuta1;
                Parameter_CodigoHojaRuta1.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta1);
                
                SqlParameter Parameter_CodigoSesion = new SqlParameter("@CodigoSesion", SqlDbType.Int, 11);
                Parameter_CodigoSesion.Value = pCodigoSesion;
                Parameter_CodigoSesion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoSesion);
                
                //parametros de salida
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);

                try
                {
                    SqlCon.Open();
                    Resultado = SqlCom.ExecuteNonQuery();
                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                }
                catch (Exception MiExcepcion)
                {
                    _CodigoError = -1;
                    throw new Exception("Usuario::Adicion::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
                if (_CodigoError == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
//--------------------------------------------------------
            public DataSet ObtenerHojasRutaRelacionadas(int pCodigoHojaRuta)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_HojaRutaRelacionadas", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                //parametros de salida
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_hrelacionadas");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//--------------------------------------------------------
//--------------------------------------------------------
//--------------------------------------------------------
        #endregion
    }
}
