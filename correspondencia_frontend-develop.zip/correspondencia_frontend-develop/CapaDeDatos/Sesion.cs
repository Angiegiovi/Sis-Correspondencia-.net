﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class Sesion
    {
        #region "Variables"
            private string _CadenaConexion;
            private int _CodigoError;
        #endregion
        #region "Constructor"

            public Sesion()
            {
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion
        #region "Propiedades públicas"
            public int _Codigo_Sesion { get; set; }
            public int _Codigo_Usuario { get; set; }
            public string _Identificador_Sesion { get; set; }
            public string _Desde_Sesion { get; set; }
            public string _Hasta_Sesion { get; set; }
        #endregion
        #region "Funciones públicas"
//------------------------------------------------------------------------------------------------
            public bool Adicionar(int pCodigo_Usuario, string pIdentificador_Sesion)
            {
                int Resultado;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("ins_Sesion", SqlCon);
                
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Codigo_Usuario = new SqlParameter("@Codigo_Usuario", SqlDbType.Int, 4);
                Parameter_Codigo_Usuario.Value = pCodigo_Usuario;
                Parameter_Codigo_Usuario.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Codigo_Usuario);
                
                SqlParameter Parameter_Identificador_Sesion = new SqlParameter("@Identificador_Sesion", SqlDbType.VarChar, 250);
                Parameter_Identificador_Sesion.Value = pIdentificador_Sesion;
                Parameter_Identificador_Sesion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Identificador_Sesion);
                
                //parametros de salida
                SqlParameter Parameter_Codigo_Sesion = new SqlParameter("@Codigo_Sesion", SqlDbType.Int, 4);
                Parameter_Codigo_Sesion.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_Codigo_Sesion);
                
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);
                try
                {
                    SqlCon.Open();
                    Resultado = SqlCom.ExecuteNonQuery();
                    _Codigo_Sesion = Convert.ToInt32(Parameter_Codigo_Sesion.Value);
                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                }
                catch (Exception MiExcepcion)
                {
                    _CodigoError = -1;
                    throw new Exception("Sesion::Adicionar::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
                if (_CodigoError == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
//------------------------------------------------------------------------------------------------
            public bool Actualizar(int pCodigo_Sesion)
            {
                int Resultado;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("upd_Sesion", SqlCon);
                
                SqlCom.CommandType = CommandType.StoredProcedure;
                
                SqlParameter Parameter_Codigo_Sesion = new SqlParameter("@Codigo_Sesion", SqlDbType.Int, 4);
                Parameter_Codigo_Sesion.Value = pCodigo_Sesion;
                Parameter_Codigo_Sesion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Codigo_Sesion);
                
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);
                try
                {
                    SqlCon.Open();
                    Resultado = SqlCom.ExecuteNonQuery();
                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                }
                catch (Exception MiExcepcion)
                {
                    _CodigoError = -1;
                    throw new Exception("Sesion::Actualizar::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
                if (_CodigoError == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }  
//--------------------------------------------------------------
        #endregion
    }
}
