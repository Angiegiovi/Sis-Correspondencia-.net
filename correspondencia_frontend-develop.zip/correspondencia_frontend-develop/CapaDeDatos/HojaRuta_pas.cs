﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI;

namespace CapaDeDatos
{
    public class HojaRuta
    {
        #region "Variables"
            
            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"
            
            public HojaRuta()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion

            #region "Propiedades publicas"

            public int _CodigoHojaRuta { get; set; }
            public string _Referencia { get; set; }
            public string _Procedencia { get; set; }
            public string _FechaRegistro { get; set; }
            public int _CodigoEstado { get; set; }
            public int _CodigoTipoHojaRuta { get; set; }
            public string _CodigoCorrelatvo { get; set; }
            public string _FechaRecepcion { get; set; }
            public string _CodigoCorrespondencia { get; set; }

            public string _HoraRegistro { get; set; }
            public string _HoraRecepcion { get; set; }
            public string _CITE { get; set; }
            public char _PQ { get; set; }

            public int _EnUso { get; set; }
            public string _Anexos { get; set; }

        #endregion
        #region "funciones publicas"
//-----------------------------------------------------------------------------------------------
       public DataSet _ObtenerSolicitudOficio(int per_codigo, string NumeroCorrelativo)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_CorrelativoDocumento_oficios", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                //parametros de salida
                /*     SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 4);
                    Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                      SqlCom.Parameters.Add(Parameter_CodigoDeError);*/



                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = per_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_NumeroCorrelativo = new SqlParameter("@NumeroCorrelativo", SqlDbType.VarChar, 150);
                Parameter_NumeroCorrelativo.Value = NumeroCorrelativo;
                Parameter_NumeroCorrelativo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_NumeroCorrelativo);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "RadGridOFICIO");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosElementos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-----------------------------------------------------------------------------------------------
       public SqlDataReader _ModificarCambiosdeEstado(int CodigoEstado, int CodigoEjemplar, int CodigoMovimiento, int CodPersonaMovimiento, int per_codigo_responsable)
       {
           SqlDataReader Lector;

           SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
           SqlCommand SqlCom = new SqlCommand("upd_CambiosEstadoHojaRuta", SqlCon);

           SqlCom.CommandType = CommandType.StoredProcedure;

           SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
           Parameter_CodigoEstado.Value = CodigoEstado;
           Parameter_CodigoEstado.Direction = ParameterDirection.Input;
           SqlCom.Parameters.Add(Parameter_CodigoEstado);

           SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.VarChar, 600);
           Parameter_CodigoEjemplar.Value = CodigoEjemplar;
           Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
           SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

           SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.VarChar, 600);
           Parameter_CodigoMovimiento.Value = CodigoMovimiento;
           Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
           SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

           SqlParameter Parameter_CodPersonaMovimiento = new SqlParameter("@CodPersonaMovimiento", SqlDbType.Int, 11);
           Parameter_CodPersonaMovimiento.Value = CodPersonaMovimiento;
           Parameter_CodPersonaMovimiento.Direction = ParameterDirection.Input;
           SqlCom.Parameters.Add(Parameter_CodPersonaMovimiento);

           SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
           Parameter_per_codigo_responsable.Value = per_codigo_responsable;
           Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
           SqlCom.Parameters.Add(Parameter_per_codigo_responsable);
          try
           {
               SqlCon.Open();
               Lector = SqlCom.ExecuteReader();
               if (Lector.Read())
               {
                   return Lector;
               }
               return null;
           }
           catch (Exception MiExcepcion)
           {
               throw new Exception("Usuario::_Actualizar::Produjo un error.", MiExcepcion);
           }
       }
//-------------------------------------------------------------------------------------------
            public SqlDataReader _AnularCorrelativoList(int CodigoDocumento, int per_codigo_responsable)
            {
                SqlDataReader Lector;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("ins_AnularCorrelativoDocumento", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento ", SqlDbType.Int, 11);
                Parameter_CodigoDocumento.Value = CodigoDocumento;
                Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoDocumento);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);
                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Anular correltivo produjo un error.", MiExcepcion);
                }
            
            }
//-----------------------------------------------------------------------------------------------------------------
            public SqlDataReader _ConfirmarDerivacionHR(int CodPersonaMovimiento, int per_codigo, int per_codigo_responsable)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("upd_ConfirmarDerivacionHR", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodPersonaMovimiento = new SqlParameter("@CodPersonaMovimiento", SqlDbType.Int, 11);
                Parameter_CodPersonaMovimiento.Value = CodPersonaMovimiento;
                Parameter_CodPersonaMovimiento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodPersonaMovimiento);

                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_per_codigo.Value = per_codigo;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Insertar Copia de Hoja Ruta::Produjo un error.", MiExcepcion);
                }
            }
//-----------------------------------------------------------------------------------------------
            public DataSet _ElementosporConfirmar(int per_codigo ,string  Correlativo, int per_codigo_responsable)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_BandejaPorConfirmar", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                //parametros de salida
                /*     SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 4);
                    Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                      SqlCom.Parameters.Add(Parameter_CodigoDeError);*/



                SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int , 11);
                Parameter_per_codigo.Value = per_codigo ;
                Parameter_per_codigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo);

                SqlParameter Parameter_Correlativo = new SqlParameter("@CodigoSistema", SqlDbType.VarChar, 150);
                Parameter_Correlativo.Value = Correlativo;
                Parameter_Correlativo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Correlativo);

                SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_per_codigo_responsable.Value = per_codigo_responsable;
                Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "RadGridELE");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosElementos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-----------------------------------------------------------------------------------------------

            public DataSet _ObtenerBandejasAsignadasPorUsuario(int Estado, string Busqueda, int per_codigo_administrado, int per_codigo_administra, int CodigoRol)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_Personas_Rol", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Estado = new SqlParameter("@Estado", SqlDbType.Int, 11);
                Parameter_Estado.Value = Estado;
                Parameter_Estado.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Estado);

                SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, (30));
                Parameter_Busqueda.Value = Busqueda;
                Parameter_Busqueda.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Busqueda);

                SqlParameter Parameter_per_codigo_administrado = new SqlParameter("@per_codigo_administrado", SqlDbType.Int, 11);
                Parameter_per_codigo_administrado.Value = per_codigo_administrado;
                Parameter_per_codigo_administrado.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_administrado);

                SqlParameter Parameter_per_codigo_administra = new SqlParameter("@per_codigo_administra", SqlDbType.Int, 11);
                Parameter_per_codigo_administra.Value = per_codigo_administra;
                Parameter_per_codigo_administra.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_per_codigo_administra);


                SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
                Parameter_CodigoRol.Value = CodigoRol;
                Parameter_CodigoRol.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoRol);



                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_asignacion");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//-------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------
        public DataSet _ObtenerCorrespondencia(string pCodigoUsuario, int pCriterio, string pBusqueda, int pCodigoRol, int pCodigoResidencia)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_Correspondencia", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlParameter Parameter_Criterio = new SqlParameter("@Criterio", SqlDbType.Int, 1);
            Parameter_Criterio.Value = pCriterio;
            Parameter_Criterio.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Criterio);

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            SqlParameter Parameter_CodigoRol = new SqlParameter("@CodigoRol", SqlDbType.Int, 11);
            Parameter_CodigoRol.Value = pCodigoRol;
            Parameter_CodigoRol.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoRol);

            //SqlParameter Parameter_CodigoResidencia = new SqlParameter("@CodigoResidencia", SqlDbType.Int, 11);
            //Parameter_CodigoResidencia.Value = pCodigoResidencia;
            //Parameter_CodigoResidencia.Direction = ParameterDirection.Input;
            //SqlCom.Parameters.Add(Parameter_CodigoResidencia);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_corres");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _AdicionarCorrespondencia(string pNombrePersnaExterna, string pCargoTranscrito, int pCodigoCargo, int pPer_codigo_remitente, int pCodigoO_entidad, string pReferencia, string pProcedencia, int pCodigoTipoHoja, string pFechaRecepcion, string pCodigoCorrespondencia, int pPQ, string pCITE, int pTipoCorrespondencia, int cper_codigo)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_HojaRutaCorrespondencia", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_nombrePersona = new SqlParameter("@nombrePersonaExterna", SqlDbType.VarChar, 600);
            Parameter_nombrePersona.Value = pNombrePersnaExterna;
            Parameter_nombrePersona.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_nombrePersona);

            SqlParameter Parameter_cargoTranscrito = new SqlParameter("@cargoTranscrito", SqlDbType.VarChar, 600);
            Parameter_cargoTranscrito.Value = pCargoTranscrito;
            Parameter_cargoTranscrito.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_cargoTranscrito);

            SqlParameter Parameter_CodigoCargoPE = new SqlParameter("@CodigoCargoPE", SqlDbType.Int, 11);
            Parameter_CodigoCargoPE.Value = pCodigoCargo;
            Parameter_CodigoCargoPE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoCargoPE);

            SqlParameter Parameter_CodigoO = new SqlParameter("@CodigoO", SqlDbType.Int, 11);
            Parameter_CodigoO.Value = pCodigoO_entidad;
            Parameter_CodigoO.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoO);

            SqlParameter Parameter_per_codigo_remitente = new SqlParameter("@per_codigo_remitente", SqlDbType.Int, 11);
            Parameter_per_codigo_remitente.Value = pPer_codigo_remitente;
            Parameter_per_codigo_remitente.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_remitente);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 600);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 600);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            SqlParameter Parameter_CodigoTipoHoja = new SqlParameter("@CodigoTipoHoja", SqlDbType.Int, 11);
            Parameter_CodigoTipoHoja.Value = pCodigoTipoHoja;
            Parameter_CodigoTipoHoja.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoHoja);

            SqlParameter Parameter_FechaRecepcion = new SqlParameter("@FechaRecepcion", SqlDbType.DateTime, 30);
            Parameter_FechaRecepcion.Value = pFechaRecepcion;
            Parameter_FechaRecepcion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRecepcion);

            SqlParameter Parameter_CodigoCorrespondencia = new SqlParameter("@CodigoCorrespondencia", SqlDbType.VarChar, 100);
            Parameter_CodigoCorrespondencia.Value = pCodigoCorrespondencia;
            Parameter_CodigoCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoCorrespondencia);

            SqlParameter Parameter_PQ = new SqlParameter("@PQ", SqlDbType.Int, 5);
            Parameter_PQ.Value = pPQ;
            Parameter_PQ.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_PQ);

            SqlParameter Parameter_CITE = new SqlParameter("@CITE", SqlDbType.VarChar, 250);
            Parameter_CITE.Value = pCITE;
            Parameter_CITE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CITE);

            SqlParameter Parameter_TipoCorrespondencia = new SqlParameter("@tipo_correspondencia", SqlDbType.Int, 5);
            Parameter_TipoCorrespondencia.Value = pTipoCorrespondencia;
            Parameter_TipoCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_TipoCorrespondencia);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = cper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _AdicionarHojaRutaInterna(string pReferencia, string pProcedencia, string pComentarios, string xml_instrucciones, string xml_remitentes, string xml_destinatarios, int cper_codigo, int cper_codigo_responsable,string xml_correlativos)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_HojaRutaInterna", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 600);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 600);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            SqlParameter Parameter_Comentarios = new SqlParameter("@Comentarios", SqlDbType.VarChar, 250);
            Parameter_Comentarios.Value = pComentarios;
            Parameter_Comentarios.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Comentarios);

            SqlParameter Parameter_xml_instrucciones = new SqlParameter("@xml_instrucciones", SqlDbType.Xml, 1000);
            Parameter_xml_instrucciones.Value = xml_instrucciones;
            Parameter_xml_instrucciones.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_xml_instrucciones);

            SqlParameter Parameter_xml_remitentes = new SqlParameter("@xml_remitentes", SqlDbType.Xml, 1000);
            Parameter_xml_remitentes.Value = xml_remitentes;
            Parameter_xml_remitentes.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_xml_remitentes);

            SqlParameter Parameter_xml_destinatarios = new SqlParameter("@xml_destinatarios", SqlDbType.Xml, 1000);
            Parameter_xml_destinatarios.Value = xml_destinatarios;
            Parameter_xml_destinatarios.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_xml_destinatarios);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = cper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = cper_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

            SqlParameter Parameter_xml_correlativos = new SqlParameter("@correlativos_xml", SqlDbType.Xml, 1000);
            Parameter_xml_correlativos.Value = xml_correlativos;
            Parameter_xml_correlativos.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_xml_correlativos);
            // aumentar correlativos                 
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
       //Ever Ivan
        public SqlDataReader _ObtenerCorrespondenciaPorID(int pCodigoHojaRuta)
        {
            SqlDataReader Lector = null;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_CorrespondenciaPorId", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_ObtenerCorrespondenciaPorID::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _ModificarCorrespondencia( int pCodigoHojaRuta,string pNombrePersnaExterna, string pCargoTranscrito, int pCodigoCargo, int pPer_codigo_remitente, int pCodigoO_entidad, string pReferencia, string pProcedencia, int pCodigoTipoHoja, string pFechaRecepcion, string pCodigoCorrespondencia, int pPQ, string pCITE, int pTipoCorrespondencia, int cper_codigo)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_HojaRutaCorrespondencia", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_nombrePersona = new SqlParameter("@nombrePersonaExterna", SqlDbType.VarChar, 600);
            Parameter_nombrePersona.Value = pNombrePersnaExterna;
            Parameter_nombrePersona.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_nombrePersona);

            SqlParameter Parameter_cargoTranscrito = new SqlParameter("@cargoTranscrito", SqlDbType.VarChar, 600);
            Parameter_cargoTranscrito.Value = pCargoTranscrito;
            Parameter_cargoTranscrito.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_cargoTranscrito);

            SqlParameter Parameter_CodigoCargoPE = new SqlParameter("@CodigoCargoPE", SqlDbType.Int, 11);
            Parameter_CodigoCargoPE.Value = pCodigoCargo;
            Parameter_CodigoCargoPE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoCargoPE);

            SqlParameter Parameter_CodigoO = new SqlParameter("@CodigoO", SqlDbType.Int, 11);
            Parameter_CodigoO.Value = pCodigoO_entidad;
            Parameter_CodigoO.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoO);

            SqlParameter Parameter_per_codigo_remitente = new SqlParameter("@per_codigo_remitente", SqlDbType.Int, 11);
            Parameter_per_codigo_remitente.Value = pPer_codigo_remitente;
            Parameter_per_codigo_remitente.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_remitente);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 600);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 600);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            SqlParameter Parameter_CodigoTipoHoja = new SqlParameter("@CodigoTipoHoja", SqlDbType.Int, 11);
            Parameter_CodigoTipoHoja.Value = pCodigoTipoHoja;
            Parameter_CodigoTipoHoja.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoHoja);

            SqlParameter Parameter_FechaRecepcion = new SqlParameter("@FechaRecepcion", SqlDbType.DateTime, 30);
            Parameter_FechaRecepcion.Value = pFechaRecepcion;
            Parameter_FechaRecepcion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRecepcion);

            SqlParameter Parameter_CodigoCorrespondencia = new SqlParameter("@CodigoCorrespondencia", SqlDbType.VarChar, 100);
            Parameter_CodigoCorrespondencia.Value = pCodigoCorrespondencia;
            Parameter_CodigoCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoCorrespondencia);

            SqlParameter Parameter_PQ = new SqlParameter("@PQ", SqlDbType.Int, 5);
            Parameter_PQ.Value = pPQ;
            Parameter_PQ.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_PQ);

            SqlParameter Parameter_CITE = new SqlParameter("@CITE", SqlDbType.VarChar, 250);
            Parameter_CITE.Value = pCITE;
            Parameter_CITE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CITE);

            SqlParameter Parameter_TipoCorrespondencia = new SqlParameter("@tipo_correspondencia", SqlDbType.Int, 5);
            Parameter_TipoCorrespondencia.Value = pTipoCorrespondencia;
            Parameter_TipoCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_TipoCorrespondencia);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = cper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _CambioEstadoHojaRuta(int pCodigoHojaRuta, int pCodigoEstado)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("upd_CambioEstadoHojaRuta", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoEstado.Value = pCodigoHojaRuta;
            Parameter_CodigoEstado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEstado);

            SqlParameter Parameter_Valor = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
            Parameter_Valor.Value = pCodigoEstado;
            Parameter_Valor.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Valor);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet _BusquedaRegistroCorrespondencia(string pFechaRegistro, string pCorrelativoCorrespondenciaIni, string pCorrelativoCorrespondenciaFin , int pCodigoUsuario)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_HojasRutasRegistradasPorCorrespondencia", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_FechaRegistro = new SqlParameter("@FechaRegistro", SqlDbType.Date);
            Parameter_FechaRegistro.Value = pFechaRegistro;
            Parameter_FechaRegistro.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRegistro);

            SqlParameter Parameter_CorrelativoCorrespondenciaIni = new SqlParameter("@CorrelativoCorrespondenciaIni", SqlDbType.Int, 11);
            Parameter_CorrelativoCorrespondenciaIni.Value = pCorrelativoCorrespondenciaIni;
            Parameter_CorrelativoCorrespondenciaIni.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CorrelativoCorrespondenciaIni);

            SqlParameter Parameter_CorrelativoCorrespondenciaFin = new SqlParameter("@CorrelativoCorrespondenciaFin", SqlDbType.Int, 11);
            Parameter_CorrelativoCorrespondenciaFin.Value = pCorrelativoCorrespondenciaFin;
            Parameter_CorrelativoCorrespondenciaFin.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CorrelativoCorrespondenciaFin);

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoUsuario", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);


            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_busqueda");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet _ObtenerBandejaEntrada(int pCodigoUsuario, string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_BandejaEntrada", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlParameter Parameter_Busqueda = new SqlParameter("@CodigoSistema", SqlDbType.VarChar, 150);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_hojaR");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet _ObtenerBandejaEnviados(int pCodigoUsuario, string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_BandejaEnviados", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlParameter Parameter_Busqueda = new SqlParameter("@CodigoSistema", SqlDbType.VarChar, 150);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_hojaR");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
 //--------------------------------------------------------------------------------------
        public SqlDataReader _CambiarDeEstadoHR(int pEstado, int pCodigoEjemplar, int pCodigoMovimiento, int pCodigoPersonaMovimiento, int pper_codigo)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("upd_CambiosEstadoHojaRuta", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
            Parameter_CodigoEstado.Value = pEstado;
            Parameter_CodigoEstado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEstado);

            SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
            Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

            SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
            Parameter_CodigoMovimiento.Value = pCodigoMovimiento;
            Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

            SqlParameter Parameter_CodPersonaMovimiento = new SqlParameter("@CodPersonaMovimiento", SqlDbType.Int, 11);
            Parameter_CodPersonaMovimiento.Value = pCodigoPersonaMovimiento;
            Parameter_CodPersonaMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodPersonaMovimiento);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = pper_codigo;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

            
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
            }
        }
//------------------------------------------------------------------------------------------
        public DataSet ObtenerTodasLasHojasDeRuta(string pCodigoUsuario, int pCodigoEstadoHR, int pCriterio, string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_DocRecibidos", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoUsuario", SqlDbType.VarChar, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlParameter Parameter_CodigoEstadoHR = new SqlParameter("@CodigoEstadoHR", SqlDbType.Int, 4);
            Parameter_CodigoEstadoHR.Value = pCodigoEstadoHR;
            Parameter_CodigoEstadoHR.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEstadoHR);

            SqlParameter Parameter_Criterio = new SqlParameter("@Criterio", SqlDbType.Int, 11);
            Parameter_Criterio.Value = pCriterio;
            Parameter_Criterio.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Criterio);

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_recibidos");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet _Detalle_hoja_de_Ruta(int CodigoHojaRuta)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_provehido_ejemplar", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = CodigoHojaRuta;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "RadGridFlujo");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet _Crear_Grupo_HR(int pCodigoUsuario, int pCodigoEjemplar )
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_Bandeja_para_agrupar", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;
            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pCodigoUsuario;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlCom.CommandType = CommandType.StoredProcedure;
            SqlParameter Parameter_pBusqueda = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_pBusqueda.Value = pCodigoEjemplar;
            Parameter_pBusqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_pBusqueda);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "RadGridGrupo");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }  
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _Insertar_CopiaHojaRuta(int CodigoHojaRuta,int CodigoEjemplar, int CodigoMovimiento, int CodiPersonaMovimiento, int per_codigo_responsable)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_copiar_ejemplar", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = CodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 11);
            Parameter_CodigoEjemplar.Value = CodigoEjemplar;
            Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

            SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
            Parameter_CodigoMovimiento.Value = CodigoMovimiento;
            Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

            SqlParameter Parameter_Comentarios = new SqlParameter("@CodPersonaMovimiento", SqlDbType.Int, 11);
            Parameter_Comentarios.Value = CodiPersonaMovimiento;
            Parameter_Comentarios.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Comentarios);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = per_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);



           try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_Insertar Copia de Hoja Ruta::Produjo un error.", MiExcepcion);
            }
        }
//------------------------------

//---------------------------------------------------------------------------------------------------
        public bool ModificarHRNueva(int pCodigoHojaRuta, string pReferencia, int pCodigoEstadoHR, int pCodigoTipoHojaRuta, string pProcedencia)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_HojaRutaInterna", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 250);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_CodigoEstadoHR = new SqlParameter("@CodigoEstadoHR", SqlDbType.Int, 11);
            Parameter_CodigoEstadoHR.Value = pCodigoEstadoHR;
            Parameter_CodigoEstadoHR.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEstadoHR);

            SqlParameter Parameter_CodigoTipoHojaRuta = new SqlParameter("@CodigoTipoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoTipoHojaRuta.Value = pCodigoTipoHojaRuta;
            Parameter_CodigoTipoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoHojaRuta);

            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 250);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            //parametrso de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoHojaRuta = Convert.ToInt32(Parameter_CodigoHojaRuta.Value);
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Contrato::Modificacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool ModificarCorrespondencia(int pCodigoHojaRuta, string pProcedencia, string pReferencia, string pFechaRecepcion, string pCorrSistema, int pCodigoTipoHojaRuta, string pCorrCorrespondencia, char pPQ, string pCITE)
        {
            int Resultado = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_HojaRutaCorrespondencia", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 250);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 650);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_FechaRecepcion = new SqlParameter("@FechaRecepcion", SqlDbType.VarChar, 20);
            Parameter_FechaRecepcion.Value = pFechaRecepcion;
            Parameter_FechaRecepcion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRecepcion);

            SqlParameter Parameter_CorrSistema = new SqlParameter("@CorrSistema", SqlDbType.VarChar, 100);
            Parameter_CorrSistema.Value = pCorrSistema;
            Parameter_CorrSistema.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CorrSistema);

            SqlParameter Parameter_CodigoTipoHojaRuta = new SqlParameter("@CodigoTipoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoTipoHojaRuta.Value = pCodigoTipoHojaRuta;
            Parameter_CodigoTipoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoHojaRuta);

            SqlParameter Parameter_CorrCorrespondencia = new SqlParameter("@CorrCorrespondencia", SqlDbType.VarChar, 100);
            Parameter_CorrCorrespondencia.Value = pCorrCorrespondencia;
            Parameter_CorrCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CorrCorrespondencia);

            SqlParameter Parameter_PQ = new SqlParameter("@PQ", SqlDbType.Char, 1);
            Parameter_PQ.Value = pPQ;
            Parameter_PQ.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_PQ);

            SqlParameter Parameter_CITE = new SqlParameter("@CITE", SqlDbType.VarChar, 250);
            Parameter_CITE.Value = pCITE;
            Parameter_CITE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CITE);


            //parametrso de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoHojaRuta = Convert.ToInt32(Parameter_CodigoHojaRuta.Value);
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Contrato::Modificacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//+--------------------------------------------------------------------------------------------------
        public bool ObtenerCabecera(int pCodigoHojaRuta)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_HojaRutaDatos", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoHojaRuta = Convert.ToInt32(Parameter_CodigoHojaRuta.Value);
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Contrato::Modificacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool Eliminar(int pCodigoHojaRuta, int pCodigoFlujo)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_HojaRuta", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoEstado.Value = pCodigoHojaRuta;
            Parameter_CodigoEstado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEstado);

            SqlParameter Parameter_CodigoFlujo = new SqlParameter("@CodigoFlujo", SqlDbType.Int, 11);
            Parameter_CodigoFlujo.Value = pCodigoFlujo;
            Parameter_CodigoFlujo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoFlujo);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Rol::Eliminacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool ObtenerHRPorID(int pCodigoHojaRuta)
        {
            SqlDataReader Lector = null;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("sel_HojaRutaPorId", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            //parametro de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    _CodigoHojaRuta = Convert.ToInt32(Lector["campo1"]);
                    _Referencia = Lector["campo2"].ToString();
                    _Procedencia = Lector["nombreProcedencia"].ToString();

                    _CodigoCorrelatvo = Lector["campo7"].ToString();
                    //_CodigoTipoHoja = Convert.ToInt32(Lector["campo8"]);
                    //_CodigoRecibido = Convert.ToInt32(Lector["campo9"]);
                    //_CodigoSeguimiento = Lector["CodigoSeguimiento"].ToString();

                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);

                    Lector.Close();
                    SqlCon.Close();

                    if (_CodigoError == 0)
                    {
                        //    EstablecerPoliticaPrincipal(_CodigoUsuario, _LoginUsuario)
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    Lector.Close();
                    SqlCon.Close();
                    _CodigoError = -1;
                    return false;
                }
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::RecuperarUsuarioPorCodigo::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet ObtenerComboDeHR(int pCodigoUsuario)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_ComboHojaRuta", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoUsuario", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "comboDeHR");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool ObtenerHojaRutaPorID(int pCodigoHojaRuta)
        {
            SqlDataReader Lector = null;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("sel_HojaRutaPorId", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            //parametro de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    _CodigoHojaRuta = Convert.ToInt32(Lector["CodigoHojaRuta"]);
                    _Referencia = Lector["Referencia"].ToString();
                    _Procedencia = Lector["Procedencia"].ToString();

                    //_CodigoEstadoHR = Convert.ToInt32(Lector["campo7"]);
                    //_CodigoTipoHoja = Convert.ToInt32(Lector["campo8"]);
                    //_CodigoRecibido = Convert.ToInt32(Lector["campo9"]);
                    //_CodigoSeguimiento = Lector["CodigoSeguimiento"].ToString();

                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);

                    Lector.Close();
                    SqlCon.Close();

                    if (_CodigoError == 0)
                    {
                        //    EstablecerPoliticaPrincipal(_CodigoUsuario, _LoginUsuario)
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    Lector.Close();
                    SqlCon.Close();
                    _CodigoError = -1;
                    return false;
                }
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::RecuperarUsuarioPorCodigo::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------
        public DataSet BusquedaAvanzada(int pVProcedencia, int pCProcedencia, string pProcedencia, int pVReferencia, string pReferencia,int pVFechaReg, string pDFechaReg1, string pDFechaReg2, int pVCodigo, string pCodigo1, string pCodigo2, int pVFechaDoc, string pFechaDoc)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_BusquedaAvanzada", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_VProcedencia = new SqlParameter("@VProcedencia", SqlDbType.Int, 1);
            Parameter_VProcedencia.Value = pVProcedencia;
            Parameter_VProcedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_VProcedencia);

            SqlParameter Parameter_CProcedencia = new SqlParameter("@CProcedencia", SqlDbType.Int, 1);
            Parameter_CProcedencia.Value = pCProcedencia;
            Parameter_CProcedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CProcedencia);

            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 250);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            SqlParameter Parameter_VReferencia = new SqlParameter("@VReferencia", SqlDbType.Int, 1);
            Parameter_VReferencia.Value = pVReferencia;
            Parameter_VReferencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_VReferencia);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 250);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_VFechaReg = new SqlParameter("@VFechaReg", SqlDbType.Int, 1);
            Parameter_VFechaReg.Value = pVFechaReg;
            Parameter_VFechaReg.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_VFechaReg);
                
            SqlParameter Parameter_DFechaReg1 = new SqlParameter("@DFechaReg1", SqlDbType.VarChar, 15);
            Parameter_DFechaReg1.Value = pDFechaReg1;
            Parameter_DFechaReg1.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DFechaReg1);

            SqlParameter Parameter_DFechaReg2 = new SqlParameter("@DFechaReg2", SqlDbType.VarChar, 15);
            Parameter_DFechaReg2.Value = pDFechaReg2;
            Parameter_DFechaReg2.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DFechaReg2);
                    
            SqlParameter Parameter_VCodigo = new SqlParameter("@VCodigo", SqlDbType.Int, 1);
            Parameter_VCodigo.Value = pVCodigo;
            Parameter_VCodigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_VCodigo);

            SqlParameter Parameter_Codigo1 = new SqlParameter("@Codigo1", SqlDbType.VarChar, 20);
            Parameter_Codigo1.Value = pCodigo1;
            Parameter_Codigo1.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Codigo1);

            SqlParameter Parameter_Codigo2 = new SqlParameter("@Codigo2", SqlDbType.VarChar, 20);
            Parameter_Codigo2.Value = pCodigo2;
            Parameter_Codigo2.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Codigo2);

            SqlParameter Parameter_VFechaDoc = new SqlParameter("@VFechaDoc", SqlDbType.Int, 1);
            Parameter_VFechaDoc.Value = pVFechaDoc;
            Parameter_VFechaDoc.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_VFechaDoc);
 
            SqlParameter Parameter_FechaDoc = new SqlParameter("@FechaDoc", SqlDbType.VarChar, 11);
            Parameter_FechaDoc.Value = pFechaDoc;
            Parameter_FechaDoc.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDoc);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_busqueda");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet BusquedaAvanzadaGral(string pSQL)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_BusquedaAvanzada", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_SQL = new SqlParameter("@query", SqlDbType.VarChar, 4000);
            Parameter_SQL.Value = pSQL;
            Parameter_SQL.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_SQL);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_busqueda");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet ObtenerBandejaEntradaAlertas(int pCodigoUsuario)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_HojasRutaAlertas", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoUsuario", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_hojaR");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet ObtenerCorrespondenciaAlertas()
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_CorrespondenciaAlertas", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_hojaR");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
       
//---------------------------------------------------------------------------------------------------
        // Ever Ivan, BUSQUEDA AVANZADA de hoja de ruta
        public DataSet _BusquedaHR(int pPercodigo, string pProcedencia, string pReferencia, string FechaRegistro_desde, string FechaRegistro_hasta, string pCodigoSistema, string pCorrelativoCorrespondencia, string pCodigoTipoHojaRuta, string pCodigoEstado)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_BusquedaHojaRuta", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;
            
            //Datos del formulario
            SqlParameter Parameter_PerCodigo = new SqlParameter("@per_codigo", SqlDbType.Int , 600);
            Parameter_PerCodigo.Value = pPercodigo;
            Parameter_PerCodigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_PerCodigo);
            
            SqlParameter Parameter_Procedencia = new SqlParameter("@Procedencia", SqlDbType.VarChar, 600);
            Parameter_Procedencia.Value = pProcedencia;
            Parameter_Procedencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Procedencia);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 600);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_FechaRegistro_desde = new SqlParameter("@FechaRegistro_desde", SqlDbType.DateTime, 30);
            Parameter_FechaRegistro_desde.Value = FechaRegistro_desde;
            Parameter_FechaRegistro_desde.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRegistro_desde);            

            SqlParameter Parameter_FechaRegistro_hasta = new SqlParameter("@FechaRegistro_hasta", SqlDbType.DateTime, 30);
            Parameter_FechaRegistro_hasta.Value = FechaRegistro_hasta;
            Parameter_FechaRegistro_hasta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRegistro_hasta);

            SqlParameter Parameter_CodigoSistema = new SqlParameter("@CodigoSistema", SqlDbType.VarChar, 150);
            Parameter_CodigoSistema.Value = pCodigoSistema;
            Parameter_CodigoSistema.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSistema);

            SqlParameter Parameter_CorrelativoCorrespondencia = new SqlParameter("@CorrelativoCorrespondencia", SqlDbType.VarChar, 150);
            Parameter_CorrelativoCorrespondencia.Value = pCorrelativoCorrespondencia;
            Parameter_CorrelativoCorrespondencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CorrelativoCorrespondencia);

            SqlParameter Parameter_CodigoTipoHojaRuta = new SqlParameter("@CodigoTipoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoTipoHojaRuta.Value = pCodigoTipoHojaRuta;
            Parameter_CodigoTipoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoHojaRuta);

            SqlParameter Parameter_CodigoEstado = new SqlParameter("@CodigoEstado", SqlDbType.Int, 11);
            Parameter_CodigoEstado.Value = pCodigoEstado;
            Parameter_CodigoEstado.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEstado);
            
            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_busqueda");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        
//---------------------------------------------------------------------------------------------------
        public DataSet BusquedaHojaRutaRelacionadas(int pCodigoFuncionario, int pCriterio, string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_BusquedaHojaRutaRelacionadas", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoFuncionario = new SqlParameter("@CodigoFuncionario", SqlDbType.Int, 11);
            Parameter_CodigoFuncionario.Value = pCodigoFuncionario;
            Parameter_CodigoFuncionario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoFuncionario);
            
            SqlParameter Parameter_Criterio = new SqlParameter("@Criterio", SqlDbType.Int, 11);
            Parameter_Criterio.Value = pCriterio;
            Parameter_Criterio.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Criterio);

            SqlParameter Parameter_pBusqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 4000);
            Parameter_pBusqueda.Value = pBusqueda;
            Parameter_pBusqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_pBusqueda);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_busqueda");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        
//---------------------------------------------------------------------------------------------------
        #endregion
    }
}
