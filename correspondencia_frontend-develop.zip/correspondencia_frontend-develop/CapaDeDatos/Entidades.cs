﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class Entidades
    {
        #region "Variables"

            private string _CadenaConexionBDEntidades;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public Entidades()
            {
                //_CadenaConexionBDEntidades = WebConfigurationManager.AppSettings["CadenaDeConexionEntidades"];
                _CadenaConexionBDEntidades = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
                //_CadenaConexionBDEntidades = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        
        #endregion
        #region "Propiedades publicas"

            public int _CodigoO { get; set; }
            public string _RazonSocialE { get; set; }
            public string _SiglaE { get; set; }

        #endregion
        #region "funciones publicas"
//---------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------
      
//---------------------------------------------------------------------------------------------------
       
//---------------------------------------------------------------------------------------------------
       
//---------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------
        public DataSet BuscarEntidades(string pBusqueda)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexionBDEntidades);

            SqlCommand SqlCom = new SqlCommand("sel_BuscarEntidades", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Busqueda = new SqlParameter("@Busqueda", SqlDbType.VarChar, 250);
            Parameter_Busqueda.Value = pBusqueda;
            Parameter_Busqueda.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Busqueda);

             SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "foundEntidades");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        #endregion
    }
        
}
