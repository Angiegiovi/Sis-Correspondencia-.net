﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class MAEUnidades
    {
        #region "Variables"
            
            private string _CadenaConexion;
            private int _CodigoError;

        #endregion

        #region "Constructor"

            public MAEUnidades()
            {
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion

        #region "Propiedades publicas"

            public int _maeuni_Codigo { get; set; }
            public int _per_Codigo { get; set; }
            public int _uni_Codigo { get; set; }
            public int _maeuni_Estado { get; set; }
            public DateTime _maeuni_FechaRegistro { get; set; }
            public string _maeuni_NumeroDocumento { get; set; }
            public DateTime _maeuni_FechaDocumento { get; set; }
            public int _Codigo_Sesion { get; set; }
            public int _cantidad { get; set; }
            public string _NombreUnidad { get; set; }
            public string _NombreMAEUnidad { get; set; }
            
        #endregion

        #region "funciones publicas"
//----------------------------------------------------------
            public SqlDataReader Adicionar(string pNumeroDocumento, string pFechaDocumento, int pCodigoSesion,int pCodigoUnidad, int pCodigoUsuario)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("ins_MAEUnidades", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                //SqlParameter Parameter_maeuni_Codigo = new SqlParameter("@maeuni_Codigo", SqlDbType.Int, 11);
                //Parameter_maeuni_Codigo.Value = pmaeuni_Codigo;
                //Parameter_maeuni_Codigo.Direction = ParameterDirection.Input;
                //SqlCom.Parameters.Add(Parameter_maeuni_Codigo);

                SqlParameter Parameter_NumeroDocumento = new SqlParameter("@maeuni_NumeroDocumento", SqlDbType.VarChar, 150);
                Parameter_NumeroDocumento.Value = pNumeroDocumento;
                Parameter_NumeroDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_NumeroDocumento);

                SqlParameter Parameter_FechaDocumento = new SqlParameter("@maeuni_FechaDocumento", SqlDbType.Date);
                Parameter_FechaDocumento.Value = String.Format("{0:dd/MM/yyyy}",pFechaDocumento);
                Parameter_FechaDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_FechaDocumento);

                SqlParameter Parameter_CodigoSesion = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_CodigoSesion.Value = pCodigoSesion;
                Parameter_CodigoSesion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoSesion);

                SqlParameter Parameter_CodigoUnidad = new SqlParameter("@uni_Codigo", SqlDbType.Int, 11);
                Parameter_CodigoUnidad.Value = pCodigoUnidad;
                Parameter_CodigoUnidad.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoUnidad);

                SqlParameter Parameter_CodigoUsuario = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_CodigoUsuario.Value = pCodigoUsuario;
                Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoUsuario);

                //parametros de salida
                //SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                //Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                //SqlCom.Parameters.Add(Parameter_CodigoDeError);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::_Adicionar::Produjo un error.", MiExcepcion);
                }
            }
//----------------------------------------------------------
            public bool Modificar(int pCodigoUsuario, int pCodigoUnidad, int pEstado, string pNumeroDocumento, string pFechaDocumento, int pCodigoSesion)
            {
                int Resultado = 0;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("upd_MAEUnidades", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoUsuario = new SqlParameter("@per_Codigo", SqlDbType.Int, 11);
                Parameter_CodigoUsuario.Value = pCodigoUsuario;
                Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoUsuario);

                SqlParameter Parameter_CodigoUnidad = new SqlParameter("@uni_Codigo", SqlDbType.Int, 11);
                Parameter_CodigoUnidad.Value = pCodigoUnidad;
                Parameter_CodigoUnidad.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoUnidad);

                SqlParameter Parameter_Estado = new SqlParameter("@maeuni_Estado", SqlDbType.Int, 5);
                Parameter_Estado.Value = pEstado;
                Parameter_Estado.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Estado);

                SqlParameter Parameter_NumeroDocumento = new SqlParameter("@maeuni_NumeroDocumento", SqlDbType.VarChar, 150);
                Parameter_NumeroDocumento.Value = pNumeroDocumento;
                Parameter_NumeroDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_NumeroDocumento);

                SqlParameter Parameter_FechaDocumento = new SqlParameter("@maeuni_FechaDocumento", SqlDbType.DateTime);
                Parameter_FechaDocumento.Value = pFechaDocumento;
                Parameter_FechaDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_FechaDocumento);

                SqlParameter Parameter_CodigoSesion = new SqlParameter("@Codigo_Sesion", SqlDbType.Int, 11);
                Parameter_CodigoSesion.Value = pCodigoSesion;
                Parameter_CodigoSesion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoSesion);
                
                //parametrso de salida
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);

                try
                {
                    SqlCon.Open();
                    Resultado = SqlCom.ExecuteNonQuery();
                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                }
                catch (Exception MiExcepcion)
                {
                    _CodigoError = -1;
                    throw new Exception("Contrato::Modificacion::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }

                if (_CodigoError == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

//----------------------------------------------------------
            //EVer Ivan
            public DataSet ObtenerListado(int pPerCodigoResponsable, int pMaeUniEstado, int pUniCodigo)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_MAEUnidades", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                //per_codigo_Responsable es int
                //maeuni_Estado int
                //Uni_codigo int
                SqlParameter ParameterPerCodigoResponsable = new SqlParameter("@per_codigo_Responsable", SqlDbType.Int, 11);
                ParameterPerCodigoResponsable.Value = pPerCodigoResponsable;
                ParameterPerCodigoResponsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(ParameterPerCodigoResponsable);

                SqlParameter ParameterMaeUniEstado = new SqlParameter("@maeuni_Estado", SqlDbType.Int, 11);
                ParameterMaeUniEstado.Value = pMaeUniEstado;
                ParameterMaeUniEstado.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(ParameterMaeUniEstado);

                SqlParameter ParameterUniCodigo = new SqlParameter("@maeuni_codigo", SqlDbType.Int, 11);
                ParameterUniCodigo.Value = pUniCodigo;
                ParameterUniCodigo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(ParameterUniCodigo);

                //parametros de salida
                //SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                //Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                //SqlCom.Parameters.Add(Parameter_CodigoDeError);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_mae");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//----------------------------------------------------------
            // Ever ivan, devuelve el listado de todos los funcionario dado el codigo de la unidad donde pertenecen

            public bool ObtenerMAEUnidad(int pmaeuni_Codigo)
            {
                SqlDataReader Lector = null;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                // Ever., procedimiento que devuelve
                SqlCommand SqlCom = new SqlCommand("sel_MAEUnidadPorCodigo", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoPersona = new SqlParameter("@maeuni_Codigo", SqlDbType.Int, 11);
                Parameter_CodigoPersona.Value = pmaeuni_Codigo;
                Parameter_CodigoPersona.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoPersona);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        _maeuni_Codigo = Convert.ToInt32(Lector["cCodigoMaeUnidad"]);
                        _uni_Codigo = Convert.ToInt32(Lector["cuni_Codigo"]);
                        _NombreUnidad = Convert.ToString(Lector["cNombreUnidad"]);
                        _per_Codigo = Convert.ToInt32(Lector["cper_codigoMAE"]);
                        _NombreMAEUnidad = Convert.ToString(Lector["cNombreFuncionario"]);
                        _maeuni_NumeroDocumento = Convert.ToString(Lector["cNumeroDocumento"]);
                        _maeuni_FechaDocumento = Convert.ToDateTime(Lector["cFechaDocumento"]);

                      

                        Lector.Close();
                        SqlCon.Close();

                        if (_CodigoError == 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        Lector.Close();
                        SqlCon.Close();
                        _CodigoError = -1;
                        return false;
                    }
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::RecuperarUsuarioPorCodigo::Produjo un error.", MiExcepcion);
                }
            }
//----------------------------------------------------------
        #endregion
    }
}
