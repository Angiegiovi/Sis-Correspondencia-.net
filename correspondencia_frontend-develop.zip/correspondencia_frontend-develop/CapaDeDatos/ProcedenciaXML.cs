﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace CapaDeDatos
{
    public class ProcedenciaXML
    {

        public int per_codigo
        { get; set; }
        
        // Constructor
        public ProcedenciaXML()
        {
            this.per_codigo = 0;
        }
        public ProcedenciaXML(int per_codigo)
        {
            this.per_codigo = per_codigo;
        }

        // Casteador
        public static String CastearXml(List<ProcedenciaXML> lista)
        {
            return ConversionTipos.CastearListaObjetosParaXml(lista, typeof (ProcedenciaXML));

        }
        
    }
}
