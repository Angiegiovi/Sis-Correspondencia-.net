﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class HojaRutaAdjuntos
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public HojaRutaAdjuntos()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _CodigoHRAdjunto { get; set; }
            public string _Referencia { get; set; }
            public string _Cite { get; set; }
            public string _FechaDocumento { get; set; }
            public string _FechaRegistro { get; set; }
            public int _CodigoHojaRuta { get; set; }
            public int _CodigoAdjunto { get; set; }
            public int _CodigoDerivacion { get; set; }
            public string _DatosAdicionales { get; set; }

            public string _RutaArchivo { get; set; }
            public string _NombreArchivo { get; set; }
            public string _ExtensionArchivo { get; set; }

        #endregion
        #region "funciones publicas"

//---------------------------------------------------------------------------------------------------
        public DataSet _ArchivosPorCorrespondencia(int pCodigoHojaRuta)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_AdjuntosPorCorrespondencia", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                 SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_archivos");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::_ArchivosPorCorrespondencia::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//---------------------------------------------------------------------------------------------------
    //@Ever Ivan - 2015
    //@recsal_codigo INT, el txtinput
    //@CodigoEjemplar INT,????????????????????? grid listado
    //@CodigoHojaRuta INT,
    //@Referencia VARCHAR(250), del formulario
    //@Cite VARCHAR(100), ??????????????????? del formulario, documento que llega 
    //@FechaDocumento date, ??? del formulario, documento que llega
    //@DatosAdicionales VARCHAR(1000),del formulario, ? doc llega
    //@FechaRecepcionFisica DATETIME, ?del formulario, Fecha recepcion: 
    //@remper_persona_externa VARCHAR(120),del formulario el texto
    //@remper_cargo_transcrito VARCHAR(60), si es 0 cargo te manod esto
    //@CodigoCargoPE INT,  si es dif cero te mano cod, si es igual
    //@RutaAdjunto VARCHAR(150), del archivo fisico
    //@NombreAdjunto VARCHAR(150), del archivo fisico
    //@ExtensionAdjunto VARCHAR(10),del achivo fisico
    //@per_codigo_responsable INT  session("CodUsuario") 
        public SqlDataReader _AdicionarRegistroEntradas(int pRescal_codigo, int pCodigoEjemplar, int pCodigoHojaRuta, 
                                                        string pReferencia, string pCite, string pFechaDocumento, 
                                                        string pDatosAdicionales, string pFechaRecepcionFisica, 
                                                        string pRemper_persona_externa, string pRemper_cargo_transcrito, 
                                                        int pCodigoCargoPE, string pRutaAdjunto, string pNombreAdjunto, 
                                                        string pExtensionAdjunto, int pPer_codigo_responsable)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_registro_entradas", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Rescal_codigo = new SqlParameter("@recsal_codigo", SqlDbType.Int, 11);
            Parameter_Rescal_codigo.Value = pRescal_codigo;
            Parameter_Rescal_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Rescal_codigo);

            SqlParameter Parameter_CodigoEjemplar = new SqlParameter("@CodigoEjemplar", SqlDbType.Int, 250);
            Parameter_CodigoEjemplar.Value = pCodigoEjemplar;
            Parameter_CodigoEjemplar.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoEjemplar);

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 100);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar,100);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Cite = new SqlParameter("@Cite", SqlDbType.VarChar, 1000);
            Parameter_Cite.Value = pCite;
            Parameter_Cite.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Cite);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumento", SqlDbType.Date, 1000);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_DatosAdicionales = new SqlParameter("@DatosAdicionales", SqlDbType.VarChar, 1000);
            Parameter_DatosAdicionales.Value = pDatosAdicionales;
            Parameter_DatosAdicionales.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DatosAdicionales);

            SqlParameter Parameter_FechaRecepcionFisica = new SqlParameter("@FechaRecepcionFisica  ", SqlDbType.Date, 100);
            Parameter_FechaRecepcionFisica.Value = pFechaRecepcionFisica;
            Parameter_FechaRecepcionFisica.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRecepcionFisica);

            SqlParameter Parameter_remper_persona_externa = new SqlParameter("@remper_persona_externa", SqlDbType.VarChar, 1000);
            Parameter_remper_persona_externa.Value = pRemper_persona_externa;
            Parameter_remper_persona_externa.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_remper_persona_externa);

            SqlParameter Parameter_Remper_cargo_transcrito = new SqlParameter("@remper_cargo_transcrito", SqlDbType.VarChar, 60);
            Parameter_Remper_cargo_transcrito.Value = pRemper_cargo_transcrito;
            Parameter_Remper_cargo_transcrito.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Remper_cargo_transcrito);

            SqlParameter Parameter_CodigoCargoPE = new SqlParameter("@CodigoCargoPE", SqlDbType.Int, 10);
            Parameter_CodigoCargoPE.Value = pCodigoCargoPE;
            Parameter_CodigoCargoPE.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoCargoPE);

            SqlParameter Parameter_RutaAdjunto = new SqlParameter("@RutaAdjunto", SqlDbType.VarChar, 150);
            Parameter_RutaAdjunto.Value = pRutaAdjunto;
            Parameter_RutaAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_RutaAdjunto);

            SqlParameter Parameter_NombreAdjunto = new SqlParameter("@NombreAdjunto", SqlDbType.VarChar, 150);
            Parameter_NombreAdjunto.Value = pNombreAdjunto;
            Parameter_NombreAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombreAdjunto);

            SqlParameter Parameter_ExtensionAdjunto = new SqlParameter("@ExtensionAdjunto", SqlDbType.VarChar, 10);
            Parameter_ExtensionAdjunto.Value = pExtensionAdjunto;
            Parameter_ExtensionAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_ExtensionAdjunto);

            SqlParameter Parameter_Per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 10);
            Parameter_Per_codigo_responsable.Value = pPer_codigo_responsable;
            Parameter_Per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Per_codigo_responsable);
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("::_AdicionarAdjuntosCorrespondencia::Produjo un error.", MiExcepcion);
            }
        }        
        public SqlDataReader _AdicionarAdjuntosCorrespondencia(string pReferencia, string pCite, string pFechaDocumento, int pCodigoHojaRuta, string pDatosAdicionales, string pRutaAdjunto, string pNombreAdjunto, string pExtensionAdjunto)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_HojaRutaAdjuntos", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);
            
            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 250);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Cite = new SqlParameter("@Cite", SqlDbType.VarChar, 100);
            Parameter_Cite.Value = pCite;
            Parameter_Cite.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Cite);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumento", SqlDbType.Date);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_DatosAdicionales = new SqlParameter("@DatosAdicionales", SqlDbType.VarChar, 1000);
            Parameter_DatosAdicionales.Value = pDatosAdicionales;
            Parameter_DatosAdicionales.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DatosAdicionales);
            
            SqlParameter Parameter_RutaAdjunto = new SqlParameter("@RutaAdjunto", SqlDbType.VarChar, 150);
            Parameter_RutaAdjunto.Value = pRutaAdjunto;
            Parameter_RutaAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_RutaAdjunto);

            SqlParameter Parameter_NombreAdjunto = new SqlParameter("@NombreAdjunto", SqlDbType.VarChar, 150);
            Parameter_NombreAdjunto.Value = pNombreAdjunto;
            Parameter_NombreAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombreAdjunto);
            
            SqlParameter Parameter_ExtensionAdjunto = new SqlParameter("@ExtensionAdjunto", SqlDbType.VarChar, 10);
            Parameter_ExtensionAdjunto.Value = pExtensionAdjunto;
            Parameter_ExtensionAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_ExtensionAdjunto);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("::_AdicionarAdjuntosCorrespondencia::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _ModificarAdjuntosCorrespondencia(int pCodigoHRAdjunto, string pCite, string pReferencia, string pFechaDocumento, string pDatosAdicionales, string pRutaAdjunto, string pNombreAdjunto, string pExtensionAdjunto)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_HojaRutaAdjuntos", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHRAdjunto = new SqlParameter("@CodigoHRAdjunto", SqlDbType.Int, 11);
            Parameter_CodigoHRAdjunto.Value = pCodigoHRAdjunto;
            Parameter_CodigoHRAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHRAdjunto);

            SqlParameter Parameter_Cite = new SqlParameter("@Cite", SqlDbType.VarChar, 100);
            Parameter_Cite.Value = pCite;
            Parameter_Cite.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Cite);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 250);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumento", SqlDbType.Date);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_DatosAdicionales = new SqlParameter("@DatosAdicionales", SqlDbType.VarChar, 1000);
            Parameter_DatosAdicionales.Value = pDatosAdicionales;
            Parameter_DatosAdicionales.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DatosAdicionales);


            SqlParameter Parameter_RutaAdjunto = new SqlParameter("@RutaAdjunto", SqlDbType.VarChar, 150);
            Parameter_RutaAdjunto.Value = pRutaAdjunto;
            Parameter_RutaAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_RutaAdjunto);

            SqlParameter Parameter_NombreAdjunto = new SqlParameter("@NombreAdjunto", SqlDbType.VarChar, 150);
            Parameter_NombreAdjunto.Value = pNombreAdjunto;
            Parameter_NombreAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombreAdjunto);

            SqlParameter Parameter_ExtensionAdjunto = new SqlParameter("@ExtensionAdjunto", SqlDbType.VarChar, 10);
            Parameter_ExtensionAdjunto.Value = pExtensionAdjunto;
            Parameter_ExtensionAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_ExtensionAdjunto);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("::_ModificarAdjuntosCorrespondencia::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public SqlDataReader _EliminarAdjuntosCorrespondencia(int pCodigoHRAdjunto)
        {
            SqlDataReader Lector;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_HojaRutaAdjuntos", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHRAdjunto = new SqlParameter("@CodigoHRAdjunto", SqlDbType.Int, 11);
            Parameter_CodigoHRAdjunto.Value = pCodigoHRAdjunto;
            Parameter_CodigoHRAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHRAdjunto);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("::_AdicionarAdjuntosCorrespondencia::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool AdicionarHRAdjunto(string pReferencia, string pCite, string pFechaDocumento, int pCodigoHojaRuta, int pCodigoAdjunto, int pCodigoDerivacion, string pDatosAdicionales, int pCodigoSesion, string pFechaRecepcion)
        {
            int Resultado = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_HojaRutaAdjuntosRespuesta", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 250);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Cite = new SqlParameter("@Cite", SqlDbType.VarChar, 100);
            Parameter_Cite.Value = pCite;
            Parameter_Cite.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Cite);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumento", SqlDbType.VarChar, 15);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_CodigoAdjunto = new SqlParameter("@CodigoAdjunto", SqlDbType.Int, 11);
            Parameter_CodigoAdjunto.Value = pCodigoAdjunto;
            Parameter_CodigoAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoAdjunto);

            SqlParameter Parameter_CodigoDerivacion = new SqlParameter("@CodigoDerivacion", SqlDbType.Int, 11);
            Parameter_CodigoDerivacion.Value = pCodigoDerivacion;
            Parameter_CodigoDerivacion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDerivacion);

            SqlParameter Parameter_DatosAdicionales = new SqlParameter("@DatosAdicionales", SqlDbType.VarChar, 1000);
            Parameter_DatosAdicionales.Value = pDatosAdicionales;
            Parameter_DatosAdicionales.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DatosAdicionales);

            SqlParameter Parameter_CodigoSesion = new SqlParameter("@CodigoSesion", SqlDbType.VarChar, 250);
            Parameter_CodigoSesion.Value = pCodigoSesion;
            Parameter_CodigoSesion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSesion);

            SqlParameter Parameter_FechaRecepcion = new SqlParameter("@FechaRecepcion", SqlDbType.VarChar,20);
            Parameter_FechaRecepcion.Value = pFechaRecepcion;
            Parameter_FechaRecepcion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaRecepcion);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlParameter Parameter_CodigoHRAdjunto = new SqlParameter("@CodigoHRAdjunto", SqlDbType.Int, 11);
            Parameter_CodigoHRAdjunto.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoHRAdjunto);


            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                _CodigoHRAdjunto = Convert.ToInt32(Parameter_CodigoHRAdjunto.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Usuario::Adicion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool AdicionarTEMP(string pReferencia, string pCite, string pFechaDocumento, string pDatosAdicionales, int pCodigoSesion, string pRutaAdjuntoTemp, string pNombreAdjuntoTemp, string pExtensionAdjuntoTemp)
        {
            int Resultado = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_HojaRutaAdjuntosTEMP", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_Referencia = new SqlParameter("@ReferenciaTEMP", SqlDbType.VarChar, 250);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Cite = new SqlParameter("@CiteTEMP", SqlDbType.VarChar, 100);
            Parameter_Cite.Value = pCite;
            Parameter_Cite.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Cite);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumentoTEMP", SqlDbType.VarChar, 15);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_DatosAdicionales = new SqlParameter("@DatosAdicionalesTEMP", SqlDbType.VarChar, 250);
            Parameter_DatosAdicionales.Value = pDatosAdicionales;
            Parameter_DatosAdicionales.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DatosAdicionales);

            SqlParameter Parameter_CodigoSesion = new SqlParameter("@CodigoSesionTEMP", SqlDbType.VarChar, 250);
            Parameter_CodigoSesion.Value = pCodigoSesion;
            Parameter_CodigoSesion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSesion);

            SqlParameter Parameter_RutaAdjuntoTemp = new SqlParameter("@RutaAdjuntoTEMP", SqlDbType.VarChar, 350);
            Parameter_RutaAdjuntoTemp.Value = pRutaAdjuntoTemp;
            Parameter_RutaAdjuntoTemp.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_RutaAdjuntoTemp);

            SqlParameter Parameter_NombreAdjuntoTemp = new SqlParameter("@NombreAdjuntoTEMP", SqlDbType.VarChar, 250);
            Parameter_NombreAdjuntoTemp.Value = pNombreAdjuntoTemp;
            Parameter_NombreAdjuntoTemp.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombreAdjuntoTemp);

            SqlParameter Parameter_ExtensionAdjuntoTemp = new SqlParameter("@ExtensionAdjuntoTEMP", SqlDbType.VarChar, 100);
            Parameter_ExtensionAdjuntoTemp.Value = pExtensionAdjuntoTemp;
            Parameter_ExtensionAdjuntoTemp.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_ExtensionAdjuntoTemp);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Usuario::Adicion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
        
//---------------------------------------------------------------------------------------------------
        public bool ModificarTEMP(int pCodigoHojaRutaAdjuntoTemp, string pReferencia, string pCite, string pFechaDocumento, string pDatosAdicionales, string pRutaAdjuntoTemp, string pNombreAdjuntoTemp, string pExtensionAdjuntoTemp)
        {
            int Resultado = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("upd_HojaRutaAdjuntosTEMP", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRutaAdjuntoTemp = new SqlParameter("@CodigoHojaRutaAdjuntoTEMP", SqlDbType.Int, 11);
            Parameter_CodigoHojaRutaAdjuntoTemp.Value = pCodigoHojaRutaAdjuntoTemp;
            Parameter_CodigoHojaRutaAdjuntoTemp.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRutaAdjuntoTemp);

            SqlParameter Parameter_Referencia = new SqlParameter("@ReferenciaTEMP", SqlDbType.VarChar, 250);
            Parameter_Referencia.Value = pReferencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_Cite = new SqlParameter("@CiteTEMP", SqlDbType.VarChar, 100);
            Parameter_Cite.Value = pCite;
            Parameter_Cite.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Cite);

            SqlParameter Parameter_FechaDocumento = new SqlParameter("@FechaDocumentoTEMP", SqlDbType.VarChar, 11);
            Parameter_FechaDocumento.Value = pFechaDocumento;
            Parameter_FechaDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_FechaDocumento);

            SqlParameter Parameter_DatosAdicionales = new SqlParameter("@DatosAdicionalesTEMP", SqlDbType.VarChar, 250);
            Parameter_DatosAdicionales.Value = pDatosAdicionales;
            Parameter_DatosAdicionales.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_DatosAdicionales);

            SqlParameter Parameter_RutaAdjuntoTemp = new SqlParameter("@RutaAdjuntoTEMP", SqlDbType.VarChar, 350);
            Parameter_RutaAdjuntoTemp.Value = pRutaAdjuntoTemp;
            Parameter_RutaAdjuntoTemp.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_RutaAdjuntoTemp);

            SqlParameter Parameter_NombreAdjuntoTemp = new SqlParameter("@NombreAdjuntoTEMP", SqlDbType.VarChar, 250);
            Parameter_NombreAdjuntoTemp.Value = pNombreAdjuntoTemp;
            Parameter_NombreAdjuntoTemp.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_NombreAdjuntoTemp);

            SqlParameter Parameter_ExtensionAdjuntoTemp = new SqlParameter("@ExtensionAdjuntoTEMP", SqlDbType.VarChar, 100);
            Parameter_ExtensionAdjuntoTemp.Value = pExtensionAdjuntoTemp;
            Parameter_ExtensionAdjuntoTemp.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_ExtensionAdjuntoTemp);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Usuario::Adicion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
        
//---------------------------------------------------------------------------------------------------
        public bool EliminarTEMP(int pCodigoHRAdjuntoTemp)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_HojaRutaAdjuntosTEMP", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHRAdjuntoTemp = new SqlParameter("@CodigoHRAdjuntoTemp", SqlDbType.Int, 11);
            Parameter_CodigoHRAdjuntoTemp.Value = pCodigoHRAdjuntoTemp;
            Parameter_CodigoHRAdjuntoTemp.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHRAdjuntoTemp);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlParameter Parameter_RutaArchivo = new SqlParameter("@RutaArchivo", SqlDbType.VarChar, 600);
            Parameter_RutaArchivo.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_RutaArchivo);

            SqlParameter Parameter_NombreArchivo = new SqlParameter("@NombreArchivo", SqlDbType.VarChar, 600);
            Parameter_NombreArchivo.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_NombreArchivo);

            SqlParameter Parameter_ExtensionArchivo = new SqlParameter("@ExtensionArchivo", SqlDbType.VarChar, 10);
            Parameter_ExtensionArchivo.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_ExtensionArchivo);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);

                _RutaArchivo = Convert.ToString(Parameter_RutaArchivo.Value);
                _NombreArchivo = Convert.ToString(Parameter_NombreArchivo.Value);
                _ExtensionArchivo = Convert.ToString(Parameter_ExtensionArchivo.Value);

            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Rol::Eliminacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
       
//---------------------------------------------------------------------------------------------------
        public DataSet ArchivosPorCorrespondenciaTEMP(int pCodigoFuncionario, int pCodigoSesionTemp)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_AdjuntosPorCorrespondenciaTEMP", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoFuncionario = new SqlParameter("@CodigoFuncionario", SqlDbType.Int, 11);
            Parameter_CodigoFuncionario.Value = pCodigoFuncionario;
            Parameter_CodigoFuncionario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoFuncionario);
            
            SqlParameter Parameter_CodigoSesionTemp = new SqlParameter("@CodigoSesionTemp", SqlDbType.Int, 11);
            Parameter_CodigoSesionTemp.Value = pCodigoSesionTemp;
            Parameter_CodigoSesionTemp.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSesionTemp);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_archivos");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool ActualizarCodigoHojaRuta(int pCodigoHRAdjunto, int pCodigoHojaRuta)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_HojaRutaAdjuntoPorCodHR", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHRAdjunto = new SqlParameter("@CodigoHRAdjunto", SqlDbType.Int, 11);
            Parameter_CodigoHRAdjunto.Value = pCodigoHRAdjunto;
            Parameter_CodigoHRAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHRAdjunto);

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            //parametro de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
               

                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Contrato::Modificacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool ActualizarCodigoDerivacion(int pCodigoHRAdjunto, int pCodigoDerivacion)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_HojaRutaAdjuntoPorCodDerivacion", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHRAdjunto = new SqlParameter("@CodigoHRAdjunto", SqlDbType.Int, 11);
            Parameter_CodigoHRAdjunto.Value = pCodigoHRAdjunto;
            Parameter_CodigoHRAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHRAdjunto);

            SqlParameter Parameter_CodigoDerivacion = new SqlParameter("@CodigoDerivacion", SqlDbType.Int, 11);
            Parameter_CodigoDerivacion.Value = pCodigoDerivacion;
            Parameter_CodigoDerivacion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDerivacion);

            //parametro de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();


                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Contrato::Modificacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool ModificarPorCodigoSesion(int pCodigoSesion)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("upd_HojaRutaAdjuntoPorSesion", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoSesion = new SqlParameter("@CodigoSesion", SqlDbType.Int, 11);
            Parameter_CodigoSesion.Value = pCodigoSesion;
            Parameter_CodigoSesion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSesion);

            //parametro de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();


                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Contrato::Modificacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet ArchivosPorDerivacion(int pCodigoDerivacion, int pCodigoUsuario, int pCodigoSesion)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_AdjuntosPorDerivacion", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoDerivacion = new SqlParameter("@CodigoDerivacion", SqlDbType.Int, 11);
            Parameter_CodigoDerivacion.Value = pCodigoDerivacion;
            Parameter_CodigoDerivacion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDerivacion);

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoUsuario", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlParameter Parameter_CodigoSesion = new SqlParameter("@CodigoSesion", SqlDbType.Int, 11);
            Parameter_CodigoSesion.Value = pCodigoSesion;
            Parameter_CodigoSesion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSesion);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_archivos");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet ObtenerAdjuntosPorHRyS(int pCodigoDerivacion, int pCodigoSesion)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_AdjuntosPorDerivacionYSesion", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoDerivacion = new SqlParameter("@CodigoDerivacion", SqlDbType.Int, 11);
            Parameter_CodigoDerivacion.Value = pCodigoDerivacion;
            Parameter_CodigoDerivacion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDerivacion);

            SqlParameter Parameter_CodigoSesion = new SqlParameter("@CodigoSesion", SqlDbType.Int, 11);
            Parameter_CodigoSesion.Value = pCodigoSesion;
            Parameter_CodigoSesion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSesion);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_archivos");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//---------------------------------------------------------------------------------------------------
        public bool ObtenerHRAdjuntoPorID(int pCodigoHRAdjunto)
        {

            SqlDataReader Lector = null;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("sel_HRAdjuntoPorId", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHRAdjunto = new SqlParameter("@CodigoHRAdjunto", SqlDbType.Int, 11);
            Parameter_CodigoHRAdjunto.Value = pCodigoHRAdjunto;
            Parameter_CodigoHRAdjunto.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHRAdjunto);

            //parametro de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();

                if (Lector.Read())
                {
                    _CodigoAdjunto = Convert.ToInt32(Lector["cCodigoAdjunto"]);
                    _NombreArchivo = Lector["cArchivo"].ToString();
                    _Cite = Lector["cCite"].ToString();
                    _Referencia = Lector["cReferencia"].ToString();
                    _FechaDocumento = Lector["cFechaDocumento"].ToString();
                    _DatosAdicionales = Lector["cDatosAdicionales"].ToString();

                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);

                    Lector.Close();
                    SqlCon.Close();

                    if (_CodigoError == 0)
                    {
                        //    EstablecerPoliticaPrincipal(_CodigoUsuario, _LoginUsuario)
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    Lector.Close();
                    SqlCon.Close();
                    _CodigoError = -1;
                    return false;
                }
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::RecuperarUsuarioPorCodigo::Produjo un error.", MiExcepcion);
            }
        }
//---------------------------------------------------------------------------------------------------
        public DataSet LimpiarHojaRutaAdjuntosTEMP(int pCodigoSesion)
        {
            int Retorno = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_HojaRutaAdjuntosTEMPPorSesion", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoSesion = new SqlParameter("@CodigoSesion", SqlDbType.Int, 11);
            Parameter_CodigoSesion.Value = pCodigoSesion;
            Parameter_CodigoSesion.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSesion);

            ////parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            //SqlParameter Parameter_RutaArchivo = new SqlParameter("@RutaArchivo", SqlDbType.VarChar, 600);
            //Parameter_RutaArchivo.Direction = ParameterDirection.Output;
            //SqlCom.Parameters.Add(Parameter_RutaArchivo);

            //SqlParameter Parameter_NombreArchivo = new SqlParameter("@NombreArchivo", SqlDbType.VarChar, 600);
            //Parameter_NombreArchivo.Direction = ParameterDirection.Output;
            //SqlCom.Parameters.Add(Parameter_NombreArchivo);

            //SqlParameter Parameter_ExtensionArchivo = new SqlParameter("@ExtensionArchivo", SqlDbType.VarChar, 10);
            //Parameter_ExtensionArchivo.Direction = ParameterDirection.Output;
            //SqlCom.Parameters.Add(Parameter_ExtensionArchivo);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_archivos");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Rol::Eliminacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            
        }
//---------------------------------------------------------------------------------------------------
        #endregion
    }
}
