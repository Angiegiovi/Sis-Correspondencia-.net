﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class CorrelativoDocumento
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public CorrelativoDocumento()
            {
                //_CadenaConexion = WebConfigurationManager.AppSettings["CadenaDeConexion"];
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _CodigoDocumento { get; set; }
            public string _CodigoCorrelativo { get; set; }
            public int _Solicitud { get; set; }
            public int _CodigoHojaRuta { get; set; }
            public int _CodigoTipoDocumento { get; set; }
            public string _Referencia { get; set; }
            public string _FechaSolicitud { get; set; }
            public string _CodigoUsuarioSolicitante { get; set; } 

            public string _NombreUsuario { get; set; }
            public string _DescripcionTipoDocumento { get; set; }
            public string _Archivo { get; set; }
            public string _CorrelativoSistemaHR { get; set; }
            public string _CorrelativoCorrespondenciaHR { get; set; }

        #endregion
        #region "funciones publicas"
        
 //-------------------------------------------------------------------------------------------------
            public SqlDataReader _GenerarCorrelativoHorizontal(string CodigoDocumento)
            {  SqlDataReader respuesta;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_GenerarCorrelativoMae", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
                Parameter_CodigoDocumento.Value = CodigoDocumento;
                Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoDocumento);
                try
                {
                    SqlCon.Open(); respuesta = SqlCom.ExecuteReader();
                    if (respuesta.Read())  { return respuesta; }
                    return null;
                }
                catch (Exception MiExcepcion)
                {    throw new Exception("Usuario::ObtenerInformacionCorrelativo::Produjo un error.", MiExcepcion);
                }
            }
//-------------------------------------------------------------------------------------------------
            public SqlDataReader _ObtenerDatosCorrelativoGeneralPorId(int CodigoDocumento)
            {
                SqlDataReader respuesta;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_Correlativo_generalPorId", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
                Parameter_CodigoDocumento.Value = CodigoDocumento;
                Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoDocumento);

                try
                {
                    SqlCon.Open();
                    respuesta = SqlCom.ExecuteReader();
                    if (respuesta.Read())
                    { return respuesta; }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerInformacionCorrelativo::Produjo un error.", MiExcepcion);
                }

            }
//-------------------------------------------------------------------------------------------------
            public SqlDataReader _ObtenerDatosOficioPorId(int CodigoDocumento)
            {
                SqlDataReader respuesta;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_Correlativo_oficioPorId", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
                Parameter_CodigoDocumento.Value = CodigoDocumento;
                Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoDocumento);

                try
                {
                    SqlCon.Open();
                    respuesta = SqlCom.ExecuteReader();
                    if (respuesta.Read())
                    { return respuesta; }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerInformacionCorrelativo::Produjo un error.", MiExcepcion);
                }

            }
//-------------------------------------------------------------------------------------------------
            public DataSet _ObtenerTodosLosCorrelativos(int pCodigoUsuario, int CodigoResponsable, int CodigoRol, string FechaDesde, string FechaHasta, int estado_correlativo, int pTipo_doc)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_buscar_Correlativos", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoUsuario = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_CodigoUsuario.Value = pCodigoUsuario;
                Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoUsuario);


                SqlParameter Parameter_CodigoResponsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
                Parameter_CodigoResponsable.Value = CodigoResponsable;
                Parameter_CodigoResponsable.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoResponsable);

                SqlParameter Parameter_CodigoRol = new SqlParameter("@codigo_rol", SqlDbType.VarChar, 250);
                Parameter_CodigoRol.Value = CodigoRol;
                Parameter_CodigoRol.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoRol);

                SqlParameter Parameter_FechaDesde = new SqlParameter("@Fechadesde", SqlDbType.DateTime, 30);
                Parameter_FechaDesde.Value = FechaDesde;
                Parameter_FechaDesde.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_FechaDesde);

                SqlParameter Parameter_FechaHasta = new SqlParameter("@Fechahasta", SqlDbType.DateTime, 30);
                Parameter_FechaHasta.Value = FechaHasta;
                Parameter_FechaHasta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_FechaHasta);

                SqlParameter Parameter_estado_correlativo = new SqlParameter("@estado_correlativo", SqlDbType.Int, 11);
                Parameter_estado_correlativo.Value = estado_correlativo;
                Parameter_estado_correlativo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_estado_correlativo);

                SqlParameter Parameter_pTipo_doc = new SqlParameter("@tipo_doc", SqlDbType.Int, 11);
                Parameter_pTipo_doc.Value = pTipo_doc;
                Parameter_pTipo_doc.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pTipo_doc);

                

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_docu");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosCorrelativos::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }

//-------------------------------------------------------------------------------------------------
            public DataSet _ObtenerTodosLosDocumentos(int pCodigoUsuario, int CodigoTipoDocumento, string NumeroCorrelativo, int Gestion, int RelacionHojaRuta)

            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_CorrelativoDocumento", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoUsuario = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_CodigoUsuario.Value = pCodigoUsuario;
                Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoUsuario);

                SqlParameter Parameter_CodigoTipoDocumento = new SqlParameter("@CodigoTipoDocumento", SqlDbType.Int, 11);
                Parameter_CodigoTipoDocumento.Value = CodigoTipoDocumento;
                Parameter_CodigoTipoDocumento.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoTipoDocumento);

                SqlParameter Parameter_NumeroCorrelativo = new SqlParameter("@NumeroCorrelativo", SqlDbType.VarChar, 250);
                Parameter_NumeroCorrelativo.Value = NumeroCorrelativo;

                Parameter_NumeroCorrelativo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_NumeroCorrelativo);

                SqlParameter Parameter_Gestion = new SqlParameter("@Gestion", SqlDbType.Int, 11);
                Parameter_Gestion.Value = Gestion;
                Parameter_Gestion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Gestion);

                SqlParameter Parameter_RelacionHojaRuta = new SqlParameter("@RelacionHojaRuta", SqlDbType.Int, 11);
                Parameter_RelacionHojaRuta.Value = RelacionHojaRuta;
                Parameter_RelacionHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_RelacionHojaRuta);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_docu");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//===========================================================================
            //@Ever Ivan - 2015
            // Se obtiene un SqlDataReader con los datos de l correlativo dato los datos del codigo de BD del documento y el la sesscion de usuario
        public SqlDataReader ObtenerInformacionCorrelativo(int CodigoDocumento, int per_codigo)
        {
            SqlDataReader respuesta;       
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_CorrelativoDocumentoPorId", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
            Parameter_CodigoDocumento.Value = CodigoDocumento;
            Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDocumento);

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = per_codigo;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            try
            {
                SqlCon.Open();
                respuesta = SqlCom.ExecuteReader();
                if (respuesta.Read())
                { return respuesta; }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerInformacionCorrelativo::Produjo un error.", MiExcepcion);
            }
            
        }

      /*
       * Genera un nro correlativo A partir de uno anterior (REGULARIZAR ) -- subcontraloria de serv legales
       *  se agrego el envio CodigoMovimiento y CodigoCorrelativo        
       */
        public SqlDataReader AdicionarCorrelativo_Horizontal(int CodigoMovimiento, int CodigoTipoDocumento, string Referencia, int pper_codigo, int per_codigo_responsable, string remitente_xml, string destinatario_xml, string via_xml, string destinatario_ext_xml, int pTipdocuni_codigo)
        {
            SqlDataReader Lector;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("ins_CorrelativoDocumento_horizontal", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
            Parameter_CodigoMovimiento.Value = CodigoMovimiento; // es menos unoCodigoTipoDocumento;
            Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

            SqlParameter Parameter_CodigoTipoDocumento = new SqlParameter("@CodigoTipoDocumento", SqlDbType.Int, 11);
            Parameter_CodigoTipoDocumento.Value = CodigoTipoDocumento;
            Parameter_CodigoTipoDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoDocumento);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 650);
            Parameter_Referencia.Value = Referencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = per_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);

            SqlParameter Parameter_remitente = new SqlParameter("@remitente_xml", SqlDbType.Xml);
            Parameter_remitente.Value = remitente_xml;
            Parameter_remitente.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_remitente);

            SqlParameter Parameter_via = new SqlParameter("@via_xml", SqlDbType.Xml);
            Parameter_via.Value = via_xml;
            Parameter_via.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_via);

            SqlParameter Parameter_destinatario = new SqlParameter("@destinatario_xml", SqlDbType.Xml);
            Parameter_destinatario.Value = destinatario_xml;
            Parameter_destinatario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_destinatario);

            SqlParameter Parameter_destinatario_ext_xml = new SqlParameter("@destinatario_ext_xml", SqlDbType.Xml);
            Parameter_destinatario_ext_xml.Value = destinatario_ext_xml;
            Parameter_destinatario_ext_xml.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_destinatario_ext_xml);

            SqlParameter Parameter_pTipdocuni_codigo = new SqlParameter("@tipdocuni_codigo_ini", SqlDbType.Int, 11);
            Parameter_pTipdocuni_codigo.Value = pTipdocuni_codigo;
            Parameter_pTipdocuni_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_pTipdocuni_codigo);
            
            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_AdicionarCorrelarivo::Produjo un error.", MiExcepcion);
            }



        }




        //Genera un nro correlativo
        public SqlDataReader AdicionarCorrelativo( int CodigoMovimiento, int CodigoTipoDocumento,string Referencia,int pper_codigo, int per_codigo_responsable,string remitente_xml,string destinatario_xml,string via_xml,string destinatario_ext_xml)
        {
            SqlDataReader Lector;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("ins_CorrelativoDocumento", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoMovimiento = new SqlParameter("@CodigoMovimiento", SqlDbType.Int, 11);
            Parameter_CodigoMovimiento.Value = CodigoMovimiento; // es menos unoCodigoTipoDocumento;
            Parameter_CodigoMovimiento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoMovimiento);

            SqlParameter Parameter_CodigoTipoDocumento = new SqlParameter("@CodigoTipoDocumento", SqlDbType.Int, 11);
            Parameter_CodigoTipoDocumento.Value = CodigoTipoDocumento;
            Parameter_CodigoTipoDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoTipoDocumento);

            SqlParameter Parameter_Referencia = new SqlParameter("@Referencia", SqlDbType.VarChar, 650);
            Parameter_Referencia.Value = Referencia;
            Parameter_Referencia.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_Referencia);

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pper_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);  
            
            SqlParameter Parameter_per_codigo_responsable = new SqlParameter("@per_codigo_responsable", SqlDbType.Int, 11);
            Parameter_per_codigo_responsable.Value = per_codigo_responsable;
            Parameter_per_codigo_responsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo_responsable);            

            SqlParameter Parameter_remitente = new SqlParameter("@remitente_xml", SqlDbType.Xml);
            Parameter_remitente.Value = remitente_xml;
            Parameter_remitente.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_remitente);

            SqlParameter Parameter_via = new SqlParameter("@via_xml", SqlDbType.Xml);
            Parameter_via.Value = via_xml;
            Parameter_via.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_via);

            SqlParameter Parameter_destinatario = new SqlParameter("@destinatario_xml", SqlDbType.Xml);
            Parameter_destinatario.Value = destinatario_xml;
            Parameter_destinatario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_destinatario);

            SqlParameter Parameter_destinatario_ext_xml = new SqlParameter("@destinatario_ext_xml", SqlDbType.Xml);
            Parameter_destinatario_ext_xml.Value = destinatario_ext_xml;
            Parameter_destinatario_ext_xml.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_destinatario_ext_xml);

            try
            {
                SqlCon.Open();
                Lector = SqlCom.ExecuteReader();
                if (Lector.Read())
                {
                    return Lector;
                }
                return null;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_AdicionarCorrelarivo::Produjo un error.", MiExcepcion);
            }


          
        }
        
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
        //@Ever Ivan - 2015 anteriormente estaba apuntando a 'sel_DocumentosDeSalida'
        public DataSet _ObtenerDocumentosDeSalida(int pPer_codigo, string pCodigoSistema)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_SalidaOficios", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_per_codigo = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
            Parameter_per_codigo.Value = pPer_codigo;
            Parameter_per_codigo.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_per_codigo);

            SqlParameter Parameter_CodigoSistema = new SqlParameter("@CodigoSistema", SqlDbType.VarChar, 100);
            Parameter_CodigoSistema.Value = pCodigoSistema;
            Parameter_CodigoSistema.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoSistema);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_docu_salida");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::_ObtenerDocumentosDeSalida::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//-------------------------------------------------------------------------------------------------
        #endregion
    }
}
