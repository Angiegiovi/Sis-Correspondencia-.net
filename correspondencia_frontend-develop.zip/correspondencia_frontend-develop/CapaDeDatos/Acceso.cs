﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Web.Configuration;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class Acceso
    {
        #region "Variables"
            private string _CadenaConexion;
            private int _CodigoError;
        #endregion
        #region "Constructor"
            public Acceso()
            {
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades públicas"

            public int _Codigo_Acceso { get; set; }
            public string _Plataforma_Acceso { get; set; }
            public string _Version_Acceso { get; set; }
            public string _DireccionIP_Acceso { get; set; }
            public string _Equipo_Acceso { get; set; }
            public string _Url_Acceso { get; set; }
            public int _Codigo_Sesion { get; set; }

        #endregion
        #region "Funciones públicas"
//------------------------------------------------------------------------
            public bool Adicionar(string pPlataforma_Acceso, string pVersion_Acceso, string pDireccionIP_Acceso, string pEquipo_Acceso, string pUrl_Acceso, int pCodigo_Sesion)
            {
                int Resultado = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("ins_Acceso", SqlCon);
            
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Plataforma_Acceso = new SqlParameter("@Plataforma_Acceso", SqlDbType.VarChar, 250);
                Parameter_Plataforma_Acceso.Value = pPlataforma_Acceso;
                Parameter_Plataforma_Acceso.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Plataforma_Acceso);
                
                SqlParameter Parameter_Version_Acceso = new SqlParameter("@Version_Acceso", SqlDbType.VarChar, 250);
                Parameter_Version_Acceso.Value = pVersion_Acceso;
                Parameter_Version_Acceso.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Version_Acceso);
                
                SqlParameter Parameter_DireccionIP_Acceso = new SqlParameter("@DireccionIP_Acceso", SqlDbType.VarChar, 250);
                Parameter_DireccionIP_Acceso.Value = pDireccionIP_Acceso;
                Parameter_DireccionIP_Acceso.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_DireccionIP_Acceso);
                
                SqlParameter Parameter_Equipo_Acceso = new SqlParameter("@Equipo_Acceso", SqlDbType.VarChar, 250);
                Parameter_Equipo_Acceso.Value = pEquipo_Acceso;
                Parameter_Equipo_Acceso.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Equipo_Acceso);
                
                SqlParameter Parameter_Url_Acceso = new SqlParameter("@Url_Acceso", SqlDbType.Text, 0);
                Parameter_Url_Acceso.Value = pUrl_Acceso;
                Parameter_Url_Acceso.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Url_Acceso);
                
                SqlParameter Parameter_Codigo_Sesion = new SqlParameter("@Codigo_Sesion", SqlDbType.Int, 4);
                Parameter_Codigo_Sesion.Value = pCodigo_Sesion;
                Parameter_Codigo_Sesion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Codigo_Sesion);

                //parametros de salida
                SqlParameter Parameter_Codigo_Acceso = new SqlParameter("@Codigo_Acceso", SqlDbType.Int, 4);
                Parameter_Codigo_Acceso.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_Codigo_Acceso);
                
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);
                try
                {
                    SqlCon.Open();
                    Resultado = SqlCom.ExecuteNonQuery();
                    _Codigo_Acceso = Convert.ToInt32(Parameter_Codigo_Acceso.Value);
                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                }
                catch (Exception MiExcepcion)
                {
                    _CodigoError = -1;
                    throw new Exception("Acceso::Adicionar::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
                if (_CodigoError == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
//------------------------------------------------------------------------
        #endregion

    }
}
