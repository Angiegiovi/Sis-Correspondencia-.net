﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// Ever Ivan
namespace CapaDeDatos
{
    public class CodigoMovimientoXML
    {
        public int CodigoMovimiento
        { get; set; }

        // Constructor
        public CodigoMovimientoXML()
        {
            this.CodigoMovimiento = 0;
        }

        public CodigoMovimientoXML(int CodigoMovimiento)
        {
            this.CodigoMovimiento = CodigoMovimiento;
        }

        // Casteador
        public static String CastearXml(List<CodigoEjemplarXML> lista)
        {
            return ConversionTipos.CastearListaObjetosParaXml(lista, typeof(CodigoEjemplarXML));
        }
    }
}
