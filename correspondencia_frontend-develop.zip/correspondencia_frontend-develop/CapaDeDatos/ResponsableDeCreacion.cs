﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class ResponsableDeCreacion
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public ResponsableDeCreacion()
            {
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion
        #region "Propiedades publicas"

            public int _CodigoResponsable { get; set; }
            public int _CodigoUsuario { get; set; }
            public int _CodigoHojaRuta { get; set; }
            public int _CodigoDocumento { get; set; }
            
            //extras
            //public string _Instruccion { get; set; }
            //public string _DerivadoPorM { get; set; }
            //public string _DerivadoAM { get; set; }

        #endregion
        #region "funciones publicas"
//--------------------------------------------------------------------
        public bool Adicionar(int pCodigoUsuario, int pCodigoHojaRuta, int pCodigoDocumento)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("ins_ResponsableDeCreacion", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoUsuario", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
            Parameter_CodigoDocumento.Value = pCodigoDocumento;
            Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDocumento);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                //_CodigoResponsable = Convert.ToInt32(Parameter_CodigoResponsable.Value);
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Usuario::Adicion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//--------------------------------------------------------------------
        public bool Modificar(int pCodigoResponsable, int pCodigoUsuario, int pCodigoHojaRuta, int pCodigoDocumento)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("upd_ResponsableDeCreacion", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoResponsable = new SqlParameter("@CodigoResponsable", SqlDbType.Int, 11);
            Parameter_CodigoResponsable.Value = pCodigoResponsable;
            Parameter_CodigoResponsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoResponsable);

            SqlParameter Parameter_CodigoUsuario = new SqlParameter("@CodigoUsuario", SqlDbType.Int, 11);
            Parameter_CodigoUsuario.Value = pCodigoUsuario;
            Parameter_CodigoUsuario.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoUsuario);

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
            Parameter_CodigoDocumento.Value = pCodigoDocumento;
            Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDocumento);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
               // _CodigoGrupo = Convert.ToInt32(Parameter_CodigoGrupo.Value);
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Usuario::Adicion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//--------------------------------------------------------------------
        public bool Eliminar(int pCodigoResponsable)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_ResponsableDeCreacion", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoResponsable = new SqlParameter("@CodigoResponsable", SqlDbType.Int, 11);
            Parameter_CodigoResponsable.Value = pCodigoResponsable;
            Parameter_CodigoResponsable.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoResponsable);

            //parametro de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Rol::Eliminacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//--------------------------------------------------------------------
        public bool EliminarPorHojaRuta(int pCodigoHojaRuta)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_ResponsableDeCreacionPorHR", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoResponsable", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            //parametro de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Rol::Eliminacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//--------------------------------------------------------------------
        public bool EliminarPorCodigoDocumento(int pCodigoDocumento)
        {
            int Resultado = 0;

            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

            SqlCommand SqlCom = new SqlCommand("del_ResponsableDeCreacionPorDocumento", SqlCon);
            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
            Parameter_CodigoDocumento.Value = pCodigoDocumento;
            Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDocumento);

            //parametro de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            try
            {
                SqlCon.Open();
                Resultado = SqlCom.ExecuteNonQuery();
                _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
            }
            catch (Exception MiExcepcion)
            {
                _CodigoError = -1;
                throw new Exception("Rol::Eliminacion::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }

            if (_CodigoError == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
//--------------------------------------------------------------------
        public DataSet ObtenerResponsabePorHojaRuta(int pCodigoHojaRuta)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_ResponsableDeCreacionPorHR", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
            Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
            Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_docDe");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//--------------------------------------------------------------------
        public DataSet ObtenerResponsabePorCodigoDocumento(int pCodigoDocumento)
        {
            int Retorno = 0;
            SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
            SqlCommand SqlCom = new SqlCommand("sel_ResponsableDeCreacionPorDocumento", SqlCon);

            SqlCom.CommandType = CommandType.StoredProcedure;

            SqlParameter Parameter_CodigoDocumento = new SqlParameter("@CodigoDocumento", SqlDbType.Int, 11);
            Parameter_CodigoDocumento.Value = pCodigoDocumento;
            Parameter_CodigoDocumento.Direction = ParameterDirection.Input;
            SqlCom.Parameters.Add(Parameter_CodigoDocumento);

            //parametros de salida
            SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
            Parameter_CodigoDeError.Direction = ParameterDirection.Output;
            SqlCom.Parameters.Add(Parameter_CodigoDeError);

            SqlDataAdapter da = new SqlDataAdapter(SqlCom);
            DataSet ds = new DataSet();
            try
            {
                SqlCon.Open();
                Retorno = da.Fill(ds, "DataGrid_docDe");
                return ds;
            }
            catch (Exception MiExcepcion)
            {
                throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);
            }
            finally
            {
                SqlCon.Close();
            }
        }
//--------------------------------------------------------------------
        #endregion
    }
}
