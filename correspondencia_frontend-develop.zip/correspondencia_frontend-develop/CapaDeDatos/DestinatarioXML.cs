﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CapaDeDatos
{
    public class DestinatarioXML
    {
        public int per_codigo
        { get; set; }
        
        // Constructor
        public DestinatarioXML()
        {
            this.per_codigo = 0;
        }
        public DestinatarioXML(int per_codigo)
        {
            this.per_codigo = per_codigo;
        }

        // Casteador
        public static String CastearXml(List<DestinatarioXML> lista)
        {   return ConversionTipos.CastearListaObjetosParaXml(lista, typeof (DestinatarioXML));
        }
        
    }
}
