﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class HojaRutaAnuladas
    {
        #region "Variables"
            
            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public HojaRutaAnuladas()
            {
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion
        #region "Propiedades publicas"

            public int _CodigoHRAnulado { get; set; }
            public int _CodigoHojaRuta { get; set; }
            public string _DescripcionAnulacion { get; set; }
            public string _FechaAnulacion { get; set; }
            public int _CodigoSesion { get; set; }
            
        #endregion
        #region "funciones publicas"
//------------------------------------------------------
            public bool Adicionar(int pCodigoHojaRuta, string pDescripcionAnulacion, int pCodigoSesion)
            {
                int Resultado = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("ins_HojaRutaAnuladas", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                SqlParameter Parameter_DescripcionAnulacion = new SqlParameter("@DescripcionAnulacion", SqlDbType.VarChar, 450);
                Parameter_DescripcionAnulacion.Value = pDescripcionAnulacion;
                Parameter_DescripcionAnulacion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_DescripcionAnulacion);

                SqlParameter Parameter_CodigoSesion = new SqlParameter("@CodigoSesion", SqlDbType.Int, 11);
                Parameter_CodigoSesion.Value = pCodigoSesion;
                Parameter_CodigoSesion.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoSesion);

                //parametros de salida
                SqlParameter Parameter_CodigoDeError = new SqlParameter("@CodigoDeError", SqlDbType.Int, 4);
                Parameter_CodigoDeError.Direction = ParameterDirection.Output;
                SqlCom.Parameters.Add(Parameter_CodigoDeError);

                try
                {
                    SqlCon.Open();
                    Resultado = SqlCom.ExecuteNonQuery();
                    _CodigoHojaRuta = Convert.ToInt32(Parameter_CodigoHojaRuta.Value);
                    _CodigoError = Convert.ToInt32(Parameter_CodigoDeError.Value);
                }
                catch (Exception MiExcepcion)
                {
                    _CodigoError = -1;
                    throw new Exception("Usuario::Adicion::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
                if (_CodigoError == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
//------------------------------------------------------
//------------------------------------------------------
//------------------------------------------------------
        #endregion
    }
}
