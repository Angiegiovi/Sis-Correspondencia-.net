﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class Cargos
    {
        #region "Variables"

            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public Cargos()
            {
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }
        #endregion
        #region "Propiedades publicas"

            public int _CodigoCargos { get; set; }
            public string _Descripcion { get; set; }
            public int _Habilitado { get; set; }

        #endregion
        #region "funciones publicas"


        //----------------------------------------------------
          // ever :  se recibe el codigo de un cargo y se devuelve un boolean indicando que si puede 
        // definir la fecha de derivacion
            public SqlDataReader  _ObtenerPermisoFechaDerivacion(int pCodigoCargo)
            {   SqlDataReader  Lector;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_permisoFechaDerivacion", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;
                
                SqlParameter Parameter_pCodigoCargo = new SqlParameter("@car_codigo", SqlDbType.Int, 11);
                Parameter_pCodigoCargo.Value = pCodigoCargo;
                Parameter_pCodigoCargo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_pCodigoCargo);                
                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if(Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {  throw new Exception("Usuario::_ObtenerPermisoFechaDerivacion::Produjo un error.", MiExcepcion);
                }
            }
//---------------------------------------------------------------------------------------------------
        
            public DataSet _ObtenerCargosPorPersona(int pCodigoFuncionario)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_CargosPorPersona", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoFuncionario = new SqlParameter("@per_codigo", SqlDbType.Int, 11);
                Parameter_CodigoFuncionario.Value = pCodigoFuncionario;
                Parameter_CodigoFuncionario.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoFuncionario);

                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "CargosPersona");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {  throw new Exception("Usuario::ObtenerTodosLosUsuarios::Produjo un error.", MiExcepcion);  }
                finally
                {  SqlCon.Close();  }
            }
//---------------------------------------------------------------------------------------------------
       /*     public DataSet _ObtenerTodosLosRoles(int pEstado)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_Rol", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_Estado = new SqlParameter("@Estado", SqlDbType.Int, 11);
                Parameter_Estado.Value = pEstado;
                Parameter_Estado.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Estado);
                 
                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_rol");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("Instruccion::ObtenerTodasLasInstrucciones::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }*/
//---------------------------------------------------------------------------------------------------
      #endregion
    }
}
