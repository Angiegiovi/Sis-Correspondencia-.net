﻿using System;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace CapaDeDatos
{
    public class AnexosHojaRuta
    {
        #region "Variables"
            
            private string _CadenaConexion;
            private int _CodigoError;

        #endregion
        #region "Constructor"

            public AnexosHojaRuta()
            {
                _CadenaConexion = WebConfigurationManager.ConnectionStrings["CadenaDeConexion"].ConnectionString;
            }

        #endregion
        #region "Propiedades publicas"

            public int _CodigoAnexoHojaRuta { get; set; }
            public int _CodigoHojaRuta { get; set; }
            public int _CodigoAnexo { get; set; }
            public int _Cantidad { get; set; }
            public int _CodigoSesion { get; set; }
            
        #endregion
        #region "funciones publicas"

//----------------------------------------------------------
            public DataSet _ObtenerAnexosDeHojaRuta(int pCodigoHojaRuta)
            {
                int Retorno = 0;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("sel_AnexosPorHojaRuta", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);


                SqlDataAdapter da = new SqlDataAdapter(SqlCom);
                DataSet ds = new DataSet();
                try
                {
                    SqlCon.Open();
                    Retorno = da.Fill(ds, "DataGrid_anexoshr");
                    return ds;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::_ObtenerAnexosDeHojaRuta::Produjo un error.", MiExcepcion);
                }
                finally
                {
                    SqlCon.Close();
                }
            }
//----------------------------------------------------------
            public SqlDataReader _AdicionarAnexoXHojaRuta(int pCodigoHojaRuta, int pCodigoAnexo, int pCantidad)
            {
                SqlDataReader Lector;
                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("ins_HojaRutaAnexos", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoHojaRuta = new SqlParameter("@CodigoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoHojaRuta.Value = pCodigoHojaRuta;
                Parameter_CodigoHojaRuta.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoHojaRuta);

                SqlParameter Parameter_CodigoAnexo = new SqlParameter("@CodigoAnexo", SqlDbType.Int, 11);
                Parameter_CodigoAnexo.Value = pCodigoAnexo;
                Parameter_CodigoAnexo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoAnexo);

                SqlParameter Parameter_Cantidad = new SqlParameter("@Cantidad", SqlDbType.Int, 11);
                Parameter_Cantidad.Value = pCantidad;
                Parameter_Cantidad.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Cantidad);

                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::_AdicionaranexoXHojaRuta::Produjo un error.", MiExcepcion);
                }
            }
//----------------------------------------------------------
            public SqlDataReader _EliminarAnexoXHojaRuta(int pCodigoAnexoHojaRuta)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);

                SqlCommand SqlCom = new SqlCommand("del_HojaRutaAnexo", SqlCon);
                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoAnexoHojaRutaTEMP = new SqlParameter("@CodigoAnexoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoAnexoHojaRutaTEMP.Value = pCodigoAnexoHojaRuta;
                Parameter_CodigoAnexoHojaRutaTEMP.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoAnexoHojaRutaTEMP);
                
                try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::_EliminarAnexoXHojaRuta::Produjo un error.", MiExcepcion);
                }
            }
//----------------------------------------------------------
            public SqlDataReader _ModificarAnexoXHojaRuta(int pCodigoAnexoHojaRuta, int pCodigoAnexo, int pCantidad)
            {
                SqlDataReader Lector;

                SqlConnection SqlCon = new SqlConnection(_CadenaConexion);
                SqlCommand SqlCom = new SqlCommand("upd_HojaRutaAnexos", SqlCon);

                SqlCom.CommandType = CommandType.StoredProcedure;

                SqlParameter Parameter_CodigoAnexoHojaRutaTEMP = new SqlParameter("@CodigoAnexoHojaRuta", SqlDbType.Int, 11);
                Parameter_CodigoAnexoHojaRutaTEMP.Value = pCodigoAnexoHojaRuta;
                Parameter_CodigoAnexoHojaRutaTEMP.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoAnexoHojaRutaTEMP);

                SqlParameter Parameter_CodigoAnexo = new SqlParameter("@CodigoAnexo", SqlDbType.Int, 11);
                Parameter_CodigoAnexo.Value = pCodigoAnexo;
                Parameter_CodigoAnexo.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_CodigoAnexo);

                SqlParameter Parameter_Cantidad = new SqlParameter("@Cantidad", SqlDbType.Int, 11);
                Parameter_Cantidad.Value = pCantidad;
                Parameter_Cantidad.Direction = ParameterDirection.Input;
                SqlCom.Parameters.Add(Parameter_Cantidad);

                  try
                {
                    SqlCon.Open();
                    Lector = SqlCom.ExecuteReader();
                    if (Lector.Read())
                    {
                        return Lector;
                    }
                    return null;
                }
                catch (Exception MiExcepcion)
                {
                    throw new Exception("::ModificarAnexoXHojaRuta::Produjo un error.", MiExcepcion);
                }
            }
//----------------------------------------------------------
//----------------------------------------------------------
        #endregion
    }
}
