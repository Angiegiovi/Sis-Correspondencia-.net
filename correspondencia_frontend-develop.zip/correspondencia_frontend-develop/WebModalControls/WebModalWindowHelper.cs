//===============================================================================
// Copyright � Codesummit
// http://www.codesummit.com
//===============================================================================

using System;
using System.Collections.Specialized;
using System.ComponentModel.Design;
using System.ComponentModel;
using System.Drawing.Design;
using System.Drawing;
using System.Web.UI.Design;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace Codesummit
{
	/// <summary>
	/// Helper class for WebModal Windows.  Only one control for each modal window is necessary.  This control
	/// gives access to the Properties collection, OutputData, and the ability to cause the main window to postback on close.
	/// </summary>
	[
	DefaultProperty("CloseForm"), 
	ToolboxData("<{0}:WebModalWindowHelper runat=\"server\"></{0}:WebModalWindowHelper>"), 
	ToolboxBitmap(typeof(WebModalWindowHelper),"Toolbox.WebModalWindowHelper.bmp"),
	Designer(typeof(WebModalWindowHelperDesigner))
	]
	public class WebModalWindowHelper: WebControl
	{
		#region Variables               
		private Properties	_properties; 
		private string		_outputData;
		private bool		_causePostBack	= true;
		private bool		_closeForm		= false;
		private bool		_showVersion	= false;

		// This javascript is used to send data back to the main page.  takes hidden input data
		// and attaches it to the window return object.
		private static string _javascript = @"
				<script language=""javascript"">
					var returnValue = new Object;
					window.parent.returnValue = returnValue;

					function windowOnLoad()
					{
						returnValue.CausePostBack = document.all(""__CausePostBack_ForHelper"").value;
						returnValue.WebModalData = document.all(""__WebModalData_ForHelper"").value;
						window.parent.close();
					}
					window.onload = windowOnLoad;
					
				</script>";

		//This is rendered when __LoadIFrame=True is discovered in the querystring.  In order for a modal window to allow postbacks
		//to function correctly, they must be loaded in an IFrame.  In effect the modal window URL gets called twice:
		//Once to render only this Html, and then the second time it loads within the IFrame.
		private static string iFrameHtml = @"
			<html>
				<head>
					<title></title>
					<script language=""javascript"">
						function body_onload()
						{
							window.parent.returnValue = """";
							document.WebModalForm.__Properties.value = window.dialogArguments.Properties;
							document.WebModalForm.submit();
						}
					</script>
					<script>
						window.document.title = window.dialogArguments.Title;
					</script>
				</head>
				<body style=""margin: 0px"" onload=""body_onload();"">
					<form action=""ActionParam"" target=""WebModalIFrame"" method=""post"" id=""WebModalForm"" name=""WebModalForm"" >
						<input type=""hidden"" id=""__Properties"" name=""__Properties"" >
					</form>
					<iframe scrolling=""ScrollingParam"" id=""WebModalIFrame"" name=""WebModalIFrame"" style=""margin: 0px;width:100%;height:100%"" frameborder=""no""></iframe>
				</body>
			</html>";
		#endregion
		#region Properties  

		/// <summary>
		/// Collection of Property(string Key, string Value) objects send to Modal Window.
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		Editor(typeof(PropertyCollectionEditor), typeof(UITypeEditor)),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Content),
		PersistenceMode(PersistenceMode.InnerDefaultProperty),
		Description("Collection of Property(string Key, string Value) objects sent to Modal Window.")
		]
		public Properties Properties
		{
			get
			{
				if (_properties == null)
				{
					_properties = new Properties();
				}
				return _properties;
			}
		}
		/// <summary>
		/// Data Returned to anchor from the window
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		DefaultValue(""),
		Description("Data Returned to anchor from the window")
		]
		public string OutputData 
		{ 
			get 
			{ 
				return _outputData; 
			} 
			set 
			{ 
				_outputData = value; 
			} 
		} 
		/// <summary>
		/// Should the main window postback when the modal window closes?
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		DefaultValue(""),
		Description("Should the main window postback when the modal window closes?")
		]
		public bool CausePostBack 
		{ 
			get 
			{ 
				return _causePostBack; 
			} 
			set 
			{ 
				_causePostBack = value; 

			} 
		}
		/// <summary>
		/// Show the assembly version in the designer?
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		DefaultValue(false),
		Description("Show the assembly version in the designer?")
		]
		public bool ShowVersion
		{
			get { return _showVersion; }
			set { _showVersion=value; }
		} 
		/// <summary>
		/// If true, modal window will close at appropriate time.
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		DefaultValue(""),
		Description("If true, modal window will close at appropriate time.")
		]
		public bool CloseForm 
		{ 
			get 
			{ 
				return _closeForm; 
			} 
			set 
			{ 
				_closeForm = value; 

			} 
		} 
		#endregion
		#region View State              
		protected override object SaveViewState() 
		{ 
			// Save State as a cumulative array of objects.
			object[] SavedState = new object[4]; 
			SavedState[0] = base.SaveViewState(); 
			SavedState[1] = this.Properties.Xml; 
			SavedState[2] = this.OutputData; 
			SavedState[3] = this.CausePostBack; 
			return SavedState; 
		} 

		protected override void LoadViewState(object SavedState) 
		{ 
			if (SavedState != null)
			{
				// Load State from the array of objects that was saved at SavedViewState.
				object[] state = (object[])SavedState;
				if (state[0] != null) base.LoadViewState(state[0]);
				if (state[1] != null) this.Properties.Xml	= (string)state[1];
				if (state[2] != null) this.OutputData		= (string)state[2]; 
				if (state[3] != null) this.CausePostBack	= (bool)state[3];
			} 
		}
		#endregion			  
		#region Control Events          
		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);
			//Attach to the helper's Page Class.
			this.Page.Init += new System.EventHandler(this.Page_Init);
		} 

		//Attach to the helper's Page Class.
		protected void Page_Init(object sender, EventArgs e)
		{
			if (!this.Page.IsPostBack) 
			{
				if (this.Page.Request.QueryString["__LoadIFrame"] != null)
				{
					//Page is being loaded into the modalwindow.  Will create an iframe, set the scrolling property, 
					string Scrolling; 
					if (((!(this.Page.Request.QueryString["__Scrolling"] == null)) && (this.Page.Request.QueryString["__Scrolling"] == "True")))
					{ 
						Scrolling = "yes"; 
					}
					else 
					{ 
						Scrolling = "no"; 
					} 
					//strip off internal parameters
					string url = this.Page.Request.Url.ToString();
					int internalParameters = url.IndexOf("__LoadIFrame");
					url = url.Substring(0, internalParameters-1);

					//Render the IFrame with the adjusted url
					this.Page.Response.Clear();
					this.Page.Response.Write(iFrameHtml.Replace("ScrollingParam", Scrolling).Replace("ActionParam", url)); 
					this.Page.Response.End();
				}
				else
				{
					//This time, the page is being loaded into the iframe
					//Load the Properties
					this.Properties.Xml = System.Web.HttpUtility.UrlDecode(this.Page.Request.Form["__Properties"]);
				}
			}
		}
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);

			if ( CloseForm )
			{
				this.Page.RegisterHiddenField("__WebModalData_ForHelper", System.Web.HttpUtility.UrlEncode(OutputData));
				this.Page.RegisterHiddenField("__CausePostBack_ForHelper", CausePostBack.ToString()); 

//				if (!this.Page.IsClientScriptBlockRegistered("__WebModalData")) 
//				{ 
//					this.Page.RegisterClientScriptBlock("__WebModalData",  string.Format("<input type=\"hidden\" id=\"__WebModalData\" value=\"{0}\"/>", System.Web.HttpUtility.UrlEncode(OutputData))); 
//					this.Page.RegisterClientScriptBlock("__CausePostBack", string.Format("<input type=\"hidden\" id=\"__CausePostBack\" value=\"{0}\"/>",  CausePostBack.ToString())); 
//				}


				if (!this.Page.IsClientScriptBlockRegistered("HandleClose")) 
				{ 
					this.Page.RegisterClientScriptBlock("HandleClose", _javascript); 
				}
			} 
		}
		#endregion

	}

	#region DesignTime

	
	/// <summary>
	/// Class for displaying WebModalWindowHelper in designer
	/// </summary>
	internal class WebModalWindowHelperDesigner : System.Web.UI.Design.ControlDesigner
	{
		#region Overriden methods

		/// <summary>
		/// Returns HTML code to show in designer
		/// </summary>
		public override string GetDesignTimeHtml()
		{
			string s = "<div style=\"padding:6px; background-color: #333333;color:#FFFFFF;font:12px Verdana " +
				"border-style:outset; border-width:1px; font: 75% 'Microsoft Sans Serif';\">&nbsp;<span style=\"color:#FAB301\">CS</span> "+((Control)Component).ID;
			if (((WebModalWindowHelper)Component).ShowVersion)
				s += "&nbsp;<br/>Ver.&nbsp;"+ this.GetType().Assembly.GetName().Version;
			s += "</div>";
			return s;		}
    
		#endregion
	}
	#endregion
}
