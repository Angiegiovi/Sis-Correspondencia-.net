function WebModalAnchor(){
	this.AnchorID = null;
	this.Scrolling = null;
	this.Title = null;
	this.Properties = new Hashtable();
	this.URL  = null;
	this.LinkedControlID  = null;
	this.HandledEvent = null;
	this.WindowHeight  = null;
	this.WindowWidth  = null;
	this.Open = open;
	this.OutputData = null;
	this.Debug = WebModalAnchor_Debug;
	
	function open()
	{
		return WebModal (this, this.AnchorID, this.Title, this.URL, this.WindowHeight, this.WindowWidth, this.Scrolling, this.Properties.toString());
	}
	function WebModalAnchor_Debug()
	{	
		for (var i in this)
		{
			alert(this.AnchorID + '  [' + i + '] is ' + this[i]);
		}
	}
}