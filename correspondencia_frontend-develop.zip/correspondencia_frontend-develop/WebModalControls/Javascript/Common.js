function WebModal ( Anchor, AnchorID, Title, Url, WindowHeight, WindowWidth, Scrolling, Properties ) {
	
	var o = new Object;
	o.Title = Title;
	o.Properties = Properties;

	var queryStringPrefix;
	if (Url.indexOf("?")==-1)
		queryStringPrefix = "?";
	else
		queryStringPrefix = "&";
		
	var returnValue = window.showModalDialog(Url + queryStringPrefix + "__LoadIFrame=True&__Scrolling=" + Scrolling, o, "dialogHeight:" + WindowHeight + "; dialogWidth:" + WindowWidth + "; status:off; center:on; help:off");
	document.getElementById("__WebModalData").value = returnValue.WebModalData;
	document.getElementById("__CausePostBack").value = returnValue.CausePostBack;
	document.getElementById("__AnchorID").value = AnchorID;

	if (Anchor != null)
	{
		Anchor.OutputData = returnValue.WebModalData;
	}
	return (returnValue.CausePostBack == "True");

}

function WireClientSideEvent(control, event, functionToAttach)
{
	var ctrl;
	if (typeof(control) != "undefined")
	{
		ctrl = control;
	}
	else
	{
		ctrl = document.getElementById(control);
	}

	if (typeof(ctrl) != "undefined")
	{
		if ( typeof( ctrl.addEventListener ) != "undefined" ) {
				ctrl.addEventListener(event, functionToAttach, false);
			} 
		else if ( typeof ( ctrl.attachEvent ) != "undefined" ) 
		{
			ctrl.attachEvent(event, functionToAttach);
		} 
		else 
		{
			ctrl[event] = functionToAttach;
		}
	}
}
