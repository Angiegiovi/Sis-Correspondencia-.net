//===============================================================================
// Copyright � Codesummit
// http://www.codesummit.com
//===============================================================================

using System;
using System.Collections;
using System.ComponentModel.Design;
using System.ComponentModel;
using System.Drawing.Design;
using System.Drawing;
using System.Text;
using System.Web.UI.Design;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Web;

namespace Codesummit
{
	/// <summary>
	/// Web control which simplifies the complex process of opening a modal window in ASP.Net, and passing information in both directions.
	/// </summary>
	/// <remarks>
	/// <para>
	/// The WebModalAnchor control renders all the necessary javascript
	/// to open modal windows and to move server-side data and/or client-side data
	/// to the modal window and back again. 
	/// </para>
	[
	DefaultProperty("Url"), 
	ToolboxData("<{0}:WebModalAnchor runat=\"server\"></{0}:WebModalAnchor>"), 
	DefaultEvent("OnWindowClose"), 
	ToolboxBitmap(typeof(WebModalAnchor),"Toolbox.WebModalAnchor.bmp"),
	Designer(typeof(WebModalAnchorDesigner)),
	ParseChildren(true, "Properties"), //needed by the page parser
	PersistChildren(false) // Needed by the designer
	]
	public class WebModalAnchor : WebControl, INamingContainer
	{
		#region Variables               
		private bool _scrolling = false;
		private bool _clientSideSupport = false;
		private bool _showVersion = false;
		private string _title = "";
		private string _url = "";
		private string _outputData = "";
		private string _linkedControlID = "";
		private JSEvent _handledEvent = JSEvent.onclick;
		private Unit _windowHeight = Unit.Empty;
		private Unit _windowWidth = Unit.Empty;
		private Properties _properties;

		public delegate void OnWindowCloseEventHandler(WebModalAnchor sender);
		public event OnWindowCloseEventHandler OnWindowClose; 

		#endregion
		#region Properties              
		/// <summary>
		/// Should the window have a scrollbar?
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		DefaultValue(false),
		Description("Should the window have a scrollbar?")
		]
		public bool Scrolling
		{
			get { return _scrolling; }
			set { _scrolling=value; }
		}  
		/// <summary>
		/// Show the assembly version in the designer?
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		DefaultValue(false),
		Description("Show the assembly version in the designer?")
		]
		public bool ShowVersion
		{
			get { return _showVersion; }
			set { _showVersion=value; }
		}      
		/// <summary>
		/// Enable client-side javascript support?
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		DefaultValue(false),
		Description("Enable client-side javascript support?")
		]
		public bool ClientSideSupport
		{
			get { return _clientSideSupport; }
			set { _clientSideSupport=value; }
		}
		/// <summary>
		/// Text that appears in the window's title bar
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		DefaultValue(""),
		Description("Text that appears in the window's title bar")
		]
		public string Title
		{
			get { return _title; }
			set { _title=value; }
		}
		/// <summary>
		/// URL of the page that is loaded in the window
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		DefaultValue(""),
		Description("URL of the page that is loaded in the window"),
		Editor(typeof(UrlEditor), typeof(UITypeEditor))
		]
		public string URL
		{
			get { return _url; }
			set { _url=value; }
		}
		/// <summary>
		/// Data Returned to anchor from the window
		/// </summary>
		[
		Bindable(true),
		Browsable(false),
		Category("Window"),
		DefaultValue(""),
		Description("Data Returned to anchor from the window")
		]
		public string OutputData
		{
			get { return _outputData; }
			set { _outputData=value; }
		}

		/// <summary>
		/// Collection of Property(string Key, string Value) objects sent to Modal Window.
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		Editor(typeof(PropertyCollectionEditor), typeof(UITypeEditor)),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Content),
		PersistenceMode(PersistenceMode.InnerDefaultProperty),
		Description("Collection of Property(string Key, string Value) objects sent to Modal Window.")
		]
		public Properties Properties
		{
			get
			{
				if (_properties == null)
				{
					_properties = new Properties();
				}
				return _properties;
			}
		}

		/// <summary>
		/// Contol which event will cause the window to show
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		DefaultValue(""),
		Editor(typeof(AllControlsEditor), typeof(UITypeEditor)),
		Description("Control ")
		]
		public string LinkedControlID
		{
			get { return _linkedControlID; }
			set { _linkedControlID=value; }
		}

		/// <summary>
		/// Object reference to LinkedControlID
		/// </summary>
		[
		Bindable(false),
		Browsable(false),
		Category("Window"),
		DefaultValue(null),
		Description("Object reference to LinkedControlID")
		]
		public Control LinkedControl
		{
			get
			{
				Control ctrl = null;
				if (_linkedControlID != string.Empty)
				{
					ctrl = FindControl(this, _linkedControlID);
				}
				return ctrl;
			}
		}

		/// <summary>
		/// JavaScript event to handle
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		DefaultValue("onclick"),
		//Editor(typeof(JavaScriptEventEditor),typeof(UITypeEditor)),
		Description("JavaScript event to handle")
		]
		public JSEvent HandledEvent
		{
			get { return _handledEvent; }
			set { _handledEvent=value; }
		}
		/// <summary>
		/// The width of the window
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		Description("The width of the window"),
		DefaultValue(typeof(Unit), "400")
		]
		public virtual Unit WindowWidth
		{
			get
			{
				return _windowWidth;
			}
			set
			{
				if (value.Value < 0)
				{
					throw new ArgumentOutOfRangeException("value");
				}
				this._windowWidth = value;
			}
		}

		/// <summary>
		/// The height of the window
		/// </summary>
		[
		Bindable(true),
		Browsable(true),
		Category("Window"),
		Description("The height of the window"),
		DefaultValue(typeof(Unit), "400")
		]
		public virtual Unit WindowHeight
		{
			get
			{
				return _windowHeight;
			}
			set
			{
				if (value.Value < 0)
				{
					throw new ArgumentOutOfRangeException("value");
				}
				this._windowHeight = value;
			}
		}

		#endregion
		#region View State              
		protected override object SaveViewState() 
		{ 
			// Save State as a cumulative array of objects.
			object[] SavedState = new object[11]; 
			SavedState[0] = base.SaveViewState(); 
			SavedState[1] = this.Scrolling;
			SavedState[2] = this.ClientSideSupport;
			SavedState[3] = this.ShowVersion;
			SavedState[4] = this.Title; 
			SavedState[5] = this.Properties.Xml; 
			SavedState[6] = this.URL; 
			SavedState[7] = this.LinkedControlID; 
			SavedState[8] = this.HandledEvent.ToString("d"); 
			SavedState[9] = this.WindowHeight; 
			SavedState[10] = this.WindowWidth; 
			return SavedState; 
		} 

		protected override void LoadViewState(object SavedState) 
		{ 
			if (SavedState != null)
			{
				// Load State from the array of objects that was saved at SavedViewState.
				object[] state = (object[])SavedState;
				if (state[0] != null) base.LoadViewState(state[0]);
				if (state[1] != null) this.Scrolling				= (bool)state[1]; 
				if (state[2] != null) this.ClientSideSupport		= (bool)state[2]; 
				if (state[2] != null) this.ShowVersion				= (bool)state[3]; 
				if (state[3] != null) this.Title					= (string)state[4]; 
				if (state[4] != null) this.Properties.Xml			= (string)state[5];
				if (state[5] != null) this.URL						= (string)state[6]; 
				if (state[6] != null) this.LinkedControlID			= (string)state[7]; 
				if (state[7] != null) this.HandledEvent				= (JSEvent)Enum.Parse(typeof(JSEvent), (string)state[8]); 
				if (state[8] != null) this.WindowHeight				= (Unit)state[9];
				if (state[9] != null) this.WindowWidth				= (Unit)state[10];
			} 
		}
		#endregion
		#region Control Events          
		protected override void OnLoad(System.EventArgs e) 
		{ 
			RegisterJavascript("WebModalJavascript", "Javascript.Common.js");
			this.Page.RegisterHiddenField("__WebModalData"	, string.Empty);
			this.Page.RegisterHiddenField("__CausePostBack"	, string.Empty);
			this.Page.RegisterHiddenField("__AnchorID"		, string.Empty);

			//Move the data returned from the window back into the anchor.
			if (this.Page.IsPostBack) 
			{ 
				//Every anchor calls its OnLoad function, so only the anchor that opened the window should take action here
				if((this.Page.Request.Form["__CausePostBack"] != string.Empty) && (this.Page.Request.Form["__AnchorID"] == this.ClientID))
				{ 
					this.OutputData = HttpUtility.UrlDecode(this.Page.Request.Form["__WebModalData"]); 
					
					//Allow the anchor host to take action on the return data
					if (OnWindowClose != null) 
					{ 
						//Prevent this event from firing more than once. 
						//Occurs in a dynamic scenario, where the anchor is created twice.
						if (this.Context.Items["OnWindowCloseFired"] == null)
						{
							this.Context.Items["OnWindowCloseFired"] = "true";
							OnWindowClose(this); 
						}
						
					} 
					
					Clear(); 
				} 
			} 

			this.RegisterClientEvent();
			
		} 
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			Hashtable anchors;
			StringBuilder sb = new StringBuilder(); 
			//This will only be called once for all anchors, to reduce page output size
			if (this.Context.Items["WebModalAnchor"] != null)
			{
				
				anchors = ((Hashtable)this.Context.Items["WebModalAnchor"]);
				sb.Append("<script type=\"text/javascript\">//<![CDATA[\n");
				sb.Append("WireClientSideEvent(window, \"onload\", wireAnchors);\n");

				foreach (WebModalAnchor anchor in anchors.Values)
				{
					//Add a global reference to the client-side anchor object
					if (anchor.ClientSideSupport)
					{
						sb.AppendFormat("var {0} = new WebModalAnchor();\n"		, anchor.ClientID);
					}
					 
				}
				sb.Append("function wireAnchors(){\n");

				foreach (WebModalAnchor anchor in anchors.Values)
				{
					//Make sure the anchor hasn't been removed from the page
					//This might happen with dynamic rendering, when a row containing an anchor is deleted, for example
					//Then there would be a "ghost" anchor remaining in the httpcontext, so it is ignored
					if (anchor.NamingContainer.FindControl(anchor.ID) != null && anchor.LinkedControl != null && anchor.LinkedControl.Visible == true)
					{
						if (anchor.LinkedControlID == null || anchor.LinkedControlID == string.Empty ) 
						{
							throw new ArgumentNullException("LinkedControlID for " + anchor.ClientID);
						}
						if (anchor.URL == null || anchor.URL == string.Empty ) 
						{
							throw new ArgumentNullException("URL for " + anchor.ClientID);
						}
						if (anchor.Title == null) { anchor.Title = string.Empty; }

						if (anchor.WindowHeight == Unit.Empty) 
						{
							throw new ArgumentNullException("WindowHeight for " + anchor.ClientID);
						}
						if (anchor.WindowWidth == Unit.Empty) 
						{
							throw new ArgumentNullException("WindowWidth for " + anchor.ClientID);
						}

						//render a javascript object model mimicking the server-side one ClientSideSupport is chosen
						if (anchor.ClientSideSupport)
						{
							RegisterJavascript("ClientSideSupport_HashTable"		, "Javascript.HashTable.js");
							RegisterJavascript("ClientSideSupport_WebModalAnchor"	, "Javascript.WebModalAnchor.js");
							sb.AppendFormat("\t{0}.AnchorID = \"{0}\";\n"			, anchor.ClientID);
							sb.AppendFormat("\t{0}.Scrolling = \"{1}\";\n"			, anchor.ClientID	, anchor.Scrolling.ToString());
							sb.AppendFormat("\t{0}.Title = \"{1}\";\n"				, anchor.ClientID	, anchor.Title.ToString());
							sb.AppendFormat("\t{0}.URL =  \"{1}\";\n"				, anchor.ClientID	, anchor.URL.ToString());
							sb.AppendFormat("\t{0}.LinkedControlID = \"{1}\";\n"	, anchor.ClientID	, anchor.LinkedControlID.ToString());
							sb.AppendFormat("\t{0}.HandledEvent = \"{1}\";\n"		, anchor.ClientID	, anchor.HandledEvent.ToString("f"));
							sb.AppendFormat("\t{0}.WindowHeight = \"{1}\";\n"		, anchor.ClientID	, anchor.WindowHeight.ToString());
							sb.AppendFormat("\t{0}.WindowWidth = \"{1}\";\n"		, anchor.ClientID	, anchor.WindowWidth.ToString());
							foreach(Property Property in anchor.Properties)
							{
								sb.AppendFormat("\t{0}.Properties.add(\"{1}\",\"{2}\");\n"	, anchor.ClientID	, HttpUtility.UrlEncode(Property.Key), HttpUtility.UrlEncode(Property.Value));
							}
						}
						else
						{
							//Doesn't seem possible to escape the curly braces, so they are broken out
							sb.AppendFormat("if(document.getElementById(\"{0}\"))",GetClientID(anchor, anchor.LinkedControlID));
							sb.Append("{");
							sb.AppendFormat("document.getElementById(\"{0}\").{1}=function()",GetClientID(anchor, anchor.LinkedControlID), anchor.HandledEvent.ToString("f"));
							sb.Append("{");
							sb.AppendFormat("return WebModal ( null, \"{0}\", \"{1}\", \"{2}\", \"{3}\", \"{4}\", \"{5}\", \"{6}\" ) ", anchor.ClientID, anchor.Title, anchor.URL, anchor.WindowHeight, anchor.WindowWidth, anchor.Scrolling.ToString(),  HttpUtility.UrlEncode(anchor.Properties.Xml) );
							sb.Append("}};\n");

						}
					}
				}
				sb.Append("}\n//]]></script>");	
				//clear it out, so it doesn't get called again
				this.Context.Items["WebModalAnchor"] = null;

				//write the javascript out to the client
				this.Page.RegisterClientScriptBlock("WebModalAnchors", sb.ToString());
			}
		}

#endregion
		#region Internal Functions      

		private string GetClientID(WebModalAnchor anchor, string id)
		{
			//determine the actual ClientID of a LinkedControlID
			return FindControl(anchor, id).ClientID;

		}
		private Control FindControl(WebModalAnchor anchor, string id)
		{
			// recursive routine for walking from anchor to top, looking for the LinkedControlID,
			// so it can retrieve an actual reference
			for (Control ctrl = anchor.Parent; ctrl != null; ctrl = ctrl.Parent)
			{
				Control _ctrl = ctrl.FindControl(id);
				if ( _ctrl != null)
				{
					return _ctrl;
				}
			}

			throw new ApplicationException(string.Format("Anchor:{0} was unable to find LinkedControlID:{1} in the control hierarchy.", anchor.ClientID, anchor.LinkedControlID));

		}

		/// <summary>
		/// Clear the anchor so it can be reused.
		/// </summary>
		private void Clear() 
		{ 
			this.OutputData = string.Empty; 
		} 

		/// <summary>
		/// Store a reference to the anchor in the httpcontext, so all anchors can be rendered in one block
		/// </summary>
		private void RegisterClientEvent()
		{
			if (this.Context.Items["WebModalAnchor"] == null){ 
				this.Context.Items["WebModalAnchor"] = new Hashtable(); 
			}
			//If the anchor is already in memory, remove it, since the latter on is more up to date.
			if (((Hashtable)this.Context.Items["WebModalAnchor"]).Contains(this.ClientID))
			{
				((Hashtable)this.Context.Items["WebModalAnchor"]).Remove(this.ClientID);
			}
			((Hashtable)this.Context.Items["WebModalAnchor"]).Add(this.ClientID, this);
			
		}
		/// <summary>
		/// Wrapper for retrieving and registering embedded javascript resource files
		/// </summary>
		private void RegisterJavascript(string blockName, string scriptname)
		{
			if ( !Page.IsClientScriptBlockRegistered(blockName) ) 
			{
				using (System.IO.StreamReader reader = new System.IO.StreamReader(typeof(WebModalAnchor).Assembly.GetManifestResourceStream(typeof(WebModalAnchor), scriptname)))
				{
					string script = "<script language='javascript' type='text/javascript' >\r\n<!--\r\n" + reader.ReadToEnd() + "\r\n//-->\r\n</script>";
					this.Page.RegisterClientScriptBlock(blockName, script);
				}
			}			
		}

		#endregion 
	}

	#region DesignTime
	/// <summary>
	/// Editor for selecting adding and editing properties in designer
	/// </summary>
	internal class PropertyCollectionEditor : CollectionEditor
	{

		public PropertyCollectionEditor(Type type) : base(type)
		{
		}

		protected override Type CreateCollectionItemType()
		{
			return typeof(Property);
		}
	}

	/// <summary>
	/// Class for displaying WebModalAnchor in designer
	/// </summary>
	internal class WebModalAnchorDesigner : ControlDesigner
	{
		#region Overriden methods

		/// <summary>
		/// Returns HTML code to show in designer
		/// </summary>
		public override string GetDesignTimeHtml()
		{
			string s = "<div style=\"padding:6px; background-color: #333333;color:#FFFFFF;font:12px Verdana " +
				"border-style:outset; border-width:1px; font: 75% 'Microsoft Sans Serif';\">&nbsp;<span style=\"color:#FAB301\">CS</span> "+((Control)Component).ID;
			if (((WebModalAnchor)Component).ShowVersion)
				s += "&nbsp;<br/>Ver.&nbsp;"+ this.GetType().Assembly.GetName().Version;
			s += "</div>";
			return s;
			
		}
    
		#endregion
	}
	/// <summary>
	/// Editor for selecting controls from Asp.Net page
	/// </summary>
	internal abstract class ControlsEditor : UITypeEditor
	{
		#region Variables

		private System.Windows.Forms.Design.IWindowsFormsEditorService edSvc=null;
		private System.Windows.Forms.ListBox lb;
		private Type typeShow;

		#endregion
		#region Constructor


		/// <summary>
		/// onstructor - show specified types
		/// </summary>
		/// <param name="show">Type descriptor</param>
		public ControlsEditor(Type show)
		{
			typeShow=show;
		}

		#endregion
		#region Methods

		/// <summary>   
		/// Overrides the method used to provide basic behaviour for selecting editor.
		/// Shows our custom control for editing the value.
		/// </summary>
		/// <param name="context">The context of the editing control</param>
		/// <param name="provider">A valid service provider</param>
		/// <param name="value">The current value of the object to edit</param>
		/// <returns>The new value of the object</returns>
		public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider,object value) 
		{  
			if (context!=null&&context.Instance!=null&&provider!=null) 
			{
				edSvc=(System.Windows.Forms.Design.IWindowsFormsEditorService)
					provider.GetService(typeof(System.Windows.Forms.Design.IWindowsFormsEditorService));

				if (edSvc!=null) 
				{					
					lb=new System.Windows.Forms.ListBox();
					ArrayList controlArray = new ArrayList();
					lb.BorderStyle=System.Windows.Forms.BorderStyle.None;
					lb.SelectedIndexChanged+=new EventHandler(lb_SelectedIndexChanged);

					//Cycle through the controls in the anchor's NamingContainer
					ControlCollection coll = ((Control)context.Instance).NamingContainer.Controls;

					//((ReadOnlyCollectionBase)((IContainer)(context.Container)).Components)

					for(int i = 0; i<= coll.Count; i++)
					{
						try
						{
							Control ctrl = coll[i];
							if ((ctrl.GetType().IsSubclassOf(typeShow) || ctrl.GetType().FullName==typeShow.FullName) && ctrl.ID != null) 
								controlArray.Add(ctrl.ID);
						}
						catch{}
					}
					
					//Sort the controls by ID, and then add them to the listbox
					controlArray.Sort(new CaseInsensitiveComparer());
					IEnumerator myEnumerator = controlArray.GetEnumerator();
					while ( myEnumerator.MoveNext() )
						lb.Items.Add(myEnumerator.Current);

					//return it to the IDE
					edSvc.DropDownControl(lb);
					if (lb.SelectedIndex==-1) return value;
						return lb.SelectedItem;
				}
			}

			return value;
		}


		/// <summary>
		/// Choose editor type
		/// </summary>
		/// <param name="context">The context of the editing control</param>
		/// <returns>Returns <c>UITypeEditorEditStyle.DropDown</c></returns>
		public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context) 
		{
			return UITypeEditorEditStyle.DropDown;			
		}


		/// <summary>
		/// Close the dropdowncontrol when theProperty has selected a value
		/// </summary>
		private void lb_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (edSvc != null) 
			{
				edSvc.CloseDropDown();
			}
		}

		#endregion
	}


	/// <summary>
	/// Editor for selecting all Asp.Net controls
	/// </summary>
	internal class AllControlsEditor : ControlsEditor
	{
		#region Members

		/// <summary>
		/// Invoke base constructor
		/// </summary>
		public AllControlsEditor() : base(typeof(Control)) {}

		#endregion
	}
	
	/// <summary>
	/// List of javascript events used for HandleEvent Property
	/// </summary>
	public enum JSEvent
	{
		onabort,
		onblur,
		onchange,
		onclick,
		oncontextmenu,
		ondblclick,
		ondragdrop,
		onerror,
		onfocus,
		onkeydown,
		onkeypress,
		onkeyup,
		onload,
		onmousedown,
		onmouseout,
		onmouseover,
		onmouseup,
		onmove,
		onreset,
		onresize,
		onselect,
		onsubmit,
		onunload
	}
}
	#endregion


