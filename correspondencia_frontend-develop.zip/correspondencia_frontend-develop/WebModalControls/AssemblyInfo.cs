using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("WebModalControls")]
[assembly: AssemblyDescription("Simplifies the complex process of opening a modal window in ASP.Net, and passing information in both directions.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Codesummit")]
[assembly: AssemblyProduct("WebModal Anchor Control")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		
[assembly: AssemblyVersion("0.5.2")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
[assembly: System.Web.UI.TagPrefix("Codesummit","cs")]

//Version 0.5.2 04/05/05 CausePostback failed when anchors existed in modal window.  Fixed conflict with hidden fields.
//Version 0.5.1 04/04/05 Fixed Problem with anchors displaying when Linked Control wasn't
//Version 0.5.0 03/31/05 Created
